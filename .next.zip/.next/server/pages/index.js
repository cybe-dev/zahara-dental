module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/jkW":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "0Bsm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router = __webpack_require__("nOHt");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (false) {}

  return WithRouterWrapper;
}

/***/ }),

/***/ "0G5g":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "0mz7":
/***/ (function(module, exports) {

module.exports = {
  purge: ["./pages/**/*.{js,ts,jsx,tsx}", "./src/components/**/*.{js,ts,jsx,tsx}"],
  darkMode: false,
  // or 'media' or 'class'
  theme: {
    colors: {
      accent: "#ffeebb",
      transparent: "transparent",
      background: "#e6f8f9",
      primary: {
        100: "#00b4c5",
        200: "#00a2b1",
        300: "#00909e",
        400: "#007e8a",
        500: "#006c76"
      },
      grayscale: {
        100: "#ffffff",
        200: "#e6e6e6",
        300: "#b3b3b3",
        400: "#999999",
        500: "#808080",
        600: "#666666",
        700: "#4d4d4d",
        800: "#333333",
        900: "#1a1a1a",
        1000: "#000000"
      }
    },
    extend: {}
  },
  variants: {
    extend: {
      translate: ["group-hover", "group-focus"],
      width: ["group-hover", "group-focus"],
      padding: ["group-hover", "group-focus"],
      display: ["group-hover", "group-focus"],
      overflow: ["hover", "group-focus"],
      boxShadow: ["group-hover"]
    }
  },
  plugins: []
};

/***/ }),

/***/ "284h":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("cDf5");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "3WeD":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "3wub":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.normalizeLocalePath = normalizeLocalePath;

function normalizeLocalePath(pathname, locales) {
  let detectedLocale; // first item will be empty string from splitting at first char

  const pathnameParts = pathname.split('/');
  (locales || []).some(locale => {
    if (pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
      detectedLocale = locale;
      pathnameParts.splice(1, 1);
      pathname = pathnameParts.join('/') || '/';
      return true;
    }

    return false;
  });
  return {
    pathname,
    detectedLocale
  };
}

/***/ }),

/***/ "6D7l":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__("3WeD"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "7UUK":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "8OQS":
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("RNiq");


/***/ }),

/***/ "ANQk":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "Aiso":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dQHF")


/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "GXs3":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = resolveRewrites;

function resolveRewrites() {}

/***/ }),

/***/ "KaAA":
/***/ (function(module, exports) {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ "Nh2W":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.default = void 0;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__("UhrY"));

var _requestIdleCallback = __webpack_require__("0G5g"); // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? // eslint-disable-next-line no-sequences
  generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (_unused) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR'); // TODO: unexport

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // Resolve a promise that times out after given amount of milliseconds.


function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject);
    (0, _requestIdleCallback.requestIdleCallback)(() => setTimeout(() => {
      if (!cancelled) {
        reject(err);
      }
    }, ms));
  });
} // TODO: stop exporting or cache the failure
// It'd be best to stop exporting this. It's an implementation detail. We're
// only exporting it for backwards compatibilty with the `page-loader`.
// Only cache this response as a last resort if we cannot eliminate all other
// code branches that use the Build Manifest Callback and push them through
// the Route Loader interface.


function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (false) {}

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route) {
      return withFuture(route, routes, async () => {
        try {
          const {
            scripts,
            css
          } = await getFilesForRoute(assetPrefix, route);
          const [, styles] = await Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
          const entrypoint = await resolvePromiseWithTimeout(this.whenEntrypoint(route), MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`)));
          const res = Object.assign({
            styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        } catch (err) {
          return {
            error: err
          };
        }
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback.requestIdleCallback)(() => this.loadRoute(route));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

var _default = createRouteLoader;
exports.default = _default;

/***/ }),

/***/ "Osoz":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router-context.js");

/***/ }),

/***/ "RNiq":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "getServerSideProps", function() { return /* binding */ getServerSideProps; });
__webpack_require__.d(__webpack_exports__, "default", function() { return /* binding */ Home; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// CONCATENATED MODULE: ./src/images/Background.js



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Background(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", _objectSpread(_objectSpread({
    id: "Layer_1",
    "data-name": "Layer 1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 1024 720",
    preserveAspectRatio: "none"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
      children: "Untitled-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M175.33,92.5c3.22,0,3.23-5,0-5s-3.22,5,0,5Z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M0,720s138-94.94,292.83-112.5c242.5-27.5,195-11.81,295-96.67,82.5-70,105.84-25,237.5-64.16C993.15,396.75,1024,0,1024,0H0Z"
    })]
  }));
}
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__("Aiso");
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);

// EXTERNAL MODULE: ./tailwind.config.js
var tailwind_config = __webpack_require__("0mz7");

// EXTERNAL MODULE: ./src/components/Container.jsx
var Container = __webpack_require__("wcCm");

// CONCATENATED MODULE: ./src/components/SocialMediaButton.jsx


function SocialMediaButton_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function SocialMediaButton_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { SocialMediaButton_ownKeys(Object(source), true).forEach(function (key) { SocialMediaButton_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { SocialMediaButton_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function SocialMediaButton_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


function SocialMediaButton(_ref) {
  let {
    href = "#",
    className,
    icon
  } = _ref,
      props = _objectWithoutProperties(_ref, ["href", "className", "icon"]);

  let css = "flex justify-center items-center w-8 h-8 bg-grayscale-400 hover:bg-primary-100";

  if (className) {
    css += " " + className;
  }

  const Icon = icon;
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", SocialMediaButton_objectSpread(SocialMediaButton_objectSpread({
    href: href,
    className: css
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Icon, {
      width: 18,
      height: 18,
      fill: tailwind_config["theme"].colors.grayscale[100]
    })
  }));
}
// CONCATENATED MODULE: ./src/components/WhyChoose.jsx



function WhyChooseList({
  icon,
  title,
  children,
  right = false
}) {
  const Icon = icon;
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "group",
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "relative flex flex-col items-center ",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "p-3 bg-accent rounded-lg",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Icon, {
          fill: tailwind_config["theme"].colors.primary[300],
          width: 44,
          height: 44
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-grayscale-800 font-bold arimo text-center mt-1",
        children: title
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: right ? "p-0 lg:group-hover:p-5 w-0 lg:group-hover:w-96 group-hover:block transform -translate-y-12 group-hover:translate-y-0 bg-primary-300 text-grayscale-100 absolute rounded shadow overflow-hidden transition-transform z-10 top-full right-0" : "p-0 lg:group-hover:p-5 w-0 lg:group-hover:w-96 group-hover:block transform -translate-y-12 group-hover:translate-y-0 bg-primary-300 text-grayscale-100 absolute rounded shadow overflow-hidden transition-transform z-10 top-full left-0",
        children: children
      })]
    })
  });
}
function WhyChooseContainer({
  children
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "grid grid-flow-row gap-16 md:gap-12 lg:gap-10 xl:gap-16 grid-cols-1 md:grid-cols-2 lg:grid-cols-4 my-16",
    children: children
  });
}
// CONCATENATED MODULE: ./src/images/BackgroundMobile.js



function BackgroundMobile_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function BackgroundMobile_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { BackgroundMobile_ownKeys(Object(source), true).forEach(function (key) { BackgroundMobile_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { BackgroundMobile_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function BackgroundMobile_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function BackgroundMobile(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", BackgroundMobile_objectSpread(BackgroundMobile_objectSpread({
    id: "Layer_1",
    "data-name": "Layer 1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 1024 720",
    preserveAspectRatio: "none"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
      children: "Untitled-2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M175.33,92.5c3.22,0,3.23-5,0-5s-3.22,5,0,5Z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "0 0 1024 0 1024 630.83 0 720 0 0"
    })]
  }));
}
// CONCATENATED MODULE: ./src/images/Welcome.js



function Welcome_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Welcome_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Welcome_ownKeys(Object(source), true).forEach(function (key) { Welcome_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Welcome_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Welcome_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Welcome(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", Welcome_objectSpread(Welcome_objectSpread({
    id: "ccdb08d7-40f3-45f2-8ef6-c6a673654779",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "1167.61",
    height: "862.87",
    viewBox: "0 0 1167.61 862.87",
    preserveAspectRatio: "xMidYMid meet"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("defs", {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("linearGradient", {
        id: "cb66075b-2ebe-455c-893b-1def13a8d59c",
        x1: "481.48",
        y1: "854.12",
        x2: "481.48",
        y2: "276.47",
        gradientUnits: "userSpaceOnUse",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("stop", {
          offset: "0",
          stopColor: "gray",
          stopOpacity: "0.25"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("stop", {
          offset: "0.54",
          stopColor: "gray",
          stopOpacity: "0.12"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("stop", {
          offset: "1",
          stopColor: "gray",
          stopOpacity: "0.1"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("linearGradient", {
        id: "b7415561-023b-44da-badb-9b3453976a8a",
        x1: "878.34",
        y1: "879.41",
        x2: "878.34",
        y2: "264.07",
        xlinkHref: "#cb66075b-2ebe-455c-893b-1def13a8d59c"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
      children: "doctors"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M92.37,356.76H193.85V495.09H99.79c-.24,1.43-.48,2.85-.75,4.28h94.81V610.91c-.16,0-.32-.12-.47-.18q-4-1.59-8-3.37c-.57-.26-1.13-.53-1.71-.78q-4-1.89-8-4c-.93-.49-1.86-1-2.77-1.52A166.43,166.43,0,0,1,133,570c-.35-.33-.67-.69-1-1-1.62-1.76-3.21-3.54-4.75-5.36-.58-.67-1.14-1.35-1.71-2-1.82-2.22-3.58-4.52-5.28-6.83-.26-.35-.5-.69-.75-1a147.72,147.72,0,0,1-17.2-31.1c-.14-.33-.27-.69-.4-1-1.38-3.5-2.63-7.05-3.71-10.67-.46-1.51-.91-3-1.29-4.57-.14-.45-.25-.91-.37-1.36-5.62-22.15-6.27-45.17-6.27-68.08q0-4,0-8Q90.39,415,90.6,401q.08-3.6.15-7.23.21-9.19.6-18.42c.06-1.7.14-3.41.23-5.1q.06-1.47.15-2.94Q92,362,92.37,356.76Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M193.85,202.74H138.18A423.75,423.75,0,0,1,167.79,162c8.28-10.16,17-20.06,26.06-29.6Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M193.85,207V352.48H92.69c0-.42.06-.85.1-1.27.09-1.15.18-2.29.28-3.44.1-1.34.23-2.68.36-4s.26-2.92.42-4.37.29-2.92.45-4.37.32-2.9.5-4.34.34-2.9.54-4.34c.15-1.19.3-2.39.47-3.59.23-1.69.47-3.38.72-5.06,0-.26.08-.51.12-.76a348.93,348.93,0,0,1,7.44-36.52,270.41,270.41,0,0,1,12.55-37A277.87,277.87,0,0,1,135.52,207Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M218.09,356.76V495.09H434.85V356.76Zm0,142.61v118.8c1.24.25,2.46.5,3.69.71,1.65.32,3.31.61,5,.86l1,.14c.66.11,1.33.2,2,.28,1.67.24,3.34.42,5,.58.78.08,1.59.14,2.38.21l1.93.14h0c1.05.08,2.09.14,3.13.18.64,0,1.28.05,1.93.07s1,0,1.52,0l1.89,0c.86,0,1.72,0,2.57,0h1.1c.86,0,1.72,0,2.57-.08h.05c.6,0,1.19,0,1.79-.07a4.38,4.38,0,0,0,.51,0c.5,0,1,0,1.48-.06a2.09,2.09,0,0,1,.34,0c1.11-.07,2.23-.16,3.36-.26s2.2-.22,3.33-.34l2.27-.28a199.13,199.13,0,0,0,27.45-5.84c20.23-5.64,40-13.53,60.22-19.3,26.12-7.45,55-11.12,80.24-2.05V499.37ZM434.85,202.74V18.58a278.53,278.53,0,0,0-70.42,8.25c-54.89,13.79-104.18,43.7-146.34,81.9v94H229V207H218.09V352.48H434.85V207H273.63v-4.28Zm278.48-62.21c-13.58-.48-27.08-4.77-39.3-11.42-23.34-12.69-42-32.31-62.84-48.85-43.3-34.47-97-55.28-152.09-60.44V202.74H768.51l.77-.81Zm28.19-5,29.89,32.81V126.9C761.35,128.17,752.59,131.12,741.52,135.49Zm29.89,512.14V499.37H707.67c-.16-.63-.34-1.27-.54-1.91.19.64.36,1.28.53,1.91H459.1V606.61c2.36,1.75,4.69,3.6,7,5.46h0q3.74,3.06,7.43,6.19l2.48,2.05c1.19,1,2.4,2,3.6,2.95q3.61,2.91,7.27,5.76,1.83,1.44,3.68,2.83a502.09,502.09,0,0,0,61.64,40.31c4.82,2.69,9.69,5.28,14.59,7.81q4.89,2.52,9.85,4.94,7.44,3.63,15,7s0,0,0,0a550.6,550.6,0,0,0,146,42.52q16.78,2.47,33.71,3.9V647.65l1,0ZM459.1,207V352.48H771.41V207Zm0,149.74V495.09H771.41V356.76ZM795.65,126.7V173l38.14-41.87Q814.83,128,795.65,126.7Zm0,230.06V495.09H1099.4V356.76Zm302.68,301.88,1.07-159.27H795.65V739.94a547.32,547.32,0,0,0,58.7-.71h0l.34,0q14-.9,27.87-2.56l.21,0A512.49,512.49,0,0,0,1026,698.41m132-318.93q-1.73-4-3.55-8c-2.26-5-4.64-9.86-7.1-14.71h-23.7V495.09h59.91C1183.51,455.91,1173.59,415.91,1158,379.48Zm-34.35,119.89v137c16.87-16.17,31.14-34.68,41.4-55.84,12.35-25.49,18-53.07,18.47-81.17Zm0-182.92v36h21.48A391.16,391.16,0,0,0,1123.65,316.45Zm-206-162.6c-1.58-.61-3.17-1.22-4.76-1.8a432.15,432.15,0,0,0-51.3-15.42l-58.38,64.06h0l-1.14,1.23.75.81h207.78A443.9,443.9,0,0,0,917.65,153.85ZM1016.7,207H799.91l-4.26,3.89V352.48H833a.05.05,0,0,0,0,0l0,0H1099.4v-68.6A432.49,432.49,0,0,0,1016.7,207Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M193.85,280.39v72.09H92.69c0-.42.06-.85.1-1.27.09-1.15.18-2.29.28-3.44.1-1.34.23-2.68.36-4s.26-2.92.42-4.37.29-2.92.45-4.37.32-2.9.5-4.34.34-2.9.54-4.34c.15-1.19.3-2.39.47-3.59.23-1.69.47-3.38.72-5.06,0-.26.08-.51.12-.76a348.93,348.93,0,0,1,7.44-36.52Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M92.37,356.76H193.85V495.09H99.79c-.24,1.43-.48,2.85-.75,4.28h94.81V610.91c-.16,0-.32-.12-.47-.18q-4-1.59-8-3.37c-.57-.26-1.13-.53-1.71-.78q-4-1.89-8-4c-.93-.49-1.86-1-2.77-1.52A166.43,166.43,0,0,1,133,570c-.35-.33-.67-.69-1-1-1.62-1.76-3.21-3.54-4.75-5.36-.58-.67-1.14-1.35-1.71-2-1.82-2.22-3.58-4.52-5.28-6.83-.26-.35-.5-.69-.75-1a147.72,147.72,0,0,1-17.2-31.1c-.14-.33-.27-.69-.4-1-1.38-3.5-2.63-7.05-3.71-10.67-.46-1.51-.91-3-1.29-4.57-.14-.45-.25-.91-.37-1.36-5.62-22.15-6.27-45.17-6.27-68.08q0-4,0-8Q90.39,415,90.6,401q.08-3.6.15-7.23.21-9.19.6-18.42c.06-1.7.14-3.41.23-5.1q.06-1.47.15-2.94Q92,362,92.37,356.76Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "278.44 209.28 278.44 333.92 202.13 333.92 202.13 209.28 213.01 209.28 213.01 167.08 257.67 167.08 257.67 209.28 278.44 209.28",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "202.13",
      y: "338.19",
      width: "76.3",
      height: "138.33",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M218.09,499.37h76.3v115a197.64,197.64,0,0,1-27.45,5.83c-.76.11-1.51.2-2.27.28-1.12.13-2.23.25-3.34.35l-3.35.27-.34,0-1.48.08-.51,0c-.6,0-1.19.07-1.79.08h-.05c-.86,0-1.71.06-2.57.08h-1.1c-.85,0-1.7,0-2.57,0l-1.88,0-1.53,0c-.65,0-1.29,0-1.94-.08q-1.54-.06-3.12-.18h0l-1.93-.14c-.8-.06-1.6-.14-2.39-.22q-2.52-.22-5-.57l-2-.28-1-.14c-1.67-.25-3.33-.53-5-.85-1.24-.22-2.46-.47-3.69-.73Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "692.53",
      y: "194.56",
      width: "62.92",
      height: "139.35",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "755.46 338.19 755.46 476.53 443.15 476.53 443.15 416.86 609.5 416.86 609.5 452.06 692.53 452.06 692.53 338.19 755.46 338.19",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M772.4,647.7c-.33,0-.66,0-1-.06v90.75Q754.49,737,737.7,734.5A551.33,551.33,0,0,1,591.64,692q-20.13-9.08-39.44-19.79a503.91,503.91,0,0,1-61.63-40.31q-7.38-5.64-14.54-11.53c-3.31-2.74-6.59-5.54-9.93-8.25-2.3-1.87-4.63-3.72-7-5.48V499.37H707.66c-.18-.64-.34-1.27-.52-1.91.19.64.37,1.27.53,1.91h63.74V647.63C771.74,647.64,772.07,647.67,772.4,647.7Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M935.51,202.74h-41V190h18.37V152.05q2.39.88,4.76,1.8V190h17.86Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M1034.3,352.48H833a.13.13,0,0,0,.06,0l-.09,0H795.65V213.13h10.58v103h48.34v-61h39.95V207h41v48.16h39.93v61h58.86Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M795.65,356.76V495.09h238.66V356.76Zm303.41,301.15.34-109.5h-65.09v-49H795.65V739.94a547.32,547.32,0,0,0,58.7-.71h0l.34,0q14-.9,27.87-2.56l.21,0A512.49,512.49,0,0,0,1026,698.41",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M1127.85,499.37h55.67c-.48,28.09-6.12,55.68-18.47,81.16-10.26,21.17-24.53,39.68-41.4,55.85v-88h4.2Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M1183.56,495.09h-55.71V379.48H1158C1173.59,415.91,1183.51,455.91,1183.56,495.09Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "721.75",
      y: "233.3",
      width: "33.71",
      height: "43.69",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "721.75",
      y: "323.86",
      width: "33.71",
      height: "10.06",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "721.75",
      y: "338.19",
      width: "33.71",
      height: "29.35",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "721.75",
      y: "414.42",
      width: "33.71",
      height: "43.69",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "721.75",
      y: "504.98",
      width: "33.71",
      height: "43.69",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M771.41,647.63c.33,0,.66,0,1,.07-.33,0-.66,0-1-.06v10.15H737.7V614.1h33.71Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M771.41,704.65v33.74Q754.49,737,737.7,734.5V704.65Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "443.15",
      y: "473.32",
      width: "144.47",
      height: "3.21",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "443.15",
      y: "480.8",
      width: "144.47",
      height: "12.3",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "443.15",
      y: "533.42",
      width: "144.47",
      height: "19.78",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M603.57,612.08v19.78h-113q-7.38-5.62-14.54-11.54c-3.32-2.73-6.6-5.53-9.93-8.24Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M603.57,672.17V692H591.64q-20.13-9.08-39.44-19.79Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "838.4",
      y: "351.6",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "222.62",
      y: "219.09",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "222.62",
      y: "285.15",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "222.62",
      y: "351.21",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "222.62",
      y: "417.26",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "222.62",
      y: "483.32",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "222.62",
      y: "549.38",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "946.97",
      y: "351.6",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "838.4",
      y: "421.75",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "946.97",
      y: "421.75",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "838.4",
      y: "491.89",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "946.97",
      y: "491.89",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "838.4",
      y: "562.04",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "946.97",
      y: "562.04",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "838.4",
      y: "632.19",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "946.97",
      y: "632.19",
      width: "28.44",
      height: "28.44",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "838.4 720.67 838.4 702.33 866.83 702.33 866.83 718.06 838.4 720.67",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M96.53,316.91v16.27h97.32V316.91Zm9.69,15.25h-8V317.94h8Zm9.69,0h-8V317.94h8Zm9.67,0h-8V317.94h8Zm9.69,0h-8V317.94h8Zm9.68,0h-8V317.94h8Zm9.69,0h-8V317.94h8Zm9.69,0h-8V317.94h8Zm9.68,0h-8V317.94h8Zm9.68,0h-8V317.94h8Zm9.69,0h-8V317.94h8Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M96.53,364.27v16.27h97.32V364.27Zm9.69,15.25h-8V365.3h8Zm9.69,0h-8V365.3h8Zm9.67,0h-8V365.3h8Zm9.69,0h-8V365.3h8Zm9.68,0h-8V365.3h8Zm9.69,0h-8V365.3h8Zm9.69,0h-8V365.3h8Zm9.68,0h-8V365.3h8Zm9.68,0h-8V365.3h8Zm9.69,0h-8V365.3h8Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M96.53,411.64V427.9h97.32V411.64Zm9.69,15.23h-8V412.65h8Zm9.69,0h-8V412.65h8Zm9.67,0h-8V412.65h8Zm9.69,0h-8V412.65h8Zm9.68,0h-8V412.65h8Zm9.69,0h-8V412.65h8Zm9.69,0h-8V412.65h8Zm9.68,0h-8V412.65h8Zm9.68,0h-8V412.65h8Zm9.69,0h-8V412.65h8Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M96.53,459v16.26h97.32V459Zm9.69,15.24h-8V460h8Zm9.69,0h-8V460h8Zm9.67,0h-8V460h8Zm9.69,0h-8V460h8Zm9.68,0h-8V460h8Zm9.69,0h-8V460h8Zm9.69,0h-8V460h8Zm9.68,0h-8V460h8Zm9.68,0h-8V460h8Zm9.69,0h-8V460h8Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M97,506.34c.38,1.54.83,3.06,1.29,4.57v-3.54h8v14.21H102c.12.34.25.69.39,1h91.5V506.34Zm19,15.24h-8V507.37h8Zm9.67,0h-8V507.37h8Zm9.69,0h-8V507.37h8Zm9.68,0h-8V507.37h8Zm9.69,0h-8V507.37h8Zm9.69,0h-8V507.37h8Zm9.68,0h-8V507.37h8Zm9.68,0h-8V507.37h8Zm9.69,0h-8V507.37h8Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M119.54,553.7c.26.32.5.68.75,1h5.29v6.83l1.71,2v-8.87h8V569H132c.32.33.63.68,1,1h60.83V553.7ZM145,569h-8V554.72h8Zm9.69,0h-8V554.72h8Zm9.69,0h-8V554.72h8Zm9.68,0h-8V554.72h8Zm9.68,0h-8V554.72h8Zm9.69,0h-8V554.72h8Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M172.93,601.06c.92.52,1.85,1,2.78,1.51v-.5h8v4.51c.58.25,1.13.52,1.7.78v-5.29h8v8.66a3.26,3.26,0,0,0,.47.17v-9.84Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M833,352.48h0a.05.05,0,0,0,0,0Zm-61.6,295.15v0l1,0ZM707.13,497.46c.19.64.36,1.28.53,1.91h0C707.51,498.74,707.33,498.1,707.13,497.46ZM833,352.48h0a.05.05,0,0,0,0,0ZM229,202.74V207h44.67v-4.28ZM771.41,647.63v0l1,0ZM707.13,497.46c.19.64.36,1.28.53,1.91h0C707.51,498.74,707.33,498.1,707.13,497.46ZM833,352.48h0a.05.05,0,0,0,0,0Zm-61.6,295.15v0l1,0ZM707.13,497.46c.19.64.36,1.28.53,1.91h0C707.51,498.74,707.33,498.1,707.13,497.46Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("ellipse", {
      cx: "879.43",
      cy: "847.22",
      rx: "97.44",
      ry: "15.65",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("ellipse", {
      cx: "439.97",
      cy: "831.57",
      rx: "97.44",
      ry: "15.65",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M568.1,436.31a.53.53,0,0,0-.15-.26c-1.49-1.47-20.49-28.34-20.49-28.34s-1-3-2.62-6.9a6.86,6.86,0,0,0,1.15-2.25,7.72,7.72,0,0,0,.19-1.05c0-.11.08-.2.11-.31a7.59,7.59,0,0,0-.1-4.12,7.12,7.12,0,0,1-.41,1,16.72,16.72,0,0,0-1.5-3.34c-2.52-4.34-6.12-8-8.77-12.23A33.09,33.09,0,0,1,531,356.55c0,.39,0,.79,0,1.18a34.24,34.24,0,0,1,.6-4.5,31.22,31.22,0,0,1,1.67-4.94c2.38-5.45,6.23-10.2,8.57-15.67a29.7,29.7,0,0,0,1.78-5.73,32.1,32.1,0,0,0,.89-10.05c0,.8-.13,1.6-.25,2.39a32.55,32.55,0,0,0-9.19-21.67c-8.17-8.21-19.9-11.4-31.12-13.08a28.51,28.51,0,0,1-13.1-5c-4.31-2.79-9.88-3.46-14.92-2.85a24.61,24.61,0,0,0-15.19,7.51c-5.33,5.86-7.64,14.16-13.86,19.1-3.77,3-8.55,4.4-12.94,6.44s-8.54,5-9.95,9.38c0,0,0-.06,0-.09l0,.25-.06.16c-1.46,5.18,1.36,10.45,2.83,15.62,1.53,5.35,1.63,11,1.71,16.53.11,6.76.21,13.53.1,20.3-.05,2.66-.14,5.35-.34,8a41.92,41.92,0,0,0-6.87,2.76c-2.24,1.46-10.62,10.51-10.62,10.51l-16.39,62.62.22.25-.22.85.83-.19c2.32,2.5,9.25,9.62,16.73,14.06l.7,12.28s.84,12.32,12.17,17.41c.26,4.27,1.07,21.61-2.68,28.48a32,32,0,0,0-3.54,16.28s1.31,10.42-.18,15.9a26,26,0,0,0-.19,11.16h0s0,1.21,0,3.29c0,11.09.13,46.63,0,50.65-.19,4.75,0,75,0,75s-.93,35.11-3.91,44.62-2.23,41-2.23,41-1.87,37.51,4.74,44.91c0,.33-.06.67-.07,1,0,.15,0,.32,0,.47-.08,2.85.47,5.88,2.92,6.81,5,1.92,11.61,7.68,12.86,9.33s8.52,5.76,18,4.66a135.5,135.5,0,0,1,17.89-.82h0s3.74-.68,2.53-5.33h0s0,0,0,0c-.78-2.9-3.7-7.36-5.78-10.29.38.1.75.18,1.1.25l.36.07.28,0a3.8,3.8,0,0,0,.46,0l.2,0a3.43,3.43,0,0,0,.56,0h0c2.51-.24,11.87,4.12,13.54,7s7.56,5.07,12,5.62c2.64.32,9.3-.22,14.89-.94a54.83,54.83,0,0,0,8.34-1.52c1.32-.5,1.6-2.1,1.22-3.9h0a10.15,10.15,0,0,0-3.46-5.84c-1.62-1.15-3.76-4.18-5.34-6.66l-.42-.67c2.79-2.66,7.83-11.36,9.36-13.16,1.86-2.19-3-82.28-3-82.28V695.32l7.45-38,5.21-20.11,4.47-30.36s7.82-35.46,5.41-38.94h0c0-.07-2-36.58-4.1-45.35-.91-3.91-.68-12.71-.14-21.27a4.2,4.2,0,0,0,1-4.38,9.1,9.1,0,0,0-.58-1.49c0-.15,0-.31,0-.46a68.86,68.86,0,0,1,13.47-4.58c7.45-1.46,5.59-5.3,5.59-5.3s1.68-3.29,2.79-5.3.19-19.75,0-21.21c-.07-.59-.53-3.85-1.06-7.55,2.39-1.7,5.5-3.81,8.89-5.81C570.08,441.39,568.63,437.36,568.1,436.31ZM470.9,689.84s-5.59,14.26-3.35,17.91-.37,17.2-.37,17.2l-1.87,20.11s-5.21,37.3-3.35,46.07c1.46,6.88,2,27.43,2.17,36h0a2.53,2.53,0,0,0-.37.18l-.25.13c.86-3.37.5-10.19-3.77-23.91l-.36-56.67s-.66-65.46,4.51-72.78,7-19.75,7-19.75-1.12,17.93-1.85,22.68S470.9,689.84,470.9,689.84ZM460.49,830.7c-.05.12-.11.24-.15.35l-.28-.36A2.94,2.94,0,0,0,460.49,830.7Z",
      transform: "translate(-15.95 -18.56)",
      fill: "url(#cb66075b-2ebe-455c-893b-1def13a8d59c)"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M517.5,853.16c-2.89,1.11-18.56,3-22.94,2.47s-10.18-2.75-11.83-5.65-10.9-7.28-13.38-7a9,9,0,0,1-3-.42,36.93,36.93,0,0,1-5-1.92,9.28,9.28,0,0,1,.11-3.8,6.09,6.09,0,0,1,.22-.74,6.61,6.61,0,0,1,3.36-3.74l.36-.17a10.17,10.17,0,0,1,2.16-.66c7.86-1.51,40.29,1.52,40.29,1.52s.91,1.63,2.16,3.65c1.56,2.5,3.68,5.55,5.28,6.7a10.25,10.25,0,0,1,3.41,5.88C519.08,851.05,518.8,852.67,517.5,853.16Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M517.5,853.16c-2.89,1.11-18.55,3-22.93,2.47s-10.18-2.76-11.84-5.65-10.89-7.28-13.37-7-8-2.34-8-2.34-.86-4,1.64-6.73l5,3.55s13.38,4.15,15.86,8,7,6,13.53,6.39c4.88.32,16.09-1.58,21.34-2.53C519.08,851.05,518.81,852.67,517.5,853.16Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M469.63,858.26a133.13,133.13,0,0,0-17.66.83c-9.39,1.1-16.56-3-17.81-4.69S426.44,847,421.47,845c-2.43-.94-3-4-2.89-6.86,0-.15,0-.32,0-.47a28,28,0,0,1,.8-5.37l38.91-.83,3.37,4.57.52.7,2.05,2.79s.93,1.22,2.15,3c2.06,3,4.94,7.43,5.71,10.36v0C473.32,857.58,469.63,858.26,469.63,858.26Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M469.63,858.26a133.13,133.13,0,0,0-17.66.83c-9.38,1.1-16.56-3-17.8-4.69s-7.73-7.45-12.7-9.38c-2.43-.94-3-4-2.89-6.86,2.78.65,8.62,2.31,10.91,5.2,3,3.86,8.37,10.35,16,10.76,6.16.33,21.16-.77,26.66-1.21C473.33,857.58,469.63,858.26,469.63,858.26Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M465,832.32c-.45,3.34-1.84,4.24-2.84,4.44a1.93,1.93,0,0,1-.74,0,2.46,2.46,0,0,1-.39-.06s-34.94,7.72-42,1.47a4.89,4.89,0,0,1-.5-.52,28,28,0,0,1,.8-5.37l38.91-.83,3.37,4.57a6.61,6.61,0,0,1,3.36-3.74Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M510,836.66c-.78.86-1.43,1.35-1.84,1.18-1.84-.74-16.92-3.31-21.71-1.1s-21,.36-21,.36,0-1.92-.09-5a10.17,10.17,0,0,1,2.16-.66c7.86-1.51,40.29,1.52,40.29,1.52S508.76,834.64,510,836.66Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M532.82,610.46,528.4,641l-5.14,20.24L515.9,699.5V740s4.78,80.58,2.94,82.78-8.83,14.73-10.67,14-16.92-3.31-21.71-1.11-21,.37-21,.37-.37-31.27-2.21-40.1,3.31-46.36,3.31-46.36l1.84-20.23s2.58-13.62.37-17.3,3.31-18,3.31-18-2.57-8.11-1.83-12.89,1.83-22.81,1.83-22.81-1.83,12.52-6.94,19.87-4.46,73.22-4.46,73.22l.36,57c9.21,30.18,0,27.23,0,27.23s-34.94,7.73-42,1.47S414,791.48,414,791.48s-.73-31.64,2.21-41.2,3.87-44.89,3.87-44.89-.19-70.65,0-75.42c.14-4,0-39.81,0-51,0-2.08,0-3.31,0-3.31l4.22-10.48,50-6.26h23.92s36,8.46,39.72,12.11a.83.83,0,0,1,.2.22C540.55,574.78,532.82,610.46,532.82,610.46Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M472.11,770.88s11,26.49,16.19,28.33S472.11,770.88,472.11,770.88Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M476.18,809.88s37.14,1.84,36.77,5.89S476.18,809.88,476.18,809.88Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M426.49,799.29c1.47,1.39,28.33,4,26.12,6.54s-23.91,7.48-23.91,7.48Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M422.08,753.59c0,1.1,5.52,35.32,7,36.79s13.61,2.94,13.61,2.94Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M462.13,285.85c-5.27,5.89-7.55,14.24-13.69,19.22-3.73,3-8.45,4.43-12.79,6.47s-8.64,5.15-9.93,9.77c-1.44,5.2,1.34,10.51,2.8,15.71,1.51,5.38,1.6,11,1.69,16.63.1,6.81.21,13.62.09,20.43-.18,10.61-1.06,21.71-6.69,30.7,20.33,6.47,41.95,7.35,63.27,8.18a63.84,63.84,0,0,0,12.29-.31A105.49,105.49,0,0,0,509.64,410a80.28,80.28,0,0,1,20.86-2.67c3.07,0,6.2.19,9.16-.61s5.81-2.85,6.61-5.81c.71-2.66-.33-5.49-1.69-7.88-2.48-4.36-6-8-8.66-12.3a33.8,33.8,0,0,1-2.17-30.39c2.36-5.49,6.16-10.27,8.48-15.77a33.26,33.26,0,0,0-6.7-35.28c-8.07-8.26-19.65-11.46-30.73-13.16a27.91,27.91,0,0,1-12.94-5c-4.25-2.8-9.76-3.48-14.74-2.86A24.06,24.06,0,0,0,462.13,285.85Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      opacity: "0.1",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M534.06,344.57a33.27,33.27,0,0,0-2.55,15.27A32.7,32.7,0,0,1,534.06,349c2.35-5.49,6.15-10.27,8.47-15.77a31.91,31.91,0,0,0,2.33-14.52,31.1,31.1,0,0,1-2.33,10.1C540.21,334.31,536.41,339.08,534.06,344.57Z",
        transform: "translate(-15.95 -18.56)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M430.51,352.29c.06,3.92.12,7.85.13,11.77,0-5.4-.05-10.79-.13-16.18-.08-5.59-.18-11.25-1.69-16.64-1-3.42-2.48-6.89-3-10.34-.89,4.9,1.64,9.87,3,14.76C430.33,341,430.43,346.7,430.51,352.29Z",
        transform: "translate(-15.95 -18.56)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M540,401c-3,.81-6.08.63-9.15.61A80.22,80.22,0,0,0,510,404.23a106.2,106.2,0,0,1-10.47,2.64,63.17,63.17,0,0,1-12.3.32c-20.6-.81-41.49-1.68-61.22-7.57a33.94,33.94,0,0,1-2,3.8c20.33,6.46,41.95,7.35,63.26,8.18a63.17,63.17,0,0,0,12.3-.32A103.41,103.41,0,0,0,510,408.65,80.22,80.22,0,0,1,530.81,406c3.07,0,6.19.19,9.15-.62s5.81-2.84,6.61-5.8a7.94,7.94,0,0,0-.1-4.16C545.58,398.22,542.83,400.17,540,401Z",
        transform: "translate(-15.95 -18.56)"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M510.38,389.15c-.74,1.66-3.86,16-4.6,17.47s-4.78,25-5.15,26.32S474,427.42,474,427.42l-15.81-13.25L441.94,398s-.48-14.59,11.49-19.27a18.27,18.27,0,0,1,2.5-.78c14.52-3.49,13.06-47.64,13.06-47.64l29.8,12.87s-5.52,25.76-5.33,30.73c.05,1.67,1.36,2.71,3.07,3.34a24.27,24.27,0,0,0,8.14.88S511.12,387.5,510.38,389.15Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fbbebe"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M563.73,437.53l4.23,1.11s3.13,4.76-4.23,9.19a127.48,127.48,0,0,0-13.43,9.39l-21.75,6.62-4.19-13.15,20.24-15.36Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M563.73,437.53l4.23,1.11s3.13,4.76-4.23,9.19a127.48,127.48,0,0,0-13.43,9.39l-21.75,6.62-4.19-13.15,20.24-15.36Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M405,450.23l-8.46,8.28s15.26,17.66,27,18.76,19.31-13.43,19.31-13.43l-10.16-16Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M405,450.23l-8.46,8.28s15.26,17.66,27,18.76,19.31-13.43,19.31-13.43l-10.16-16Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "469.41",
      cy: "311.17",
      r: "29.43",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "469.41",
      cy: "308.96",
      r: "29.43",
      fill: "#fbbebe"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M538.16,574.59A95,95,0,0,0,518.47,579c-11,3.66-97.2.06-98.4,0,0-2.08,0-3.31,0-3.31l4.22-10.48,50-6.26h23.92s36,8.46,39.72,12.11C538.08,573.26,538.16,574.59,538.16,574.59Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M510.38,389.15c-.74,1.66-3.86,16-4.6,17.47s-4.78,25-5.15,26.32S474,427.42,474,427.42l-15.81-13.25L441.94,398s-.48-14.59,11.49-19.27l29.72,34.17,13.38-35.65a24.27,24.27,0,0,0,8.14.88S511.12,387.5,510.38,389.15Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M483.15,414l-30.42-35a12.75,12.75,0,0,0-12.07-.89c-6.81,2.95-15.27,5.34-17.48,6.81s-10.49,10.57-10.49,10.57L437.35,460l-10.86,42.49s1.66,21.71-2.57,29.62a32.51,32.51,0,0,0-3.5,16.37s1.29,10.49-.18,16a26.65,26.65,0,0,0-.19,11.22s87.39,3.68,98.42,0a94.18,94.18,0,0,1,19.69-4.41s-2-36.8-4-45.63,1.66-42.49,1.66-42.49l-2.39-36.06,14.34-37S540,386.39,531.9,384c0,0-14.71-3.5-17.84-5.15s-12.33-3.13-12.33-3.13l-4.83,1.62Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "454.92",
      y: "443.61",
      width: "70.04",
      height: "107.18",
      rx: "2.94",
      ry: "2.94",
      transform: "translate(18.92 -50.67) rotate(3.89)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "457.13",
      y: "441.41",
      width: "70.04",
      height: "107.18",
      rx: "2.94",
      ry: "2.94",
      transform: "translate(18.77 -50.82) rotate(3.89)",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "461.6",
      y: "449.46",
      width: "61.02",
      height: "92.22",
      transform: "translate(18.81 -50.82) rotate(3.89)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "469.9",
      y: "471.21",
      width: "49.73",
      height: "13.86",
      transform: "matrix(1, 0.07, -0.07, 1, 17.63, -51.04)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "510.27",
      y: "529.92",
      width: "7.91",
      height: "7.24",
      transform: "translate(21.44 -52.23) rotate(3.89)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "469.94",
      y: "511.38",
      width: "40.49",
      height: "7.24",
      transform: "translate(20.13 -50.64) rotate(3.89)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "475.65",
      y: "446.75",
      width: "42.16",
      height: "11.13",
      transform: "translate(15.89 -51.23) rotate(3.89)",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "475.65",
      y: "446.75",
      width: "42.16",
      height: "11.13",
      transform: "translate(15.89 -51.23) rotate(3.89)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M486.83,572.56s-.37,54.46-14.72,85.73c0,0,17.3-41.21,17.3-42.86s9.56-18.95,7-24.1S486.83,572.56,486.83,572.56Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M487.61,320.16a20.47,20.47,0,0,1,3.33-13.71A16.89,16.89,0,0,0,504,324.25a2.21,2.21,0,0,1-.63-2.42c2.05,2.32,3.62,5.07,5.94,7.11s5.8,3.26,8.53,1.81c3.71-2,3.75-7.27,2.79-11.37a53.4,53.4,0,0,0-12.29-23.47,16.26,16.26,0,0,0-12.9-6.56c-5.68-.44-11.58.06-16.67,2.61a44.3,44.3,0,0,0-8,5.59l-14,11.42a13.29,13.29,0,0,0-3.4,3.58,9.8,9.8,0,0,0-1.06,3.75,20.21,20.21,0,0,0,9.42,19.07,14.91,14.91,0,0,1,8.93-14,3.88,3.88,0,0,1,1.39,2.89L475,319a5.79,5.79,0,0,1,2-2.37c1.82-1,4.09.18,5.64,1.59s3.06,3.17,5.14,3.39l.08-7.83",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M487.61,319.06a20.48,20.48,0,0,1,3.33-13.72c-.9,8,5.13,16.26,13.07,17.8a2.19,2.19,0,0,1-.63-2.41c2.05,2.32,3.62,5.06,5.94,7.11s5.8,3.26,8.53,1.8c3.71-2,3.75-7.27,2.79-11.36a53.4,53.4,0,0,0-12.29-23.47,19.67,19.67,0,0,0-6.87-5.34,20,20,0,0,0-6-1.22c-5.68-.44-11.58.05-16.67,2.6a44.86,44.86,0,0,0-8,5.6l-14,11.42a13.15,13.15,0,0,0-3.4,3.58,9.75,9.75,0,0,0-1.06,3.75,20.2,20.2,0,0,0,9.42,19.06,14.93,14.93,0,0,1,8.93-14,3.91,3.91,0,0,1,1.39,2.89l2.94-5.24a5.73,5.73,0,0,1,2-2.37c1.82-1,4.09.18,5.64,1.59s3.06,3.16,5.14,3.39l.08-7.84",
      transform: "translate(-15.95 -18.56)",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M501.55,504.69c-2.57-1.3-45.07,5.33-45.07,5.33s-7-2-23.92-4.78-18-19.32-18-19.32l-1.85-33.11,5.71-5,24.46,16s.38,8.09,0,9.55c-.24,1-.88,2.19-.82,3a1,1,0,0,0,.82.9c1.66.42,24.28,4.08,24.28,4.08s52.43-3.59,65.5,14.07a13.28,13.28,0,0,1,2.31,4.36C538.21,511.84,503.88,505.84,501.55,504.69Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fbbebe"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M535,499.84c-2,.89-3.24,1.53-3.24,1.53S513,500.82,502.46,497s-23.35-3.14-23.35-3.14S435.19,486.3,442,476.43a1,1,0,0,0,.82.9c1.66.42,24.28,4.08,24.28,4.08s52.43-3.59,65.5,14.07A13.28,13.28,0,0,1,535,499.84Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M553.24,441.58s2.58,18.21,2.76,19.69,1.11,19.31,0,21.34-2.76,5.33-2.76,5.33,1.84,3.86-5.52,5.34-16,5.88-16,5.88-18.77-.55-29.25-4.41-23.36-3.13-23.36-3.13-55.75-9.57-31.83-21.25,40.84,4.14,40.84,4.14l26.67-1.65s9.94-6.08,12.7-5.52a10.21,10.21,0,0,0,5.7-.92l.19-19.32Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fbbebe"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M418,396.88l-5.34-.28-16.18,63s17.47-4.42,25,0,21.34,5.33,21.34,5.33l-5.15-50.22Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M418,395.77l-5.34-.28-16.18,63s17.47-4.42,25,0,21.34,5.33,21.34,5.33l-5.15-50.22Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M540.37,409.57l7.35,1.66s18.77,27,20.24,28.51-7,7-10.49,7-20.6,2-25.57,6.62S529,434.73,529,434.2,535.17,419,535.17,419Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M540.37,408.47l7.35,1.65s18.77,27.05,20.24,28.52-7,7-10.49,7-20.6,2-25.57,6.62S529,433.63,529,433.1s6.21-15.25,6.21-15.25Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      opacity: "0.1",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M490.89,305.43a14.75,14.75,0,0,1,.05-2.3,20.47,20.47,0,0,0-3.08,7.55l0,2.32s0-.05,0-.08l0,.55c0,1.62,0,3.25-.05,4.87l-.14,0,0,.75c0-.26,0-.51-.05-.77-2-.32-3.43-2-4.92-3.34s-3.82-2.62-5.64-1.59a5.73,5.73,0,0,0-2,2.37L472.09,321a3.87,3.87,0,0,0-1.39-2.88,14.91,14.91,0,0,0-8.93,14,20.32,20.32,0,0,1-9.49-15.93,20.22,20.22,0,0,0,9.49,18.13,14.93,14.93,0,0,1,8.93-14,3.91,3.91,0,0,1,1.39,2.89l2.94-5.24a5.73,5.73,0,0,1,2-2.37c1.82-1,4.09.18,5.64,1.59s3.06,3.16,5.14,3.39q0-3.84.08-7.66A20.37,20.37,0,0,1,490.89,305.43Z",
        transform: "translate(-15.95 -18.56)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M487.51,315.5c.05-.68.13-1.36.23-2l.11-2.76A20.24,20.24,0,0,0,487.51,315.5Z",
        transform: "translate(-15.95 -18.56)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M517.85,327.43c-2.73,1.46-6.21.24-8.53-1.8s-3.89-4.79-5.94-7.11a2.21,2.21,0,0,0,.63,2.42c-.2,0-.39-.1-.58-.15,2,2.3,3.59,5,5.89,7s5.8,3.26,8.53,1.8,3.51-4.88,3.27-8.21C520.94,324,520,326.27,517.85,327.43Z",
        transform: "translate(-15.95 -18.56)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M503.37,320.77a17,17,0,0,1-12.46-14.86c-.57,7.85,5.35,15.72,13.1,17.23A2.2,2.2,0,0,1,503.37,320.77Z",
        transform: "translate(-15.95 -18.56)"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M983.61,484.21s-3.94-.55-3.94-6.28-2.82-16.46-2.82-16.46h0s-2.44-18.67-5.81-21.63-7.7-20.34-7.7-20.34-.74-9.43-2.25-11.46-3.55-7-6.56-14.09S939,382,939,382s-22.69-13.16-29.12-17.45h0a9.94,9.94,0,0,1-1.64-1.24c-1.12-1.46-6-1.49-6-1.49-.51-3.23-1-6.93-1.16-10.28,0-.36,0-.72,0-1.08a34.6,34.6,0,0,0,15.21-18.82c.12-.38.22-.77.33-1.16a3.25,3.25,0,0,0,2-1.76c.57-1.29.59-2.79,1.31-4,.84-1.42,2.44-2.18,3.7-3.24,3.18-2.71,4-7.26,3.85-11.39-.1-3.36-.64-6.74-.43-10.07,0-.28,0-.56.06-.84.06-.49.13-1,.22-1.48.49-2.48,1.56-4.82,2.16-7.28s.66-5.23-.74-7.35c-2.05-3.11-6.32-3.73-10.07-4-4.25-.36-8,.1-10.77-3.43a37.7,37.7,0,0,0-4.28-5.16c-.56-.52-6-3.85-6-4.06a24.31,24.31,0,0,0-17-1.31c-2.83.82-5.48,2.16-8.35,2.83-6.16,1.46-13.26-.12-18.5,3.41-2.92,2-4.67,5.19-6.31,8.28q-2,3.82-4.06,7.65c-2.22,4.19-4.46,8.45-5.39,13.09a22.19,22.19,0,0,0-.37,3.07v0c0,.37,0,.74,0,1.11,0,.16,0,.32,0,.48,0,.34,0,.68.06,1s0,.41.07.62.09.68.15,1,.18.89.3,1.32c0,.19.12.37.18.56s.22.67.35,1,.14.35.22.52c.15.35.33.69.51,1,.08.13.14.26.22.39a11.34,11.34,0,0,0,.92,1.34c2.13,2.67,5.29,4.37,7.62,6.87,0,.1,0,.2,0,.3,0,.27,0,.54,0,.82a34.23,34.23,0,0,0,15.68,27.9c0,.38.05.77.07,1.16a57.09,57.09,0,0,1-.11,8.9,4.22,4.22,0,0,0-3.32-1.48,4.76,4.76,0,0,0-1.28.11l-.09-.07h0v.09c-2.2.54-4.91,2.83-7.5,9.34,0,0-7.88,8.88-13.88,8.51s-21.19,9.25-21.19,9.25-14.82,9.61-18,19.41a135.69,135.69,0,0,1-6.39,16.28l-18.37,37.72h0l-3.37,30s1.87,13.31,1.5,15.35,7.69,20.34,7.69,20.34,26.63,46.78,37.51,49.18l.78-.54a6.81,6.81,0,0,0,1.47.54l2.24-1.57a23.41,23.41,0,0,1-.18,5.27c-1.49,4.63.57,34.77,3.19,40.68s1.69,83.41,1.69,83.41l-.37,6.83s0,.22.09.6l-.09,1.62.27.14a19.33,19.33,0,0,1-.27,6.52c-.94,3-1.32,11.47-1.32,11.47s-7.5,47.88-3.94,57.5,6.57,20.16,6.57,20.16,3.75,12,.18,14-13.68,5.55-11.62,10.54c1.9,4.62,9.11,17,10.18,18.81l-.09,1-1.47,15.93a20,20,0,0,0,1.69,6.08c1.61,3.48,4.73,7.07,10.69,6.68,1-.07,2.15-.18,3.28-.33,10.89-1.47,24.29-6.33,24.29-6.33a9.58,9.58,0,0,1-1.89-1.57h0a5.49,5.49,0,0,1-1.67-4c.16-2.91-5.27-16.72-6.63-20.13l-.31-.76s12.38-12.95,10.32-24.41c0,0-13.7-8-9.19-12.4s12.57-17,12.57-17,.37-47.15,0-54.18a58.4,58.4,0,0,1,.69-14.64c.15-.72.33-1.43.52-2.14a127.74,127.74,0,0,0,18.86,1.43q3.46,0,7-.14,0,1,.09,2.16c.52,11.68,1.49,32.17,2.28,39.78,1.12,10.9,7.31,40.31,7.31,40.31s-11.81,7.57,2.06,26.26c0,0,0,6.76-.92,7.75h0a84.62,84.62,0,0,0-2.37,9.77c-.58,3.51-.82,7.08.12,8.92,2.25,4.42,15.75,4.06,15.75,4.06h0a2.13,2.13,0,0,1,.33-.05,19.27,19.27,0,0,1,14.29,4.3c5.13,4.12,24.59,2.32,35.14,1,4.13-.53,6.89-1,6.89-1a4.05,4.05,0,0,0,.14-1.44h0c-.11-2.59-2.14-8.27-15.9-13.34,0,0-12.94-8.7-12.76-16.28h-.29l-1.49,0C946.34,835,947,835,947,835s-5.07-18.49-3-20-4.13-22-4.13-22-3.55-34.4-3.75-36.8a21.14,21.14,0,0,1,.94-6.1l-.94-18.87s-.18-6.27,0-8.31a39.08,39.08,0,0,0-.42-5.29c-.09-.7-.18-1.43-.28-2.15,4.85-1.23,8-2.36,8-2.36l-.56-65.65c4.12-8,4.88-25.56,4.86-38,0-8-.36-13.92-.36-13.92l5.63-9.19s1.3-11-.76-13.41c-.91-1.09-.5-2.22.25-3.15a10.46,10.46,0,0,1,1.25-.88,1.57,1.57,0,0,1-.13-.22,9.94,9.94,0,0,1,1.25-.89s-2-3.1-.21-4.41c1.68,1.14,3.18,2.05,4.32,2.7-.08.73-.16,1.15-.16,1.15l.48-1c1.1.62,1.77,1,1.77,1s8.82-17.57,8.63-20.15,6-13.5,6-13.5.75-5.74,4.13-8.14,2.62-19.79,2.62-19.79.94-9.06,3.19-12.75S983.61,484.21,983.61,484.21ZM814.85,476.5l.17,4.19c-1-1.61-1.72-2.76-1.72-2.76Z",
      transform: "translate(-15.95 -18.56)",
      fill: "url(#b7415561-023b-44da-badb-9b3453976a8a)"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M961.57,559.65l-2.16,9.2S942.11,560,939,548.8s5.21-15.47,5.21-15.47l16.13,6.82Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M961.57,559.65l-2.16,9.2S942.11,560,939,548.8s5.21-15.47,5.21-15.47l16.13,6.82Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M864.48,872.76s-16,5.88-27,6.62c-5.84.39-8.91-3.19-10.49-6.64a20.3,20.3,0,0,1-1.66-6l1.45-15.85.76-8.43,23.37-6.08,3.31,10.13.31.76c1.32,3.39,6.66,17.13,6.5,20a5.49,5.49,0,0,0,1.63,4A9.29,9.29,0,0,0,864.48,872.76Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M973.72,864.7a4,4,0,0,1-.14,1.44s-34.22,5.7-41.22,0A18.53,18.53,0,0,0,918,861.91s-13.24.36-15.45-4c-.92-1.83-.68-5.38-.11-8.87a85.07,85.07,0,0,1,2.32-9.72l.53-.42,3.15-2.53,36.88-1.09h.28c-.18,7.54,12.51,16.19,12.51,16.19C971.62,856.47,973.61,862.12,973.72,864.7Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M973.73,864.7a4.12,4.12,0,0,1-.15,1.44s-34.22,5.7-41.21,0A18.53,18.53,0,0,0,918,861.91s-13.25.36-15.46-4c-.91-1.83-.68-5.38-.11-8.88,5.1.51,13.15,1.78,16.31,4.82,4.78,4.6,12.88,9.2,17.84,9.57C940.5,863.66,963.81,864.4,973.73,864.7Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M864.48,872.76s-16,5.88-27,6.62c-5.84.39-8.91-3.19-10.49-6.64,4.08,1.37,9.73,2.8,12.7,1.49,3.52-1.57,16-2.57,23-3A9.09,9.09,0,0,0,864.48,872.76Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M888.22,398.87c-13.2-5.13-30.18-22.08-25.94-30a17.93,17.93,0,0,0,1.65-6.36,58.05,58.05,0,0,0,.12-9,123.6,123.6,0,0,0-1.77-14.65s41.21.93,38.81,7c-.7,1.79-.82,4.88-.62,8.33s.69,7.38,1.21,10.69c.71,4.53,1.44,8,1.44,8s-2.53,3.53-4,3.72S907.16,406.22,888.22,398.87Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#cf6f80"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M854.49,847.22l-.31.34c-12.32-14.9-27.22,3.68-27.22,3.68l-.22-.4.76-8.43,23.37-6.08,3.31,10.13Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M945.62,836.33s-9-.18-13.8,4.06-28,.91-27,0a3.46,3.46,0,0,0,.52-1.53l3.15-2.53,36.88-1.09C945.51,835.94,945.62,836.33,945.62,836.33Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M869.82,719.32a28.05,28.05,0,0,0-1.52,5.13,58.71,58.71,0,0,0-.69,14.56c.37,7,0,53.91,0,53.91s-7.91,12.51-12.33,16.92,9,12.33,9,12.33c2,11.41-10.12,24.29-10.12,24.29-12.32-14.9-27.22,3.67-27.22,3.67s-8.1-14-10.12-19,7.91-8.45,11.4-10.49-.18-14-.18-14-2.94-10.49-6.44-20.06,3.86-57.2,3.86-57.2.38-8.47,1.29-11.42a19.34,19.34,0,0,0,.27-6.48c-.06-.73-.13-1.33-.18-1.75s-.09-.6-.09-.6l.14-.24,5-9.32S872.22,713.45,869.82,719.32Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M945.62,835.23s-9-.19-13.8,4-28,.92-27,0,.91-7.72.91-7.72c-13.61-18.59-2-26.13-2-26.13s-6.07-29.25-7.17-40.1c-.77-7.57-1.72-28-2.23-39.57-.22-5-.35-8.45-.35-8.45L905,715.07l1.43-.28,26.82-5.39s.74,5,1.24,9.09a39.94,39.94,0,0,1,.41,5.27c-.17,2,0,8.27,0,8.27l.92,18.76a21.64,21.64,0,0,0-.92,6.07c.19,2.4,3.68,36.61,3.68,36.61s6.07,20.42,4,21.89S945.62,835.23,945.62,835.23Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M901.09,345.89c-.7,1.79-.82,4.88-.62,8.33a34.25,34.25,0,0,1-36.42-.68,123.6,123.6,0,0,0-1.77-14.65S903.49,339.82,901.09,345.89Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M917,323.81a34.21,34.21,0,0,1-68.42.82c0-.28,0-.54,0-.82a34.22,34.22,0,0,1,68.44,0Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#cf6f80"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M888.22,398.87c-13.2-5.13-30.18-22.08-25.94-30a17.93,17.93,0,0,0,1.65-6.36L882,377.37l11.18,9.17,8.5-21.63c.71,4.53,1.44,8,1.44,8s-2.53,3.53-4,3.72S907.16,406.22,888.22,398.87Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "919 445.98 903.91 699.48 884.23 700.77 833.26 553.78 841.62 379.27 843.39 342.4 866.05 361.01 877.23 370.18 885.98 347.91 902.25 362.09 919 445.98",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M869.82,719.32a28.05,28.05,0,0,0-1.52,5.13A145,145,0,0,1,827,711.56l-.27-.14.09-1.61,0-.84,5-9.32S872.22,713.45,869.82,719.32Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M905.33,724.49a101.29,101.29,0,0,1-11.06,1.27c-.22-5-.35-8.45-.35-8.45L905,715.07Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M934.53,718.49c-7.11,1.85-18.1,3.93-27.92,2.63l-.14-6.33,26.82-5.39S934,714.36,934.53,718.49Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M906.43,722.28c-41,7-78.55-13.07-78.55-13.07l.36-6.8s.93-77.09-1.65-83S822,583.57,823.46,579s-5.33-73.57-5.33-73.57l-1.1-28-40.29-16.37,18-37.53A135.61,135.61,0,0,0,801,407.33c3.13-9.75,17.66-19.32,17.66-19.32s14.9-9.56,20.79-9.2,13.61-8.46,13.61-8.46c5.7-14.53,10.86-8,10.86-8,0,.7,0,0-.28,2.15-2,15.95,32.34,66.35,32.83,67.25h0l3.31,79.66,3.31,100.81Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M905.33,722.28c-41,7-78.56-13.07-78.56-13.07l.37-6.8s.92-77.09-1.66-83-4.59-35.87-3.12-40.48S817,505.39,817,505.39l-1.11-28-40.28-16.37,18-37.53a137.73,137.73,0,0,0,6.26-16.19C803,397.58,817.58,388,817.58,388s14.9-9.56,20.78-9.2S852,370.35,852,370.35c5.71-14.53,12-8,12-8,0,.7-.6,1-.28,2.15,4.4,15.47,31.24,66.35,31.73,67.25h0l3.31,79.66L902,612.27Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M894.28,434c-4.41-1.84-27.77-28.51-27.77-28.51v-6.07c-.85-2-5.91-.78-10,.62l1.76-36.87,2,1.66C864.64,380.29,893.8,433.11,894.28,434Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M895.39,431.8c-4.42-1.85-27.78-28.51-27.78-28.51v-6.08c-.85-2-5.9-.78-10,.62L859.34,361l2,1.65C865.75,378.09,894.9,430.9,895.39,431.8Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M827.88,564.8c.55,0,28.51-2.94,28.51-2.94s16.93,33.3,15.82,41.39-3.12,15.27-9.93,14-36.65,1-36.65,1Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M826.77,562.59c.56,0,28.52-2.94,28.52-2.94S872.21,593,871.11,601s-3.13,15.27-9.93,14-36.66,1-36.66,1Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M847.84,547s25.66,13.8,26.21,18-13.06-1.84-16-2.58a38.14,38.14,0,0,0-5.89-.92l-19.61.53Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#cf6f80"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "871.16",
      cy: "414.46",
      r: "2.7",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "871.16",
      cy: "413.36",
      r: "2.7",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "876.13",
      cy: "531.34",
      r: "2.7",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "876.13",
      cy: "530.23",
      r: "2.7",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "873.86",
      cy: "472.9",
      r: "2.7",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
      cx: "873.86",
      cy: "471.8",
      r: "2.7",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M952.05,560.94s1.84,2.76,0,4,.18,4.42.18,4.42-4.59,2.68-2.57,5.11.74,13.34.74,13.34L944.88,597s.33,5.89.35,13.85c0,12.42-.73,29.88-4.77,37.84L941,714s-19.33,7.07-35.51,4.91l-2.4-104.8s3.5-59.43,4.79-70.83a118.65,118.65,0,0,0,.92-17.85s-.55-17.84-2.4-26.11c0,0-2-35.88-2.2-45.81-.09-4.75.16-18.61.44-31.79.31-14.41.66-28,.66-28l-3.65-28.89s3.65-.36,4.75,1.1a10.53,10.53,0,0,0,1.6,1.23h0c6.31,4.26,28.57,17.36,28.57,17.36s12.32,4.9,15.27,11.92,5,12,6.43,14,2.21,11.4,2.21,11.4,4.24,17.3,7.55,20.23,5.69,21.53,5.69,21.53l-29.25,23s-2.57,38.26-3.12,39.74S952.05,560.94,952.05,560.94Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M953.16,560.94s1.83,2.76,0,4,.17,4.42.17,4.42-4.59,2.68-2.57,5.11.74,13.34.74,13.34L946,597s.33,5.89.36,13.85c0,12.42-.73,29.88-4.77,37.84l.55,65.31s-19.33,7.07-35.51,4.91l-2.39-104.8s3.49-59.43,4.79-70.83a117.56,117.56,0,0,0,.91-17.85s-.55-17.84-2.39-26.11c0,0-2-35.88-2.21-45.81-.09-4.75.16-18.61.44-31.79.31-14.41.66-28,.66-28l-4.82-29.28s4.82,0,5.93,1.49a9.49,9.49,0,0,0,1.6,1.23h0c6.3,4.26,28.56,17.36,28.56,17.36S950,389.42,953,396.44s5,12,6.43,14,2.21,11.4,2.21,11.4,4.24,17.3,7.55,20.23,5.7,21.53,5.7,21.53l-29.25,23s-2.57,38.26-3.13,39.74S953.16,560.94,953.16,560.94Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M918.13,402.21l2.65,7.7-13.91,14c.31-14.41.66-28,.66-28l-4.82-29.27s4.82,0,5.93,1.49a9.49,9.49,0,0,0,1.6,1.23h0l11.82,34.09Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M917,400l2.65,7.69-13.9,14c.3-14.41.66-28,.66-28l-4.83-29.28s4.83,0,5.93,1.49a10,10,0,0,0,1.6,1.23h0L921,401.25Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M917,323.81a34.11,34.11,0,0,1-1.68,10.61,1.42,1.42,0,0,1-1.08-.26c-.27-9-4.69-17.46-10.14-24.65a26.11,26.11,0,0,0-5.5-5.7,10.77,10.77,0,0,0-7.46-2.11c-3,.41-5.65,2.45-8.68,2.71-4,.33-7.58-2.44-11.55-2.57a11.32,11.32,0,0,0-8.49,3.94,23.16,23.16,0,0,0-4.55,8.43,49.38,49.38,0,0,0-2.54,14.56c-.05,2.8-.32,6.31-2.92,7.33a14.9,14.9,0,0,0-3.77-11.4l-.06-.07c0-.28,0-.54,0-.82a34.22,34.22,0,0,1,68.44,0Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M897,269.48a23.56,23.56,0,0,0-16.62-1.3c-2.77.82-5.38,2.15-8.19,2.82-6,1.45-13-.12-18.15,3.39-2.86,2-4.58,5.16-6.18,8.24l-4,7.61c-2.18,4.17-4.38,8.41-5.29,13s-.36,9.73,2.55,13.43c2.11,2.68,5.25,4.37,7.55,6.9A15,15,0,0,1,852.43,335c2.6-1,2.86-4.53,2.92-7.33a49.44,49.44,0,0,1,2.54-14.56,23.16,23.16,0,0,1,4.55-8.43,11.33,11.33,0,0,1,8.49-3.95c4,.14,7.59,2.91,11.55,2.57,3-.25,5.66-2.29,8.68-2.7a10.72,10.72,0,0,1,7.46,2.11,25.62,25.62,0,0,1,5.49,5.7c5.46,7.2,9.89,15.62,10.15,24.65,1.13.82,2.76-.26,3.32-1.54s.58-2.78,1.29-4c.82-1.41,2.39-2.17,3.62-3.23,3.12-2.69,3.9-7.22,3.78-11.33s-.92-8.28-.14-12.32c.47-2.47,1.53-4.8,2.11-7.25s.65-5.2-.72-7.31c-2-3.09-6.21-3.71-9.88-4-4.17-.36-7.9.1-10.56-3.41a39.09,39.09,0,0,0-4.2-5.14C902.33,273,897,269.7,897,269.48Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#512e4e"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M788.28,480.36l-10.44-19.31-3.31,29.8s1.84,13.24,1.47,15.27,7.54,20.23,7.54,20.23,26.13,46.55,36.8,48.94l36-25.76-9.56-12.14s-3.31-1.29-4.14,0c0,0-17.76-30.54-19.59-32.74s-1.48-6.63-1.48-6.63-2.76-2.94-1.84-5.7S814.45,480,814.45,480l5.7-5.33Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M778.39,458.84l-2.76,2.21-3.31,29.8s1.84,13.24,1.47,15.27,7.55,20.23,7.55,20.23,26.12,46.55,36.79,48.94l36.06-25.76-9.57-12.14s-3.31-1.29-4.14,0c0,0-17.75-30.54-19.59-32.74s-1.47-6.63-1.47-6.63-2.76-2.94-1.84-5.7S812.24,480,812.24,480l5.7-5.33Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M949.66,575.62c2,2.43.74,13.35.74,13.35l-5.52,9.13s.33,5.9.35,13.86l-9.28,2.9a5.52,5.52,0,0,1-7.16-5.44l1.61-51.6,21.65,8.27c-1.84,1.28.18,4.42.18,4.42S947.64,573.19,949.66,575.62Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M950.76,574.52c2,2.42.74,13.34.74,13.34L946,597s.33,5.89.36,13.85l-9.45,2.95a5.39,5.39,0,0,1-7-5.31l1.61-51.78L953.16,565c-1.85,1.28.17,4.42.17,4.42S948.74,572.09,950.76,574.52Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M957.94,549.9s-1.47,9.39-5.15,9.94-5.33,15.19-9,14.68-1.24-13.62-1.11-16.16-4-13.06-.92-15.45,12.88,0,12.88,0Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#cf6f80"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M965.72,477.6l6.93-14s2.77,10.67,2.77,16.37,3.86,6.26,3.86,6.26,4.23,5,2,8.65-3.12,12.69-3.12,12.69.73,17.29-2.58,19.68-4.05,8.1-4.05,8.1-6.07,10.85-5.88,13.43-8.46,20.05-8.46,20.05,4.23-21.71-20.42-31.09c0,0-.19-7.36,1.65-9.38s4.71-3,2.91-13.16-.52-22.41-.52-24.86,5.52-17.72,5.52-17.72Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M968.8,461.6l6.06,2s2.77,10.67,2.77,16.37,3.86,6.26,3.86,6.26,4.23,5,2,8.65-3.13,12.69-3.13,12.69.74,17.29-2.57,19.68-4,8.1-4,8.1-6.07,10.85-5.88,13.43-8.47,20.05-8.47,20.05,4.23-21.71-20.42-31.09c0,0-.18-7.36,1.66-9.38s4.71-3,2.91-13.16-.52-22.41-.52-24.86,5.52-17.72,5.52-17.72Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#fff"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M834.92,824.47s9.66-6.07,16-1.66S834.92,824.47,834.92,824.47Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M910,805.7s8.55-1.1,15.73,6.63S910,805.7,910,805.7Z",
      transform: "translate(-15.95 -18.56)",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      opacity: "0.1",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M922.49,322.09c-1.23,1.07-2.81,1.82-3.63,3.23-.7,1.21-.72,2.71-1.28,4s-2.19,2.36-3.33,1.54c-.26-9-4.69-17.45-10.14-24.65a25.57,25.57,0,0,0-5.49-5.69,10.75,10.75,0,0,0-7.47-2.12c-3,.41-5.64,2.45-8.67,2.71-4,.33-7.59-2.44-11.56-2.57a11.28,11.28,0,0,0-8.48,3.94,23.16,23.16,0,0,0-4.55,8.43,49.44,49.44,0,0,0-2.54,14.56c-.06,2.79-.32,6.27-2.9,7.31a13.84,13.84,0,0,1,0,2.23c2.61-1,2.87-4.53,2.93-7.33a49.44,49.44,0,0,1,2.54-14.56,23.16,23.16,0,0,1,4.55-8.43,11.32,11.32,0,0,1,8.48-3.95c4,.14,7.6,2.91,11.56,2.57,3-.25,5.66-2.29,8.67-2.7a10.75,10.75,0,0,1,7.47,2.11,25.62,25.62,0,0,1,5.49,5.7c5.45,7.2,9.88,15.62,10.14,24.65,1.14.82,2.77-.26,3.33-1.54s.58-2.78,1.28-4c.82-1.41,2.4-2.17,3.63-3.23,3.12-2.69,3.9-7.22,3.78-11.33,0-.13,0-.25,0-.38C926.1,316.17,925.15,319.8,922.49,322.09Z",
        transform: "translate(-15.95 -18.56)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M848.66,321.39c-2.29-2.53-5.43-4.23-7.54-6.91a14.51,14.51,0,0,1-2.91-8.18,15.41,15.41,0,0,0,2.91,10.39c2.11,2.68,5.25,4.37,7.54,6.9a15,15,0,0,1,3.78,8.92A15,15,0,0,0,848.66,321.39Z",
        transform: "translate(-15.95 -18.56)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M928.24,291.19c-.59,2.45-1.64,4.78-2.12,7.25a23.15,23.15,0,0,0-.31,5.06,19.41,19.41,0,0,1,.31-2.85c.48-2.47,1.53-4.8,2.12-7.25a12.56,12.56,0,0,0,.33-4.14A13.9,13.9,0,0,1,928.24,291.19Z",
        transform: "translate(-15.95 -18.56)"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("ellipse", {
      cx: "132.73",
      cy: "823.23",
      rx: "97.44",
      ry: "15.65",
      fill: "currentColor",
      opacity: "0.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("rect", {
      x: "129.6",
      y: "523.42",
      width: "6.27",
      height: "141.17",
      fill: "#535461"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M191.23,682.73l-.4,6.36-.55,9-.23,3.74-.56,9-.24,3.74-.55,9-6.33,102.07a17.28,17.28,0,0,1-17.25,16.22H132.25A17.27,17.27,0,0,1,115,825.57L108.67,723.5l-.55-9-.23-3.74-.57-9-.23-3.74-.55-9-.4-6.36a9,9,0,0,1,8.94-9.51H182.3A9,9,0,0,1,191.23,682.73Z",
      transform: "translate(-15.95 -18.56)",
      fill: "#3f3d56"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "174.88 670.52 174.32 679.5 91.14 679.5 90.58 670.52 174.88 670.52",
      fill: "#9d9cb5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "174.09 683.24 173.54 692.22 91.93 692.22 91.37 683.24 174.09 683.24",
      fill: "#9d9cb5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("polygon", {
      points: "173.3 695.97 172.75 704.94 92.72 704.94 92.16 695.97 173.3 695.97",
      fill: "#9d9cb5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M97,594.9c36.52,26.42,51.73,67.74,51.73,67.74s-44-1.51-80.53-27.93S16.44,567,16.44,567,60.44,568.48,97,594.9Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M16.44,567s45.67,25.35,60.32,46.34,71.93,49.32,71.93,49.32",
      transform: "translate(-15.95 -18.56)",
      fill: "none",
      stroke: "#535461",
      strokeMiterlimit: "10",
      strokeWidth: "2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M120.53,541.68c19.88,14.37,28.16,36.86,28.16,36.86s-24-.82-43.83-15.19S76.7,526.48,76.7,526.48,100.66,527.3,120.53,541.68Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M76.7,526.48s24.86,13.8,32.84,25.22,39.15,26.84,39.15,26.84",
      transform: "translate(-15.95 -18.56)",
      fill: "none",
      stroke: "#535461",
      strokeMiterlimit: "10",
      strokeWidth: "2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M177.57,577.4c-22.83,25.09-27.66,57.88-27.66,57.88s32.19-7.9,55-33,27.66-57.88,27.66-57.88S200.4,552.31,177.57,577.4Z",
      transform: "translate(-15.95 -18.56)",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M232.59,544.41s-29.74,25.72-37.3,43.44-45.38,47.43-45.38,47.43",
      transform: "translate(-15.95 -18.56)",
      fill: "none",
      stroke: "#535461",
      strokeMiterlimit: "10",
      strokeWidth: "2"
    })]
  }));
}
// EXTERNAL MODULE: ./src/components/Service.jsx
var Service = __webpack_require__("fIVH");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// CONCATENATED MODULE: ./src/components/Gallery.jsx




function GalleryList({
  text,
  slug,
  image
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
    href: `/layanan/${slug}`,
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("a", {
      className: "p-2",
      title: text,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "ratio-1-1",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "rounded-xl absolute top-0 left-0 w-full h-full flex justify-center items-center",
          children: image ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
            unoptimized: true,
            alt: text,
            src: image,
            width: 500,
            height: 500,
            objectFit: "contain",
            className: "w-full h-full rounded-xl"
          }) : null
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "text-center mt-2 text-grayscale-800 arimo font-bold",
        children: text
      })]
    })
  });
}
function GalleryContainer({
  children
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "grid grid-flow-row gap-8 md:gap-5 lg:gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-4 mt-16",
    children: children
  });
}
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// CONCATENATED MODULE: ./src/images/Instagram.js



function Instagram_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Instagram_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Instagram_ownKeys(Object(source), true).forEach(function (key) { Instagram_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Instagram_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Instagram_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Instagram(_ref) {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", Instagram_objectSpread(Instagram_objectSpread({
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    x: "0px",
    y: "0px",
    width: "169.063px",
    height: "169.063px",
    viewBox: "0 0 169.063 169.063",
    xmlSpace: "preserve"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M122.406,0H46.654C20.929,0,0,20.93,0,46.655v75.752c0,25.726,20.929,46.655,46.654,46.655h75.752\r c25.727,0,46.656-20.93,46.656-46.655V46.655C169.063,20.93,148.133,0,122.406,0z M154.063,122.407\r c0,17.455-14.201,31.655-31.656,31.655H46.654C29.2,154.063,15,139.862,15,122.407V46.655C15,29.201,29.2,15,46.654,15h75.752\r c17.455,0,31.656,14.201,31.656,31.655V122.407z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M84.531,40.97c-24.021,0-43.563,19.542-43.563,43.563c0,24.02,19.542,43.561,43.563,43.561s43.563-19.541,43.563-43.561\r C128.094,60.512,108.552,40.97,84.531,40.97z M84.531,113.093c-15.749,0-28.563-12.812-28.563-28.561\r c0-15.75,12.813-28.563,28.563-28.563s28.563,12.813,28.563,28.563C113.094,100.281,100.28,113.093,84.531,113.093z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M129.921,28.251c-2.89,0-5.729,1.17-7.77,3.22c-2.051,2.04-3.23,4.88-3.23,7.78c0,2.891,1.18,5.73,3.23,7.78\r c2.04,2.04,4.88,3.22,7.77,3.22c2.9,0,5.73-1.18,7.78-3.22c2.05-2.05,3.22-4.89,3.22-7.78c0-2.9-1.17-5.74-3.22-7.78\r C135.661,29.421,132.821,28.251,129.921,28.251z"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {})]
  }));
}
// CONCATENATED MODULE: ./src/images/Facebook.js



function Facebook_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Facebook_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Facebook_ownKeys(Object(source), true).forEach(function (key) { Facebook_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Facebook_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Facebook_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Facebook(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", Facebook_objectSpread(Facebook_objectSpread({
    version: "1.1",
    id: "Capa_1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    x: "0px",
    y: "0px",
    viewBox: "0 0 155.139 155.139",
    xmlSpace: "preserve"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        id: "f_1_",
        d: "M89.584,155.139V84.378h23.742l3.562-27.585H89.584V39.184\r c0-7.984,2.208-13.425,13.67-13.425l14.595-0.006V1.08C115.325,0.752,106.661,0,96.577,0C75.52,0,61.104,12.853,61.104,36.452\r v20.341H37.29v27.585h23.814v70.761H89.584z"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {})]
  }));
}
// EXTERNAL MODULE: ./src/images/IconCentre.js + 10 modules
var IconCentre = __webpack_require__("TqjF");

// EXTERNAL MODULE: ./src/service.js
var service = __webpack_require__("ul+n");

// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__("a6qw");

// EXTERNAL MODULE: external "react-responsive-carousel"
var external_react_responsive_carousel_ = __webpack_require__("KaAA");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// CONCATENATED MODULE: ./src/components/Embed.js


function Embed({
  refId
}) {
  Object(external_react_["useEffect"])(() => {
    (function (d, s, id) {
      var js;

      if (d.getElementById(id)) {
        return;
      }

      js = d.createElement(s);
      js.id = id;
      js.src = "https://embedsocial.com/cdn/ht.js";
      d.getElementsByTagName("head")[0].appendChild(js);
    })(document, "script", "EmbedSocialHashtagScript");
  }, []);
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "embedsocial-hashtag",
    "data-ref": refId
  });
}
// CONCATENATED MODULE: ./pages/index.js



















 // requires a loader




const getServerSideProps = async () => {
  var _basicInformation$des;

  let basicInformation, kelebihan, services, subServices, gallery, pages, slider;

  try {
    basicInformation = (await service["a" /* default */].get("/basic-information")).data.success.data;
    services = (await service["a" /* default */].get("/post/layanan?limit=100")).data.success.data.rows;
    subServices = (await service["a" /* default */].get("/post/sub-layanan?limit=100&nodesc=1")).data.success.data.rows;
    kelebihan = (await service["a" /* default */].get("/post/kelebihan")).data.success.data.rows;
    slider = (await service["a" /* default */].get("/post/slider")).data.success.data.rows;
    pages = (await service["a" /* default */].get("/post/halaman?limit=100&nodesc=1")).data.success.data.rows;
    gallery = (await service["a" /* default */].get("/gallery/type/layanan?limit=8")).data.success.data.rows;
  } catch (e) {
    console.log(e);
    return {
      props: {
        status: 500
      }
    };
  }

  return {
    props: {
      basicInformation,
      kelebihan,
      services,
      subServices,
      gallery,
      pages,
      headerProps: {
        transparentFirst: true
      },
      slider,
      metaTag: [{
        name: "description",
        content: ((_basicInformation$des = basicInformation.description) === null || _basicInformation$des === void 0 ? void 0 : _basicInformation$des.substr(0, 150)) || ""
      }]
    }
  };
};
function Home({
  basicInformation,
  kelebihan,
  services,
  gallery,
  pages,
  slider
}) {
  var _basicInformation$log;

  const counter = Object(external_react_["useRef"])(0);
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(head_default.a, {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
        children: basicInformation.clinicName
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Background, {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 hidden lg:block",
      fill: tailwind_config["theme"].colors.background
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(BackgroundMobile, {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 block lg:hidden",
      fill: tailwind_config["theme"].colors.background
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "h-screen relative",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container["a" /* default */], {
        className: "text-grayscale-800 z-10 flex items-center h-full relative",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: "lg:w-1/2",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Welcome, {
            className: "text-primary-100 mb-5 w-1/2 md:w-1/3 lg:w-2/4 mx-auto lg:mx-0 h-auto"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("h1", {
            className: "font-bold text-xl lg:text-2xl xl:text-3xl poppins mb-3 text-center lg:text-left text-grayscale-800",
            children: "Selamat Datang!"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("h2", {
            className: "text-grayscale-700 text-center lg:text-left",
            children: basicInformation.welcomeText
          })]
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "absolute right-0 z-10 top-0 bottom-0 items-center pt-16 hidden lg:flex w-64",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: "lg:p-2 xl:p-5 bg-grayscale-100 shadow-lg rounded-lg",
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_responsive_carousel_["Carousel"], {
              showThumbs: false,
              showStatus: false,
              autoPlay: true,
              infiniteLoop: true,
              interval: 3000,
              swipeable: true,
              showArrows: false,
              children: slider === null || slider === void 0 ? void 0 : slider.map((item, index) => {
                var _item$thumbnail;

                return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
                    unoptimized: true,
                    src: ((_item$thumbnail = item.thumbnail) === null || _item$thumbnail === void 0 ? void 0 : _item$thumbnail.replace("public", "https://admin.zaharadental.com")) || "/images/dentist.jpg",
                    alt: item.title,
                    width: 240,
                    height: 320,
                    className: "rounded-lg",
                    objectFit: "cover"
                  })
                }, `${index}`);
              })
            })
          })
        })]
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "bg-grayscale-100 py-10",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container["a" /* default */], {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Mengapa Memilih Klinik Kami?"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(WhyChooseContainer, {
          children: kelebihan === null || kelebihan === void 0 ? void 0 : kelebihan.map((item, index) => {
            if (counter.current + 1 > 4) {
              counter.current = 1;
            } else {
              counter.current = counter.current + 1;
            }

            return /*#__PURE__*/Object(jsx_runtime_["jsx"])(WhyChooseList, {
              icon: IconCentre["a" /* default */][item.thumbnail || "default"],
              title: item.title,
              right: counter.current > 2,
              children: item.text
            }, `${index}`);
          })
        })]
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "py-16",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container["a" /* default */], {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Our Services"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Service["b" /* default */], {
          className: "mt-16",
          children: services === null || services === void 0 ? void 0 : services.map((item, index) => /*#__PURE__*/Object(jsx_runtime_["jsx"])(Service["a" /* ServiceList */], {
            icon: IconCentre["a" /* default */][item.thumbnail || "default"],
            name: item.title,
            slug: item.slug
          }, `${index}`))
        })]
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "py-20 bg-grayscale-100",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container["a" /* default */], {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Galeri"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(GalleryContainer, {
          children: gallery === null || gallery === void 0 ? void 0 : gallery.map((item, index) => {
            var _item$path;

            return /*#__PURE__*/Object(jsx_runtime_["jsx"])(GalleryList, {
              slug: item.post.slug,
              text: item.post.title,
              image: (_item$path = item.path) === null || _item$path === void 0 ? void 0 : _item$path.replace("public", "https://admin.zaharadental.com")
            }, `${index}`);
          })
        })]
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200 py-20",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container["a" /* default */], {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300 mb-10",
          children: "Instagram Feeds"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Embed, {
          refId: "cf0cdc21292e428a3a654fb046cb71e6958030a8"
        })]
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container["a" /* default */], {
        className: "z-10 relative flex flex-col lg:flex-row lg:justify-between py-20 px-3 lg:px-0",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: "lg:w-1/3 lg:mr-16",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: "h-16 w-full relative",
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
              unoptimized: true,
              src: basicInformation === null || basicInformation === void 0 ? void 0 : (_basicInformation$log = basicInformation.logo) === null || _basicInformation$log === void 0 ? void 0 : _basicInformation$log.replace("public", "https://admin.zaharadental.com"),
              alt: `Logo ${basicInformation.clinicName}`,
              layout: "fill",
              objectFit: "contain",
              objectPosition: "left",
              quality: 90
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: "text-grayscale-700 text-justify mt-5",
            children: basicInformation.description
          })]
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "w-full lg:w-1/2 mt-8 lg:mt-0",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("iframe", {
            src: "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3984.551458567118!2d104.7828726!3d-2.9443187!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e3b77a7c616c2c7%3A0x78ffdbd1be2a42f8!2sZahara%20Dental%20Care!5e0!3m2!1sid!2sid!4v1628881642342!5m2!1sid!2sid",
            className: "w-full h-64 lg:h-full",
            frameBorder: "0",
            style: {
              border: 0
            },
            allowFullScreen: "",
            "aria-hidden": "false",
            tabIndex: "0"
          })
        })]
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container["a" /* default */], {
        className: "flex flex-col lg:flex-row py-20",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Halaman"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("ul", {
            className: "mt-3",
            children: pages === null || pages === void 0 ? void 0 : pages.map((item, index) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
                href: `/halaman/${item.slug}`,
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
                  className: "mt-1 block text-grayscale-700 hover:text-primary-100",
                  title: item.title,
                  children: item.title
                })
              })
            }, `${index}`))
          })]
        }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: "ml-0 lg:ml-12 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Jam Operasional"
          }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
            className: "arimo mt-3 text-grayscale-800 flex flex-col",
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
              className: "font-bold",
              children: basicInformation.operationalDay
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
              children: basicInformation.operationalHour
            })]
          }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
            className: "arimo mt-3 lg:w-80 flex flex-col",
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
              className: "text-grayscale-800 font-bold",
              children: "Alamat"
            }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("span", {
              className: "text-grayscale-700 flex-1",
              children: [basicInformation === null || basicInformation === void 0 ? void 0 : basicInformation.address, " ", /*#__PURE__*/Object(jsx_runtime_["jsx"])("br", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
                href: basicInformation.gmaps,
                title: `Google Maps ${basicInformation.clinicName}`,
                className: "text-primary-200",
                children: "Lihat Maps"
              })]
            })]
          })]
        }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: "ml-0 lg:ml-12 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Ikuti Kami"
          }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
            className: "mt-3 flex",
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(SocialMediaButton, {
              title: `Instagram ${basicInformation.clinicName}`,
              icon: Instagram,
              target: "_blank",
              href: basicInformation.instagram
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(SocialMediaButton, {
              title: `Facebook ${basicInformation.clinicName}`,
              icon: Facebook,
              target: "_blank",
              className: "ml-2",
              href: basicInformation.facebook
            })]
          })]
        })]
      })
    })]
  });
}

/***/ }),

/***/ "TqRt":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "TqjF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// CONCATENATED MODULE: ./src/images/Dent-Icon-1.js



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon1(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", _objectSpread(_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 511.849 511.849",
    height: "512",
    viewBox: "0 0 511.849 511.849",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m30.239 407.61c-3.464-2.271-8.113-1.305-10.384 2.16-12.989 19.811-19.855 42.786-19.855 66.441v26.949c0 4.142 3.358 7.5 7.5 7.5s7.5-3.358 7.5-7.5v-26.949c0-20.725 6.017-40.856 17.399-58.216 2.271-3.464 1.304-8.114-2.16-10.385z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m120.246 445.613h-61.777c-7.015 0-12.723 5.708-12.723 12.723v23.038c0 7.015 5.708 12.723 12.723 12.723h61.777c7.015 0 12.723-5.708 12.723-12.723v-23.038c0-7.015-5.708-12.723-12.723-12.723zm-2.277 33.484h-57.223v-18.483h57.223z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m226.995 88.286c-16.659 0-30.212 13.553-30.212 30.212s13.553 30.212 30.212 30.212c16.66 0 30.213-13.553 30.213-30.212s-13.553-30.212-30.213-30.212zm0 45.424c-8.388 0-15.212-6.824-15.212-15.212s6.824-15.212 15.212-15.212 15.213 6.824 15.213 15.212-6.825 15.212-15.213 15.212z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m450.946 274.095c-3.528-2.171-8.147-1.073-10.319 2.455-2.172 3.527-1.072 8.147 2.454 10.318 33.668 20.73 53.768 56.674 53.768 96.15 0 62.217-50.617 112.833-112.834 112.833s-112.833-50.617-112.833-112.833 50.616-112.833 112.833-112.833c10.71 0 21.316 1.503 31.524 4.468 3.976 1.152 8.139-1.133 9.294-5.111s-1.133-8.139-5.11-9.294c-11.568-3.359-23.583-5.063-35.708-5.063-58.127 0-107.311 39-122.775 92.206l-16.754-6.836v-31.298c24.687-19.548 39.907-49.676 39.907-82.303v-3.803c18.003-1.12 32.309-16.114 32.309-34.394 0-5.117-1.129-9.973-3.138-14.344l.005-34.159c7.771-1.962 13.547-8.991 13.547-17.363v-8.785c0-9.515-7.456-17.299-16.829-17.871l.029-1.677-.969-17.774c-1.232-22.595-15.287-42.748-35.961-51.763l-1.082-1.058c-12.678-12.391-30.07-18.524-47.714-16.824l-7.983.769-4.87-2.085c-15.02-6.434-32.249-6.434-47.267 0l-4.87 2.085-7.983-.769c-17.644-1.7-35.035 4.433-47.712 16.824l-1.082 1.058c-20.673 9.014-34.729 29.167-35.96 51.763l-.993 18.184-.096 1.932c-7.464 2.167-12.94 9.053-12.94 17.206v8.785c0 7.047 4.097 13.14 10.026 16.067v34.977c-2.149 4.493-3.355 9.519-3.355 14.822 0 18.281 14.306 33.275 32.309 34.394v4.102c0 33.096 15.693 63.688 41.057 83.215v30.087l-57.461 23.445c-12.022 4.905-23.134 11.688-33.029 20.163-3.146 2.694-3.512 7.429-.817 10.575 1.483 1.732 3.585 2.621 5.7 2.621 1.727 0 3.461-.593 4.875-1.804 8.671-7.426 18.407-13.371 28.938-17.667l42.448-17.319 58.19 145.566c1.139 2.849 3.897 4.716 6.964 4.716s5.826-1.868 6.964-4.716l58.189-145.566 4.05 1.652c-1.113 6.771-1.701 13.716-1.701 20.797 0 70.488 57.346 127.833 127.833 127.833 70.488 0 127.834-57.346 127.834-127.833.001-44.724-22.767-85.442-60.902-108.923zm-166.553-119.733v-13.545h14.175l-.003 17.594c-4.266-2.305-9.071-3.732-14.172-4.049zm-57.397 9.348c-24.931 0-45.213-20.282-45.213-45.212s20.282-45.212 45.213-45.212c24.93 0 45.212 20.282 45.212 45.212s-20.282 45.212-45.212 45.212zm57.397 44.388v-38.683c9.721 1.079 17.309 9.338 17.309 19.342s-7.588 18.262-17.309 19.341zm27.722-93.993v8.785c0 1.614-1.313 2.926-2.926 2.926h-22.442c.292-2.401.461-4.84.461-7.319s-.168-4.918-.461-7.319h22.442c1.614.001 2.926 1.314 2.926 2.927zm-230.276-36.505c.945-17.33 11.946-32.745 28.028-39.271.903-.367 1.726-.905 2.422-1.586l2.1-2.053c9.509-9.294 22.548-13.893 35.79-12.62l9.892.953c1.249.121 2.515-.075 3.671-.571l6.633-2.841c11.267-4.825 24.189-4.825 35.456 0l6.633 2.841c1.156.496 2.42.692 3.671.571l9.892-.953c13.237-1.274 26.282 3.326 35.79 12.619l2.1 2.053c.697.681 1.52 1.22 2.423 1.587 16.081 6.526 27.083 21.941 28.027 39.271l.989 18.147c.002.031-.006.187-.022.433h-12.433c-8.887-22.18-30.589-37.894-55.906-37.894s-47.02 15.714-55.906 37.894h-41.171c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h37.325c-.292 2.401-.461 4.84-.461 7.319s.168 4.918.461 7.319h-96.482c-1.614 0-2.926-1.313-2.926-2.926v-8.785c0-1.614 1.313-2.926 2.926-2.926h27.195c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5h-17.128l.021-.433zm9.976 76.762c-5.015.312-9.742 1.699-13.954 3.936v-17.482h13.954zm-17.309 34.394c0-10.004 7.588-18.263 17.309-19.342v38.684c-9.721-1.079-17.309-9.337-17.309-19.342zm32.309 38.496v-86.436h64.274c8.887 22.18 30.589 37.894 55.906 37.894 16.521 0 31.507-6.692 42.397-17.503v65.747c0 37.99-24.056 72.047-59.86 84.75l-.738.262c-13.703 4.861-28.785 4.831-42.468-.087-35.596-12.794-59.511-46.802-59.511-84.627zm54.438 98.742c8.519 3.062 17.473 4.592 26.43 4.592 8.849 0 17.7-1.495 26.128-4.485l.737-.262c5.201-1.845 10.189-4.077 14.937-6.656v24.636l-30.288 26.03c-6.197 5.326-15.511 5.289-21.667-.084l-29.659-25.892v-23.797c4.282 2.257 8.741 4.25 13.382 5.918zm27.426 157.152-51.265-128.244.194-.079 30.059 26.242c5.901 5.152 13.323 7.729 20.749 7.729 7.341 0 14.686-2.522 20.559-7.569l30.738-26.417.231.094z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m390.095 318.242c-3.207 2.328-7.515 2.328-10.722 0-18.898-13.726-44.878-13.175-63.178 1.339-22.018 17.464-26.315 48.947-9.784 71.675l22.321 30.685 3.447 32.665c1.088 10.303 9.721 18.073 20.081 18.073 9.71 0 18.056-6.927 19.846-16.47l6.107-32.566c.589-3.134 3.33-5.41 6.52-5.41s5.932 2.275 6.52 5.41l6.108 32.566c1.79 9.543 10.136 16.47 19.846 16.47 10.359 0 18.992-7.77 20.08-18.073l3.447-32.665 22.321-30.686c16.531-22.727 12.233-54.21-9.784-71.674-18.297-14.513-44.277-15.066-63.176-1.339zm53.854 13.091c15.698 12.451 18.762 34.896 6.976 51.099l-23.503 32.311c-.774 1.065-1.255 2.315-1.394 3.625l-3.659 34.664c-.279 2.649-2.499 4.647-5.162 4.647-2.497 0-4.643-1.781-5.104-4.235l-6.107-32.565c-1.917-10.225-10.859-17.646-21.263-17.646-10.402 0-19.344 7.42-21.262 17.645l-6.107 32.566c-.461 2.454-2.606 4.235-5.104 4.235-2.664 0-4.884-1.998-5.163-4.647l-3.658-34.664c-.139-1.31-.619-2.56-1.394-3.625l-23.504-32.311c-11.786-16.203-8.723-38.648 6.976-51.099 13.045-10.348 31.568-10.74 45.041-.955 8.478 6.157 19.871 6.157 28.351 0 13.475-9.785 31.994-9.392 45.04.955z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m369.821 350.61-.02-.012c-3.509-2.195-8.14-1.128-10.335 2.385s-1.127 8.14 2.386 10.335c.025.017.071.045.098.061 6.811 4.14 14.789 6.21 22.768 6.21 7.989 0 15.978-2.075 22.793-6.225 3.538-2.154 4.66-6.769 2.506-10.306-2.155-3.539-6.771-4.659-10.307-2.505-8.96 5.455-21.003 5.457-29.889.057z"
      })]
    })
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-10.js



function Dent_Icon_10_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_10_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_10_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_10_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_10_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_10_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon10(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", Dent_Icon_10_objectSpread(Dent_Icon_10_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 512 512",
    height: "512",
    viewBox: "0 0 512 512",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "m297.645 125.406c-.001 0-.002.001-.002.001-44.137 23.448-60.977 78.444-37.538 122.595 16.272 30.631 47.732 48.114 80.222 48.114 14.327 0 28.858-3.401 42.37-10.575 44.137-23.448 60.977-78.443 37.538-122.595-23.447-44.137-78.439-60.977-122.59-37.54zm78.017 146.889c-11.279 5.988-23.401 8.826-35.36 8.826-27.113-.001-53.372-14.592-66.95-40.152-19.561-36.847-5.508-82.745 31.328-102.314 36.847-19.559 82.741-5.506 102.309 31.328 19.56 36.846 5.506 82.744-31.327 102.312z"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "m376.785 182.391h-13.56v-13.561c0-9.088-7.393-16.481-16.481-16.481h-13.149c-9.087 0-16.48 7.393-16.48 16.481v13.561h-13.561c-9.103 0-16.509 7.406-16.509 16.509v13.12c0 9.103 7.406 16.509 16.509 16.509h13.561v13.561c0 9.103 7.393 16.509 16.48 16.509h13.149c9.088 0 16.481-7.406 16.481-16.509v-13.56h13.56c9.104 0 16.51-7.406 16.51-16.509v-13.12c-.001-9.104-7.406-16.51-16.51-16.51zm1.51 29.63c0 .819-.691 1.51-1.511 1.51h-21.059c-4.142 0-7.5 3.358-7.5 7.5v21.061c0 .805-.692 1.51-1.482 1.51h-13.149c-.803 0-1.481-.691-1.481-1.51v-21.061c0-4.142-3.357-7.5-7.5-7.5h-21.06c-.818 0-1.51-.691-1.51-1.51v-13.12c0-.819.691-1.51 1.51-1.51h21.06c4.142 0 7.5-3.358 7.5-7.5v-21.061c0-.803.679-1.482 1.481-1.482h13.149c.79 0 1.482.692 1.482 1.482v21.061c0 4.142 3.357 7.5 7.5 7.5h21.059c.819 0 1.511.691 1.511 1.51z"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "m506.585 420.006-24.796-46.633c-.013-.026-.023-.052-.036-.078-.014-.025-.03-.048-.044-.073l-13.539-25.463c-1.896-3.603-5.093-6.253-9.001-7.461-3.92-1.211-8.068-.826-11.687 1.092l-5.631 2.994-22.904-43.133c14.072-11.53 25.396-26.023 33.306-42.791 11.09-23.51 14.564-50.454 9.779-75.87-.766-4.071-4.686-6.748-8.757-5.983-4.07.766-6.749 4.687-5.982 8.757 8.864 47.093-13.643 93.852-56.006 116.353-17.982 9.553-37.814 13.798-57.637 12.571-.332-.053-.669-.092-1.015-.099-.057-.001-.112-.002-.168-.002-.072 0-.142.009-.214.011-8.05-.603-16.091-2.108-23.999-4.531-27.834-8.53-50.678-27.388-64.326-53.104-13.655-25.693-16.479-55.173-7.951-83.009 8.527-27.832 27.376-50.676 53.077-64.323 25.71-13.658 55.2-16.486 83.033-7.962 27.834 8.523 50.679 27.376 64.322 53.086 1.942 3.657 6.481 5.049 10.14 3.109 3.659-1.942 5.05-6.482 3.109-10.141-15.523-29.25-41.512-50.699-73.18-60.396-.16-.049-.32-.092-.48-.141-9.781-26.211-29.133-45.28-56.202-55.275-28.25-10.432-63.189-10.097-101.019.965-7.135 2.065-12.416 4.018-16.659 5.587-4.908 1.815-8.151 3.014-10.593 3.014-2.42 0-5.652-1.196-10.544-3.006-4.247-1.571-9.532-3.527-16.661-5.59-36.533-10.681-70.503-11.36-98.239-1.959-3.923 1.329-6.025 5.587-4.696 9.51 1.33 3.923 5.587 6.024 9.51 4.696 24.804-8.406 55.655-7.662 89.236 2.156 6.625 1.918 11.627 3.768 15.646 5.256 6.178 2.286 10.642 3.938 15.749 3.938 5.127 0 9.602-1.655 15.796-3.946 4.016-1.485 9.014-3.333 15.646-5.253 62.652-18.319 113.851-4.2 134.831 35.854-25.897-3.774-52.233.743-75.781 13.252-29.238 15.525-50.682 41.513-60.382 73.176-9.702 31.669-6.489 65.209 9.045 94.437 15.524 29.252 41.512 50.706 73.177 60.41 6.905 2.116 13.899 3.598 20.918 4.492-.68 20.316-2.729 46.656-10.202 66.386-8.163 21.55-20.799 31.587-39.766 31.587-19.774 0-32.893-9.736-41.286-30.64-8.005-19.938-10.555-46.66-13.02-72.502-.631-6.611-1.283-13.448-2.013-19.941-1.633-14.455-4.544-25.053-8.898-32.401-5.774-9.743-13.011-11.788-18.066-11.788-5.047 0-12.273 2.046-18.043 11.791-4.351 7.35-7.26 17.947-8.893 32.402-.729 6.49-1.382 13.327-2.013 19.939-2.465 25.842-5.015 52.563-13.02 72.501-8.393 20.904-21.511 30.64-41.285 30.64-21.974 0-35.762-13.689-43.392-43.08-6.995-26.948-6.995-61.426-6.995-89.129 0-38.977-12.539-67.126-23.602-91.961-6.795-15.253-13.212-29.66-16.294-45.228-8.307-42.115.94-76.777 26.036-97.601 3.188-2.645 3.628-7.373.983-10.56-2.644-3.187-7.374-3.627-10.56-.983-29.523 24.494-40.594 64.287-31.174 112.049 3.411 17.226 10.162 32.38 17.308 48.424 10.965 24.617 22.304 50.071 22.304 85.858 0 28.557 0 64.097 7.477 92.898 9.355 36.037 28.839 54.31 57.91 54.31 25.961 0 44.534-13.475 55.204-40.05 8.812-21.947 11.466-49.764 14.032-76.666.653-6.851 1.271-13.323 1.986-19.683 2.759-24.421 9.076-30.874 12.031-30.874 3.183 0 9.306 6.503 12.059 30.87.716 6.364 1.333 12.835 1.987 19.686 2.566 26.902 5.22 54.72 14.032 76.666 10.67 26.576 29.244 40.051 55.205 40.051 25.321 0 43.419-13.886 53.793-41.273 8.134-21.475 10.392-48.187 11.151-70.701.195.001.39.011.585.011 11.841-.001 23.619-1.731 35.03-5.135l22.922 43.167-5.625 2.991c-.01.005-.02.011-.029.016-7.437 3.996-10.248 13.276-6.283 20.657l13.565 25.521c.013.024.022.049.034.073.009.017.021.032.031.049l24.801 46.659c5.787 10.892 15.508 18.887 27.37 22.511 4.5 1.374 9.095 2.056 13.662 2.056 7.468 0 14.858-1.823 21.618-5.414 22.55-11.981 31.142-40.087 19.152-62.653zm-52.073-65.366c.065-.034.142-.037.229-.011.113.035.144.092.17.143l10.075 18.947-55.307 29.414-10.098-18.997c-.011-.021-.037-.07-.006-.174.04-.129.119-.179.153-.197zm-64.926-35.47c2.948-1.287 5.866-2.68 8.737-4.205 2.858-1.518 5.638-3.141 8.344-4.855l21.939 41.315-17.072 9.076zm90.809 150.244c-7.358 3.91-15.832 4.712-23.859 2.259-8.029-2.452-14.602-7.852-18.508-15.205l-21.311-40.092 55.309-29.415 21.314 40.084c8.108 15.261 2.302 34.268-12.945 42.369z"
        })]
      })
    })
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-2.js


function Dent_Icon_2_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_2_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_2_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_2_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_2_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_2_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon2(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", Dent_Icon_2_objectSpread(Dent_Icon_2_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 511.933 511.933",
    height: "512",
    viewBox: "0 0 511.933 511.933",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m139.841 138.571c3.971-1.18 6.233-5.354 5.054-9.325s-5.353-6.233-9.325-5.054c-13.57 4.031-25.64 11.367-34.905 21.213-25.794 27.412-21.203 64.301-20.02 71.417.61 3.67 3.788 6.271 7.389 6.271 4.568 0 8.161-4.195 7.408-8.73-.979-5.893-4.802-36.416 16.147-58.679 9.413-10.003 20.559-14.828 28.252-17.113zm166.599-38.22c-9.639 9.638-9.754 25.796-.001 35.455l19.466 19.468c5.834 5.831 13.6 9.043 21.867 9.043 8.268 0 16.035-3.213 21.87-9.046l54.868-54.869c10.026-9.943 9.488-26.866-.871-36.288-9.91-9.015-25.255-8.497-34.936 1.183l-40.931 40.931-5.875-5.874c-9.618-9.717-25.81-9.649-35.457-.003zm41.332 22.528c2.943 0 5.709-1.146 7.788-3.226l43.749-43.749c3.939-3.94 10.325-4.251 14.234-.695 4.186 3.807 4.397 10.595.36 14.586l-54.868 54.869c-3.001 3.001-7.001 4.653-11.264 4.653-4.261 0-8.261-1.652-11.261-4.65l-19.464-19.466c-3.893-3.855-3.875-10.369 0-14.242 3.878-3.876 10.384-3.897 14.243 0l8.695 8.695c2.08 2.079 4.845 3.225 7.786 3.225zm24.788-122.867c-4.142-.234-7.697 2.878-7.958 7.012s2.877 7.697 7.011 7.959c50.485 3.193 90.032 45.352 90.032 95.977 0 54.04-44.2 96.171-96.17 96.171-53.028 0-96.17-43.142-96.17-96.171 0-42.692 28.675-80.721 69.733-92.477 3.982-1.14 6.286-5.292 5.146-9.274-1.14-3.981-5.293-6.29-9.275-5.146-42.331 12.12-73.253 48.409-79.445 91.128-6.368 4.385-13.103 9.333-19.448 12.512-10.361 5.191-19.147 5.66-29.373 1.573-7.62-3.051-13.926-7.569-20.603-12.353-10.972-7.86-22.317-15.988-39.46-17.245-20.518-1.493-43.65 5.299-63.463 18.639-26.478 17.826-43.664 50.294-47.151 89.078-1.596 17.695-.364 34.493 3.663 49.925 2.856 10.961 7.818 21.118 12.616 30.94 4.391 8.987 8.537 17.477 11.173 26.476 5.242 17.901 4.578 35.681 3.874 54.503-.259 6.938-.527 14.113-.486 21.351.225 41.345.505 92.799 33.476 122.527 13.148 11.855 34.098 24.267 51.215 16.219 12.639-5.942 14.615-19.215 17.351-37.584 1.418-9.522 3.183-21.375 6.729-35.36.815-3.216 1.634-6.727 2.501-10.443 1.191-5.104 2.994-12.382-4.377-14.118-7.221-1.701-8.987 5.379-10.231 10.71-.851 3.646-1.654 7.089-2.434 10.166-3.731 14.716-5.558 26.981-7.025 36.837-2.447 16.431-3.746 23.797-8.894 26.218-8.335 3.913-24.145-4.177-34.789-13.782-28.054-25.294-28.313-73.077-28.522-111.473-.04-6.915.223-13.926.476-20.706.717-19.192 1.459-39.037-4.468-59.279-2.995-10.223-7.619-19.689-12.091-28.844-4.68-9.581-9.101-18.63-11.58-28.142-3.588-13.754-4.678-28.824-3.237-44.794 3.081-34.267 17.875-62.689 40.589-77.98 17.082-11.5 36.759-17.376 53.993-16.122 12.931.948 21.683 7.219 31.818 14.479 7.108 5.092 14.458 10.357 23.767 14.085 14.228 5.688 27.467 5.023 41.665-2.089 4.03-2.021 7.882-4.42 11.619-6.927 1.715 59.812 50.901 107.942 111.12 107.942 8.234 0 16.258-.908 23.987-2.614-2.198 14.637-6.717 28.396-13.282 40.278-17.619 31.908-17.253 61.618-16.866 93.073.07 5.722.144 11.639.111 17.678-.219 38.382-.491 86.149-28.534 111.436-10.642 9.604-26.453 17.695-34.784 13.781-5.151-2.422-6.45-9.788-8.897-26.22-1.467-9.855-3.294-22.12-7.024-36.834-6.304-24.868-16.567-72.889-43.429-86.994-8.97-4.71-18.722-5.117-28.985-1.216-13.986 5.313-24.754 17.907-32.919 38.499-1.526 3.851.357 8.21 4.208 9.736 3.851 1.53 8.21-.356 9.737-4.207 6.525-16.457 14.475-26.272 24.304-30.007 6.158-2.341 11.615-2.187 16.684.476 20.311 10.667 30.479 56.166 35.861 77.396 3.545 13.985 5.31 25.837 6.728 35.359 2.736 18.37 4.712 31.643 17.353 37.586 17.338 8.152 38.171-4.459 51.211-16.218 32.958-29.718 33.251-81.157 33.487-122.529.033-6.136-.041-12.12-.112-17.907-.378-30.693-.705-57.201 14.997-85.637 8.461-15.312 13.899-33.285 15.859-52.248 41.754-16.015 71.477-56.518 71.477-103.839-.004-58.52-45.724-107.253-104.089-110.946zm-280.138 236.557c-4.129.321-7.217 3.93-6.896 8.059.337 4.336 1.029 8.673 2.055 12.89.834 3.43 3.902 5.729 7.281 5.729 4.757 0 8.428-4.613 7.293-9.275-.836-3.437-1.399-6.971-1.674-10.505-.322-4.132-3.938-7.229-8.059-6.898z"
      })
    })
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-3.js



function Dent_Icon_3_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_3_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_3_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_3_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_3_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_3_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon3(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", Dent_Icon_3_objectSpread(Dent_Icon_3_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 511.989 511.989",
    height: "512",
    viewBox: "0 0 511.989 511.989",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
              d: "m9.989 190.739c4.059 0 7.797-2.555 9.29-6.323 1.536-3.875.445-8.443-2.697-11.193-3.188-2.79-7.922-3.248-11.591-1.137-3.671 2.113-5.633 6.462-4.803 10.613.922 4.608 5.096 8.04 9.801 8.04z"
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
              d: "m410.765 190.269c1.254-17.075-.696-33.235-5.809-48.093-12.945-37.616-39.611-65.36-73.159-76.119-46.625-14.951-86.499 7.602-112.438 25.867-8.253 5.81-19.343 5.81-27.595 0-25.939-18.265-65.815-40.817-112.438-25.867-30.405 9.75-54.946 33.073-69.104 65.671-2.2 5.065.123 10.955 5.189 13.156 5.063 2.2 10.955-.123 13.156-5.189 11.83-27.239 32.025-46.627 56.867-54.593 37.366-11.983 71.008 6.604 93.463 22.228 7.737 13.952 20.25 24.328 35.486 29.362 6.531 2.157 13.242 3.228 19.926 3.228 9.753 0 19.445-2.281 28.41-6.794 4.933-2.483 6.919-8.496 4.436-13.428-2.483-4.934-8.496-6.919-13.428-4.436-10.339 5.203-22.083 6.07-33.07 2.44-2.021-.668-3.972-1.473-5.843-2.407 5.665-1.212 11.138-3.551 16.06-7.017 22.444-15.804 56.691-35.399 94.816-23.175 27.484 8.813 49.482 31.988 60.355 63.581 4.095 11.901 5.726 24.929 4.863 38.795-2.62-.161-5.26-.243-7.919-.243-71.13 0-128.999 58.296-128.999 129.951 0 35.288 14.034 67.335 36.775 90.776-1.896 4.016-3.771 7.997-5.614 11.919-4.281 9.107-12.813 11.542-19.363 10.784-6.557-.759-14.309-5.079-16.397-14.928l-23.535-110.955c-.037-.174-.079-.348-.125-.52-2.486-9.25-10.591-15.465-20.17-15.465-9.578 0-17.684 6.215-20.169 15.465-.046.172-.088.346-.125.52l-23.535 110.955c-2.089 9.849-9.84 14.169-16.398 14.928-6.556.757-15.083-1.676-19.363-10.784-37.293-79.342-60.806-126.337-69.889-139.681-12.99-19.085-22.683-38.333-28.807-57.209-1.704-5.253-7.347-8.13-12.598-6.426-5.253 1.704-8.13 7.345-6.426 12.598 6.71 20.68 17.24 41.638 31.297 62.291 8.251 12.123 32.515 60.754 68.322 136.935 6.565 13.968 20.004 22.416 35.059 22.416 1.552 0 3.123-.09 4.703-.273 16.916-1.957 30.13-13.986 33.664-30.645l23.464-110.624c.091-.271.244-.466.8-.466.557 0 .709.195.801.467l23.465 110.622c3.533 16.659 16.747 28.688 33.663 30.645 16.915 1.956 32.52-6.735 39.763-22.143 1.04-2.214 2.091-4.446 3.15-6.693 21.434 15.982 47.934 25.442 76.588 25.442 71.13 0 128.999-58.296 128.999-129.952 0-62.052-43.398-114.085-101.224-126.917zm-27.775 236.869c-60.102 0-108.999-49.324-108.999-109.952 0-60.627 48.897-109.951 108.999-109.951s108.999 49.324 108.999 109.951c0 60.628-48.897 109.952-108.999 109.952z"
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
              d: "m430.78 282.885h-13.69v-13.895c0-12.252-9.924-22.219-22.122-22.219h-23.956c-12.198 0-22.122 9.967-22.122 22.219v13.895h-13.69c-12.198 0-22.121 9.967-22.121 22.219v24.167c0 12.251 9.924 22.219 22.121 22.219h13.69v13.895c0 12.251 9.924 22.219 22.122 22.219h23.956c12.198 0 22.122-9.967 22.122-22.219v-13.895h13.69c12.198 0 22.122-9.967 22.122-22.219v-24.167c0-12.252-9.924-22.219-22.122-22.219zm2.122 46.385c0 1.224-.952 2.219-2.122 2.219h-23.69c-5.523 0-10 4.477-10 10v23.895c0 1.224-.952 2.219-2.122 2.219h-23.956c-1.17 0-2.122-.995-2.122-2.219v-23.895c0-5.523-4.477-10-10-10h-23.69c-1.17 0-2.121-.995-2.121-2.219v-24.167c0-1.224.952-2.219 2.121-2.219h23.69c5.523 0 10-4.477 10-10v-23.894c0-1.224.952-2.219 2.122-2.219h23.956c1.17 0 2.122.995 2.122 2.219v23.895c0 5.523 4.477 10 10 10h23.69c1.17 0 2.122.995 2.122 2.219z"
            })]
          })
        })
      })
    })
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-4.js



function Dent_Icon_4_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_4_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_4_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_4_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_4_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_4_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon4(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", Dent_Icon_4_objectSpread(Dent_Icon_4_objectSpread({
    version: "1.1",
    id: "Capa_1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    x: "0px",
    y: "0px",
    viewBox: "0 0 512.001 512.001",
    xmlSpace: "preserve"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "M385.968,46.993c-5.52,0-10,4.48-10,10s4.48,10,10,10c5.52,0,10-4.48,10-10S391.49,46.993,385.968,46.993z"
        })
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "M395.123,7.999c-62.714-20.11-115.125,2.394-139.154,16.261C231.942,10.39,179.539-12.115,116.81,7.999\r C33.738,34.646-5.209,155.948,61.398,253.824c31.557,46.352,35.771,82.105,40.232,119.958c3.266,27.709,6.643,56.362,20.749,89.86\r c9.486,22.52,22.895,48.281,42.734,48.279c0.179,0,0.362-0.002,0.542-0.006c15.953-0.377,28.809-16.199,41.681-51.304\r c6.557-17.895,10.758-39.011,14.821-59.43c7.313-36.754,14.876-74.759,33.883-74.892c0.034,0,0.067,0,0.101,0\r c18.799,0,26.345,38.018,33.643,74.783c4.065,20.484,8.269,41.667,14.825,59.541c12.888,35.159,25.743,51.006,41.681,51.382\r c0.181,0.004,0.36,0.006,0.541,0.006c19.799,0,33.226-25.802,42.726-48.36c13.48-32.011,17.011-60.593,20.426-88.234\r c4.808-38.917,9.349-75.675,40.629-121.689C517.999,154.578,476.801,34.182,395.123,7.999z M434.07,242.474\r c-33.996,50.01-39.05,90.919-43.938,130.481c-3.397,27.497-6.606,53.469-19.009,82.922C356.407,490.816,347.873,492,346.794,492\r c-0.012,0-0.022,0-0.032,0c-0.385-0.009-9.586-0.655-23.375-38.274c-6.02-16.412-10.069-36.816-13.985-56.548\r c-4.396-22.15-8.548-43.073-15.392-59.404c-8.757-20.895-21.485-31.487-37.836-31.487c-0.091,0-0.184,0-0.275,0.001\r c-16.419,0.115-29.195,10.789-37.97,31.727c-6.841,16.322-10.992,37.181-15.385,59.263c-3.915,19.672-7.962,40.015-13.984,56.45\r c-13.764,37.538-22.987,38.184-23.373,38.193c-0.896,0.016-9.53-0.804-24.372-36.041c-13.007-30.889-16.073-56.899-19.318-84.438\r c-4.547-38.579-9.249-78.471-43.561-128.87C17.891,154.341,54.085,49.127,122.921,27.046\r c59.86-19.195,109.263,5.74,127.724,17.353c3.253,2.047,7.393,2.048,10.646,0.001c18.468-11.61,67.883-36.543,127.727-17.353\r C459.217,49.548,492.901,155.924,434.07,242.474z"
        })
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "M437.074,103.527c-3.248-9.429-7.553-18.105-12.794-25.788c-3.113-4.564-9.334-5.739-13.896-2.626\r c-4.563,3.112-5.738,9.333-2.625,13.896c4.237,6.211,7.738,13.288,10.406,21.032c9.965,28.924,7.365,62.673-7.134,92.594\r c-2.409,4.97-0.332,10.951,4.638,13.36c4.971,2.409,10.952,0.332,13.36-4.638C445.817,176.714,448.75,137.411,437.074,103.527z"
        })
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "M219.628,136.797l-40.257-13.419l-13.419-40.257c-1.361-4.083-5.183-6.838-9.487-6.838s-8.125,2.754-9.487,6.838\r l-13.419,40.257l-40.257,13.419c-4.083,1.361-6.838,5.183-6.838,9.487s2.754,8.125,6.838,9.487l40.257,13.419l13.419,40.257\r c1.361,4.083,5.183,6.838,9.487,6.838s8.125-2.754,9.487-6.838l13.419-40.257l40.257-13.419c4.083-1.361,6.838-5.183,6.838-9.487\r S223.712,138.159,219.628,136.797z M168.303,151.797c-2.986,0.995-5.33,3.338-6.325,6.325l-5.513,16.54l-5.513-16.54\r c-0.995-2.986-3.338-5.33-6.325-6.325l-16.54-5.513l16.54-5.513c2.986-0.995,5.33-3.338,6.325-6.325l5.513-16.54l5.513,16.54\r c0.995,2.986,3.338,5.33,6.325,6.325l16.54,5.513L168.303,151.797z"
        })
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {})]
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-5.js



function Dent_Icon_5_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_5_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_5_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_5_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_5_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_5_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon5(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", Dent_Icon_5_objectSpread(Dent_Icon_5_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 512 512",
    height: "512",
    viewBox: "0 0 512 512",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "m178.222 419.991c-13.846-4.779-22.013-19.443-24.882-25.527-1.47-3.116-4.647-5.13-8.092-5.13-3.446 0-6.623 2.014-8.093 5.13 0 0 0 0-.001.001-2.868 6.083-11.035 20.746-24.881 25.525-3.601 1.243-6.021 4.64-6.021 8.453s2.42 7.21 6.021 8.453c13.846 4.779 22.013 19.443 24.882 25.527 1.47 3.116 4.647 5.13 8.093 5.13s6.622-2.014 8.093-5.131c2.868-6.083 11.035-20.746 24.881-25.525 3.601-1.243 6.021-4.64 6.021-8.453s-2.42-7.21-6.021-8.453zm-32.975 26.261c-3.874-5.902-9.433-12.67-16.853-17.808 7.42-5.138 12.979-11.906 16.853-17.808 3.875 5.902 9.433 12.67 16.854 17.808-7.42 5.138-12.98 11.906-16.854 17.808z"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "m364.025 159.845c-11.257-3.886-17.98-16.583-19.771-20.379-1.427-3.029-4.513-4.987-7.862-4.988-.002 0-.003 0-.004 0-3.348 0-6.435 1.955-7.864 4.982-.001.001-.002.003-.002.004-1.792 3.798-8.512 16.494-19.774 20.381-3.499 1.209-5.85 4.51-5.85 8.214 0 3.705 2.351 7.006 5.852 8.215 11.26 3.887 17.98 16.583 19.774 20.385 1.429 3.027 4.516 4.982 7.864 4.982h.004c3.349-.002 6.435-1.959 7.861-4.985 1.792-3.799 8.515-16.497 19.772-20.383 3.5-1.208 5.853-4.509 5.853-8.215 0-3.703-2.353-7.005-5.853-8.213zm-27.637 20.574c-2.907-4.157-6.77-8.652-11.671-12.359 4.901-3.706 8.764-8.201 11.671-12.358 2.908 4.157 6.77 8.652 11.672 12.358-4.902 3.707-8.764 8.202-11.672 12.359z"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          d: "m453.45 131.416c-6.646-1.869-13.59-3.666-20.778-5.389 6.239-6.473 13.988-12.31 23.315-15.529 3.925-1.355 6.561-5.057 6.561-9.214 0-4.156-2.636-7.858-6.561-9.213-23.126-7.982-36.569-32.053-41.274-42.029-1.626-3.451-5.006-5.595-8.823-5.596-.001 0-.002 0-.003 0-3.815 0-7.196 2.143-8.824 5.593v.002c-4.705 9.977-18.146 34.047-41.275 42.03-3.925 1.355-6.561 5.057-6.561 9.213 0 4.157 2.636 7.859 6.561 9.214 1.83.632 3.592 1.374 5.301 2.192-82.684-11.387-166.101-9.317-248.514 6.239-19.417 3.665-37.593 7.866-54.024 12.486-34.474 9.694-58.551 41.588-58.551 77.562v128.04c0 12.317 10.02 22.337 22.337 22.337h45.908c4.095 0 7.933-1.113 11.236-3.044 3.449 5.162 8.927 8.885 15.465 9.967 4.09.673 7.955-2.09 8.632-6.18s-2.09-7.955-6.18-8.632c-3.949-.653-6.815-4.042-6.815-8.057v-78.731c0-17.881 14.547-32.428 32.428-32.428s32.428 14.547 32.428 32.428v78.731c0 4.504-3.664 8.168-8.168 8.168h-16.502c-4.146 0-7.507 3.361-7.507 7.507s3.361 7.507 7.507 7.507h16.502c4.051 0 7.862-1.047 11.179-2.882 4.326 8.107 12.867 13.638 22.679 13.638h56.291c7.135 0 13.597-2.925 18.257-7.637 4.66 4.712 11.122 7.637 18.257 7.637h56.291c9.927 0 18.551-5.663 22.827-13.926 3.432 2.011 7.421 3.169 11.678 3.169h48.521c8.013 0 15.089-4.088 19.254-10.287 3.307 1.937 7.15 3.052 11.25 3.052h45.908c12.317 0 22.337-10.02 22.337-22.337v-128.04c0-35.974-24.077-67.868-58.55-77.561zm-47.563-65.933c6.505 11.203 17.699 26.45 34.209 35.802-16.508 9.351-27.703 24.599-34.209 35.802-6.504-11.203-17.695-26.449-34.209-35.802 16.515-9.353 27.705-24.599 34.209-35.802zm-330.318 271.534c0 4.038-3.285 7.323-7.324 7.323h-45.908c-4.038 0-7.324-3.285-7.324-7.323v-74.491c0-.485.012-.967.033-1.442.326-6.991 3.921-13.256 9.861-17.19 3.867-2.561 8.382-3.877 12.925-3.877 2.731 0 5.473.476 8.088 1.443 18.255 6.75 28.228 17.282 29.648 31.308v64.249zm172.529 14.636c0 5.888-4.79 10.678-10.678 10.678h-56.291c-5.887 0-10.677-4.79-10.677-10.678v-91.339c0-21.407 17.416-38.823 38.823-38.823s38.823 17.416 38.823 38.823zm173.32-8.246c0 4.504-3.664 8.168-8.168 8.168h-48.521c-4.503 0-8.167-3.664-8.167-8.168v-78.731c0-17.881 14.546-32.428 32.427-32.428s32.428 14.547 32.428 32.428v78.731zm68.245.933h-45.908c-4.038 0-7.323-3.285-7.323-7.323v-64.249c1.42-14.025 11.393-24.558 29.648-31.308 6.965-2.575 14.821-1.667 21.013 2.434 5.94 3.934 9.534 10.2 9.86 17.186.022.479.033 75.938.033 75.938 0 4.037-3.285 7.322-7.323 7.322zm7.323-111.835c-.524-.386-1.054-.766-1.602-1.128-10.169-6.735-23.069-8.23-34.512-3.998-12.211 4.516-21.733 10.719-28.385 18.385-7.321-16.772-24.058-28.529-43.498-28.529-15.797 0-29.806 7.769-38.433 19.678-8.722-17.996-27.174-30.435-48.477-30.435-3.918 0-7.827.424-11.622 1.259-4.049.892-6.608 4.897-5.716 8.946.89 4.049 4.89 6.608 8.946 5.717 2.735-.603 5.559-.908 8.392-.908 21.407 0 38.823 17.416 38.823 38.823v91.339c0 5.888-4.791 10.678-10.678 10.678h-56.291c-5.887 0-10.678-4.79-10.678-10.678v-91.339c0-7.567 2.176-14.898 6.293-21.198 2.267-3.471 1.291-8.123-2.18-10.39-3.47-2.269-8.123-1.292-10.39 2.179-.458.702-.893 1.416-1.316 2.135-9.373-15.879-26.652-26.561-46.388-26.561-21.092 0-39.38 12.199-48.206 29.906-8.656-11.614-22.493-19.15-38.058-19.15-19.439 0-36.176 11.756-43.497 28.528-6.652-7.665-16.174-13.869-28.385-18.385-11.441-4.231-24.342-2.737-34.511 3.998-.548.363-1.079.743-1.604 1.129v-23.529c0-29.276 19.574-55.227 47.601-63.108 16.01-4.503 33.756-8.603 52.745-12.187 89.061-16.811 179.319-17.559 268.487-2.283 6.551 8.062 10.924 16.269 13.216 21.132 1.628 3.45 5.009 5.592 8.824 5.592h.003c3.816 0 7.196-2.145 8.822-5.594 1.563-3.313 4.095-8.183 7.62-13.5 9.459 2.155 18.512 4.438 27.055 6.84 28.027 7.88 47.6 33.831 47.6 63.108z"
        })]
      })
    })
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-6.js



function Dent_Icon_6_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_6_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_6_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_6_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_6_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_6_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon6(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", Dent_Icon_6_objectSpread(Dent_Icon_6_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 512 512",
    height: "512",
    viewBox: "0 0 512 512",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m144.927 365.344c-7.174-24.96-12.854-46.656-16.881-64.484-5.466-24.205-15.35-47.127-29.378-68.128-10.716-16.043-16.38-34.764-16.38-54.142-.001-21.841 7.344-42.881 20.779-60.02 3.068 4.676 5.562 10.109 7.108 16.428l3.116 12.73c1.107 4.521 5.131 7.678 9.785 7.678s8.678-3.157 9.785-7.678l3.116-12.729c5.312-21.696 21.731-33.02 34.568-38.7.392-.174.769-.38 1.125-.618 2.953-1.969 4.717-5.264 4.717-8.814 0-2.079-.62-4.062-1.714-5.751 2.027-.11 4.055-.161 6.08-.147 18.093.153 35.719 5.293 50.973 14.865 9.375 5.883 20.119 8.824 30.864 8.824s21.49-2.941 30.864-8.824c12.262-7.695 25.762-12.464 40.125-14.177 4.111-.49 7.046-4.22 6.556-8.331-.49-4.112-4.223-7.049-8.331-6.556-16.582 1.977-32.165 7.483-46.319 16.364-13.909 8.729-31.883 8.729-45.792 0-17.607-11.049-37.945-16.982-58.815-17.157-8.502-.074-16.981.829-25.229 2.654-8.522-6.62-16.317-16.185-19.674-29.897l-3.116-12.729c-1.107-4.521-5.131-7.678-9.785-7.678s-8.678 3.157-9.785 7.678l-3.116 12.729c-5.311 21.695-21.73 33.02-34.567 38.7-.392.174-.769.38-1.125.618-2.953 1.969-4.717 5.264-4.717 8.814s1.764 6.845 4.717 8.814c.356.238.733.445 1.125.618 5.522 2.443 11.706 5.935 17.385 10.843-16.609 20.15-25.697 45.307-25.696 71.449 0 22.351 6.538 43.953 18.906 62.469 13.003 19.466 22.161 40.697 27.221 63.103 4.09 18.108 9.841 40.086 17.095 65.323.945 3.287 3.943 5.427 7.2 5.427.686 0 1.383-.095 2.075-.294 3.98-1.142 6.278-5.295 5.135-9.274zm-21.851-317.305c5.499 16.359 16.724 29.592 32.909 38.828-16.185 9.236-27.41 22.468-32.909 38.828-5.498-16.358-16.723-29.591-32.908-38.828 16.184-9.237 27.41-22.47 32.908-38.828z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m499.433 207.003-11.413-.083c-13.477-.098-24.234-1.938-32.693-4.442 1.688-7.815 2.556-15.824 2.556-23.887.001-52.762-37.477-99.082-89.114-110.137-4.047-.867-8.033 1.712-8.9 5.761s1.713 8.033 5.761 8.9c44.769 9.585 77.261 49.739 77.26 95.477 0 6.136-.58 12.233-1.707 18.211-6.049-3.205-9.648-6.342-11.301-7.996-1.973-1.973-3.826-4.12-5.509-6.384-3.221-4.333-8.165-6.825-13.563-6.838-.015 0-.028 0-.043 0-5.397 0-10.35 2.476-13.595 6.798-1.678 2.236-3.557 4.398-5.584 6.425-6.655 6.656-23.057 17.859-58.135 18.113l-11.413.083c-6.93.05-12.568 5.729-12.568 12.658v76.723c0 17.318 4.026 34.694 11.644 50.25 7.617 15.553 18.875 29.388 32.557 40.007l16.473 12.785c-6.026 19.793-12.794 41.209-20.158 63.763-3.891 11.915-14.051 15.809-22.272 15.469-8.217-.335-18.033-5.037-20.942-17.231-12.895-54.074-22.663-99.835-29.03-136.012-1.317-7.486-7.549-12.714-15.155-12.715 0 0 0 0-.001 0-7.605 0-13.838 5.229-15.156 12.714-6.371 36.197-16.139 81.958-29.03 136.012-2.909 12.194-12.726 16.897-20.942 17.232-8.198.331-18.381-3.553-22.271-15.47-7.769-23.794-14.883-46.332-21.141-66.986-1.201-3.963-5.392-6.2-9.348-5-3.962 1.201-6.201 5.386-5 9.348 6.29 20.756 13.434 43.396 21.237 67.292 5.345 16.372 19.921 26.51 37.133 25.796 17.213-.701 30.918-11.979 34.914-28.733 12.962-54.344 22.791-100.401 29.214-136.891.03-.176.06-.262.051-.249.137-.097.544-.096.647-.034.014.02.053.11.083.283 6.419 36.47 16.248 82.527 29.214 136.892 3.995 16.753 17.7 28.031 34.913 28.733.562.023 1.12.034 1.676.034 16.478-.001 30.289-9.993 35.46-25.83 6.72-20.583 12.952-40.236 18.578-58.58l8.402 6.521c5.557 4.312 12.486 6.687 19.514 6.687s13.957-2.375 19.515-6.687l37.546-29.141c13.682-10.619 24.94-24.453 32.557-40.007 7.62-15.559 11.646-32.935 11.646-50.253v-76.723c0-6.929-5.638-12.608-12.567-12.658zm-2.425 89.381c0 15.046-3.498 30.142-10.116 43.656-6.618 13.513-16.398 25.532-28.286 34.757l-37.545 29.14c-2.984 2.315-6.554 3.539-10.324 3.539s-7.34-1.223-10.322-3.538l-37.547-29.141c-11.887-9.226-21.668-21.245-28.286-34.757-6.618-13.514-10.116-28.61-10.116-43.656v-74.406l9.098-.066c40.426-.294 60.349-14.226 68.627-22.505 2.525-2.526 4.871-5.227 6.973-8.025.525-.7 1.23-.806 1.606-.806h.006c.448.001 1.083.139 1.567.789 2.118 2.849 4.453 5.554 6.94 8.042 6.665 6.665 26.694 22.2 68.628 22.505l9.097.066z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m475.212 233.493c-13.108-1.48-25.299-4.254-36.237-8.246-7.272-2.653-13.835-5.811-19.509-9.387-5.304-3.341-12.154-3.341-17.456 0-5.674 3.575-12.237 6.734-19.509 9.388-10.937 3.992-23.128 6.766-36.237 8.246-5.451.615-9.561 5.219-9.561 10.709v51.542c0 27.491 12.455 52.925 34.173 69.781l33.253 25.808c1.946 1.509 4.278 2.264 6.61 2.264s4.664-.755 6.61-2.266l33.251-25.807c16.713-12.971 28.216-31.434 32.393-51.989.825-4.057-1.796-8.014-5.853-8.838-4.058-.826-8.014 1.796-8.838 5.853-3.463 17.041-13.014 32.358-26.894 43.131l-30.669 23.803-30.669-23.803c-18.031-13.995-28.374-35.113-28.374-57.938v-47.813c12.878-1.701 24.954-4.589 35.946-8.6 8.268-3.017 15.791-6.646 22.363-10.787.453-.286 1.015-.286 1.468 0 6.572 4.141 14.096 7.771 22.364 10.787 10.991 4.012 23.067 6.9 35.945 8.6v27.313c0 4.14 3.356 7.496 7.496 7.496s7.496-3.356 7.496-7.496v-31.042c-.002-5.49-4.112-10.094-9.562-10.709z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m443.354 261.282-37.357 47.408-18.161-23.713c-2.516-3.286-7.219-3.912-10.509-1.394-3.286 2.517-3.91 7.222-1.393 10.509l24.027 31.374c1.407 1.838 3.584 2.922 5.899 2.938h.052c2.296 0 4.465-1.052 5.887-2.856l43.329-54.987c2.562-3.252 2.004-7.965-1.248-10.527-3.25-2.562-7.965-2.004-10.526 1.248z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m57.154 293.304c-.356-.238-.733-.444-1.124-.617-8.305-3.674-13.46-9.392-15.321-16.995l-1.57-6.417c0-.001-.001-.003-.001-.004-.968-3.945-4.481-6.7-8.543-6.7-4.061 0-7.574 2.755-8.543 6.704l-1.57 6.417c-1.861 7.603-7.016 13.321-15.321 16.995-.391.173-.768.38-1.124.617-2.526 1.683-4.034 4.5-4.035 7.536 0 3.035 1.507 5.853 4.033 7.537.357.238.734.445 1.126.619 8.305 3.674 13.46 9.393 15.321 16.995l1.571 6.422c.968 3.945 4.481 6.701 8.542 6.701 4.062 0 7.575-2.755 8.544-6.705l1.57-6.417c1.861-7.602 7.016-13.321 15.321-16.995 2.484-1.19 4.731-3.782 5.159-8.156-.001-3.037-1.509-5.855-4.035-7.537zm-26.559 18.319c-2.502-4.115-5.799-7.731-9.834-10.783 4.035-3.052 7.331-6.667 9.833-10.783 2.502 4.115 5.799 7.731 9.834 10.783-4.035 3.053-7.332 6.668-9.833 10.783z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m217.425 159.96c-8.305-3.674-13.46-9.392-15.321-16.996l-1.571-6.416c-.966-3.948-4.479-6.705-8.543-6.705s-7.577 2.757-8.543 6.704l-1.571 6.418c-1.861 7.603-7.016 13.322-15.321 16.995-.392.174-.769.381-1.126.619-2.526 1.684-4.033 4.502-4.033 7.537.001 3.035 1.509 5.853 4.035 7.536.356.238.733.444 1.124.617 8.305 3.674 13.46 9.392 15.321 16.996l1.571 6.416c.966 3.948 4.479 6.705 8.543 6.705s7.577-2.757 8.543-6.703l1.571-6.417c1.861-7.603 7.016-13.321 15.321-16.996 2.483-1.189 4.729-3.78 5.159-8.153-.023-2.213-1.512-6.435-5.159-8.157zm-25.436 18.938c-2.502-4.115-5.799-7.732-9.833-10.783 4.035-3.052 7.331-6.668 9.833-10.783 2.502 4.115 5.798 7.732 9.833 10.783-4.034 3.051-7.331 6.668-9.833 10.783z"
      })]
    })
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-7.js



function Dent_Icon_7_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_7_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_7_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_7_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_7_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_7_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon7(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", Dent_Icon_7_objectSpread(Dent_Icon_7_objectSpread({
    version: "1.1",
    id: "Capa_1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    x: "0px",
    y: "0px",
    width: "423.714px",
    height: "423.713px",
    viewBox: "0 0 423.714 423.713",
    xmlSpace: "preserve"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "M403.069,146.3c-14.035-15.717-33.359-24.373-54.404-24.373c-11.196,0-22.783,4.521-31.579,8.717\r c-0.479,0.228-1.497,0.417-1.525-0.551c-1.879-20.982-10.197-39.549-23.816-54.799c-16.535-18.512-39.289-28.705-64.078-28.705\r c-19.43,0-40.146,11.428-55.285,19.781c-4.596,2.535-12.137,7.176-14.338,7.176c-2.189,0-9.666-4.613-14.275-7.16\r c-15.1-8.355-35.779-19.797-55.346-19.797c-24.787,0-47.543,10.193-64.078,28.705C8.645,92.87,0,115.999,0,140.415\r c0,34.526,12.373,83.566,33.096,131.184c9.223,21.195,19.051,39.523,28.418,53.004c11.404,16.41,21.348,24.387,30.398,24.387\r c4.186,0,11.84-1.732,16.041-13.354c3.77-10.431,7.152-22.361,10.756-35.078c8.842-31.215,20.953-73.97,38.734-73.97\r c0,0,1.813,0.058,1.935,1.571c3.887,25.74,12.749,54.335,25.468,83.562c7.75,17.807,16.01,33.211,23.889,44.549\r c9.755,14.033,18.355,20.855,26.291,20.855c3.775,0,10.669-1.541,14.398-11.861c3.174-8.779,6.012-18.795,9.027-29.432\r c7.311-25.814,17.326-61.168,31.432-61.168h1.006c6.063,0,11.689,5.614,17.201,17.164c5.805,12.154,10.258,28.465,14.563,44.242\r c2.881,10.549,5.602,20.514,8.684,29.16c3.66,10.271,10.492,11.811,14.24,11.812c7.908,0,16.504-6.926,26.274-21.17\r c7.857-11.451,16.134-27.004,23.935-44.977c17.485-40.303,27.928-81.199,27.928-109.396\r C423.712,180.806,416.382,161.202,403.069,146.3z M157.056,201.5c0,2.638,0.089,5.424,0.264,8.316\r c0.016,0.255,0.187,1.12-1.063,1.036c-14.01,0.035-24.421,9.605-34.112,29.804c-7.578,15.795-13.299,35.999-18.832,55.537\r l-0.039,0.139c-3.496,12.332-6.797,23.979-10.371,33.857c-0.473,1.311-0.812,2.537-1.342,2.707\r c-1.418,0.455-6.863-2.979-16.904-17.426c-8.654-12.455-18.201-30.304-26.887-50.261c-19.596-45.024-31.768-92.844-31.768-124.797\r c0-38.254,27.09-77.822,72.42-77.822c11.752,0,27.258,5.395,41.479,14.431c2.063,1.31,5.023,3.586,7.887,5.786\r c1.156,0.891,2.295,1.766,3.357,2.566c3.432,2.567,8.064,5.926,13.504,9.127c2.859,1.689,5.463,3.188,8.373,4.426\r c11.799,5.006,24.307,7.547,37.176,7.547c13.143,0,32.481-3.379,32.162-6.004c-0.318-2.624-23.645,1.131-47.869-6.721\r c-6.293-2.04-14.404-4.33-14.4-6.898c0.001-0.708,2.279-1.958,3.887-2.918c1.717-1.025,3.664-2.189,6.143-3.557\r c13.604-7.506,32.236-17.785,47.547-17.785c44.52,0,71.442,38.162,72.394,75.763c0.012,0.418,0.072,1.185-0.772,1.701\r c-2.89,1.586-7.147,4.404-8.903,4.404c-1.993,0-8.297-4.088-11.459-5.836c-12.734-7.047-30.176-16.697-46.817-16.697\r c-21.047,0-40.37,8.656-54.407,24.373C164.386,161.202,157.056,180.806,157.056,201.5z M381.601,304.743\r c-7.305,16.838-15.295,31.891-22.496,42.385c-6.455,9.41-10.564,15.117-12.349,13.975c-0.503-0.322-1.264-2.223-1.447-2.74\r c-2.881-8.084-4.939-16.096-7.743-26.363c-4.483-16.432-9.123-33.422-15.524-46.832c-8.344-17.469-18.533-25.961-31.152-25.961\r h-1.006c-12.191,0-22.162,8.426-30.479,25.76c-6.375,13.289-11.181,30.248-15.826,46.654c-2.934,10.346-5.701,20.117-8.691,28.389\r c-0.207,0.576-0.512,1.232-0.845,1.379c-1.451,0.631-5.603-3.852-12.612-13.939c-7.203-10.361-15.16-25.24-22.408-41.893\r c-16.35-37.57-26.506-77.441-26.506-104.056c0-31.517,22.289-64.115,59.59-64.115c9.648,0,22.423,4.457,34.168,11.92\r c1.675,1.063,4.109,2.935,6.503,4.773c0.979,0.754,1.944,1.494,2.846,2.17c2.881,2.162,6.781,4.99,11.397,7.707\r c2.433,1.436,4.646,2.709,7.132,3.764c10.004,4.246,20.606,6.4,31.52,6.4c11.176,0,32.66-3.158,32.438-6.729\r c-0.143-2.289-24.143,0.711-45.319-5.95c-4.304-1.354-10.431-3.472-10.583-4.292c-0.145-0.771,1.271-1.58,2.054-2.048\r c1.426-0.852,3.041-1.816,5.103-2.953c11.291-6.23,26.754-14.762,39.307-14.762c37.301,0,59.59,32.599,59.59,64.115\r C408.255,227.299,398.042,266.86,381.601,304.743z"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {})]
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-8.js



function Dent_Icon_8_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_8_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_8_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_8_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_8_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_8_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon8(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", Dent_Icon_8_objectSpread(Dent_Icon_8_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 512 512",
    height: "512",
    viewBox: "0 0 512 512",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m489.5 18h-147c-12.407 0-22.5 10.093-22.5 22.5v29.5h-57.5c-37.22 0-67.5 30.28-67.5 67.5v44.5h-32.5c-6.893 0-12.5 5.607-12.5 12.5v20c0 6.893 5.607 12.5 12.5 12.5h32.5v15h-84.06c-.914 0-1.756-.5-2.196-1.3l-52.818-96.198c-.606-1.103-.926-2.351-.926-3.609v-43.393c0-7.409-2.906-14.358-8.182-19.566-5.274-5.208-12.235-8.013-19.671-7.931-14.969.188-27.147 12.755-27.147 28.014v49.263c0 6.292 1.599 12.532 4.626 18.049l55.909 101.839c8.973 16.352 25.225 27.191 43.465 29.405v12.179c0 37.495 30.505 68 68 68 12.536 0 24.281-3.424 34.375-9.364l65.207 57.779-207.11 19.381c-16.802 1.572-29.472 15.483-29.472 32.359v4.593c0 6.893 5.607 12.5 12.5 12.5h23.513c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5h-21.013v-2.093c0-9.087 6.822-16.577 15.869-17.424l216.131-20.227v39.744h-175.987c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h324.487c9.649 0 17.5-7.851 17.5-17.5v-24.711c0-55.024-44.765-99.789-99.789-99.789h-55.867l-52.344-46.382v-8.618h61.19c5.41 0 10.769 1.359 15.502 3.932l81.158 44.044c4.03 2.182 8.557 3.334 13.09 3.334 10.296 0 19.649-5.677 24.411-14.814.001-.002.002-.004.003-.006 6.873-13.217 1.62-29.853-11.707-37.082l-80.717-43.808c-12.764-6.934-27.198-10.6-41.74-10.6h-61.19v-15h81.5c6.893 0 12.5-5.607 12.5-12.5v-20c0-6.893-5.607-12.5-12.5-12.5h-54c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h51.5v15h-154v-15h67.5c4.142 0 7.5-3.358 7.5-7.5v-52c0-12.407 10.093-22.5 22.5-22.5h57.5v29.5c0 12.407 10.093 22.5 22.5 22.5h147c12.407 0 22.5-10.093 22.5-22.5v-104c0-12.407-10.093-22.5-22.5-22.5zm-251.267 306.094 43.767 38.781v51.479l-63.385-56.164c9.586-9.043 16.545-20.829 19.618-34.096zm109.978 42.906c46.753 0 84.789 38.036 84.789 84.789v24.711c0 1.378-1.122 2.5-2.5 2.5h-133.5v-47.906c0-.003 0-.007 0-.01v-64.084zm-123.211-58.249c0 29.224-23.776 53-53 53s-53-23.775-53-53v-11.751h15v12c0 20.953 17.047 38 38 38s38-17.047 38-38v-12h15zm-76-11.751h46v12c0 12.682-10.318 23-23 23s-23-10.318-23-23zm186.772-31.218 80.722 43.811c6.183 3.354 8.674 10.965 5.555 16.971-2.168 4.161-6.425 6.746-11.109 6.746-2.077 0-4.079-.514-5.942-1.522l-81.146-44.038c-6.921-3.762-14.757-5.75-22.662-5.75h-190.25c-15.517 0-29.792-8.448-37.256-22.049l-55.908-101.839c-1.816-3.31-2.776-7.055-2.776-10.832v-49.263c0-7.091 5.534-12.93 12.337-13.016 6.768-.232 12.808 5.725 12.663 12.499v43.393c0 3.775.96 7.52 2.777 10.829l52.821 96.203c3.08 5.597 8.958 9.075 15.341 9.075h190.25c12.05 0 24.008 3.036 34.583 8.782zm-110.772-23.782h-15v-15h15zm37.5-142c-20.678 0-37.5 16.822-37.5 37.5v44.5h-15v-44.5c0-28.949 23.551-52.5 52.5-52.5h57.5v15zm234.5 44.5c0 4.136-3.364 7.5-7.5 7.5h-147c-4.136 0-7.5-3.364-7.5-7.5v-104c0-4.136 3.364-7.5 7.5-7.5h147c4.136 0 7.5 3.364 7.5 7.5z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m471.5 48h-111c-5.79 0-10.5 4.71-10.5 10.5v68c0 5.79 4.71 10.5 10.5 10.5h111c5.79 0 10.5-4.71 10.5-10.5v-68c0-5.79-4.71-10.5-10.5-10.5zm-4.5 74h-102v-59h102z"
      })]
    })
  }));
}
// CONCATENATED MODULE: ./src/images/Dent-Icon-9.js



function Dent_Icon_9_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dent_Icon_9_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dent_Icon_9_ownKeys(Object(source), true).forEach(function (key) { Dent_Icon_9_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dent_Icon_9_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dent_Icon_9_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function DentIcon9(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", Dent_Icon_9_objectSpread(Dent_Icon_9_objectSpread({
    id: "Capa_1",
    enableBackground: "new 0 0 512 512",
    height: "512",
    viewBox: "0 0 512 512",
    width: "512",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m511.998 238.839c0-54.239-7.525-95.383-35.005-119.771-36.689-32.561-92.582-31.541-158.778-28.75-19.656.828-39.981 1.685-61.007 1.685-23.205 0-45.593-1.251-67.243-2.462-63.987-3.579-119.244-6.666-154.157 26.348-9.366 8.857-16.998 20.28-22.622 33.634-.144.304.111-.313 0 0-8.782 21.348-13.186 49.206-13.186 83.906 0 45.795 21.201 90.031 60.008 124.206 49.894 43.939 123.162 66.952 190.548 66.952 14.857 0 33.309-.939 54.978-3.815 57.524-7.634 109.815-30.204 147.242-63.553 35.286-31.443 56.165-76.618 59.222-118.38.004-.043 0 3.576 0 0zm-264.099-14.343h-74.869v-25.912h26.659v2.943c0 5.568 4.515 10.083 10.083 10.083s10.083-4.515 10.083-10.083v-2.943h28.045v25.912zm-95.035 0h-61.105v-25.912h26.793v2.943c0 5.568 4.515 10.083 10.083 10.083s10.083-4.515 10.083-10.083v-2.943h14.146zm-121.375-66.153c6.947-7.74 18.844-12.853 30.224-12.853 7.007 0 13.72 1.924 19.548 5.51-5.458 8.148-8.714 17.536-9.478 27.418h-20.779c-5.568 0-10.083 4.515-10.083 10.083s4.515 10.083 10.083 10.083h20.589v25.912h-51.32c.653-27.2 4.36-49.137 11.216-66.153zm381.808-1.815c.137.144-.143-.137 0 0 5.826 5.957 9.635 13.736 10.611 21.891h-24.252v-7.451c0-5.568-4.515-10.083-10.083-10.083s-10.083 4.515-10.083 10.083v7.451h-16.39v-1.091c0-6.976-1.39-13.63-3.892-19.714 7.066-7.733 16.93-12.12 27.552-12.12 9.92 0 19.471 4.053 26.537 11.034zm-70.363 20.8v1.091h-25.917v-7.451c0-5.568-4.515-10.083-10.083-10.083s-10.083 4.515-10.083 10.083v7.451h-28.788v-1.091c0-17.553 14.28-31.833 31.833-31.833h11.203c17.555-.001 31.835 14.28 31.835 31.833zm-95.035 1.091h-28.045v-7.451c0-5.568-4.515-10.083-10.083-10.083s-10.083 4.515-10.083 10.083v7.451h-26.659v-1.091c0-17.553 14.28-31.833 31.834-31.833h11.202c17.553 0 31.833 14.28 31.833 31.833v1.091zm-95.035-1.091v1.091h-14.146v-7.451c0-5.568-4.515-10.083-10.083-10.083s-10.083 4.515-10.083 10.083v7.451h-26.513c.987-8.226 4.773-15.979 10.706-21.955.083-.083-.079.086 0 0 7.05-6.995 16.514-10.97 26.451-10.97 10.606 0 20.475 4.384 27.563 12.113-2.504 6.085-3.895 12.742-3.895 19.721zm115.2 21.256h28.788v2.943c0 5.568 4.515 10.083 10.083 10.083s10.083-4.515 10.083-10.083v-2.943h25.917v25.912h-74.87v-25.912zm95.036 0h16.391v2.943c0 5.568 4.515 10.083 10.083 10.083s10.083-4.515 10.083-10.083v-2.943h24.53v25.912h-61.087zm81.253 0h17.344c5.568 0 10.083-4.515 10.083-10.083s-4.515-10.083-10.083-10.083h-17.534c-.762-9.881-4.008-19.271-9.456-27.423 5.821-3.582 12.529-5.505 19.536-5.505 13.471 0 21.791 5.622 22.076 5.759 9.02 16.496 14.103 38.737 15.387 67.19-.006.144-.022.285-.022.43v5.626h-47.331zm-309.595-90.989c16.875 0 35.066 1.016 54.082 2.08 21.927 1.226 44.6 2.493 68.369 2.493 21.449 0 41.99-.865 61.855-1.702 54.722-2.308 102.801-4.315 133.326 14.904-11.612.365-22.627 4.15-31.887 10.881-9.764-7.087-21.461-10.922-33.744-10.922-14.688 0-28.448 5.439-38.98 15.178-9.41-9.374-22.379-15.178-36.679-15.178h-11.203c-17.186 0-32.443 8.385-41.916 21.273-9.473-12.888-24.731-21.273-41.916-21.273h-11.202c-14.3 0-27.269 5.804-36.679 15.177-10.55-9.738-24.314-15.177-38.988-15.177-12.29 0-23.985 3.836-33.736 10.922-9.761-7.091-21.459-10.926-33.747-10.926-2.075 0-4.155.126-6.227.344 19.348-14.332 46.895-18.074 79.272-18.074zm168.123 293.187c-65.264 7.85-142.229-1.561-209.289-42.509 5.293-5.726 15.635-15.507 31.94-25.204 23.288-13.85 63.862-30.36 124.915-30.36 61.205 0 105.69 16.748 132.23 30.798 17.38 9.201 29.554 18.477 36.511 24.421-32.106 22.054-72.432 37.576-116.307 42.854zm136.478-58.619c-1.247 1.111-2.518 2.206-3.802 3.292-7.107-6.44-21.203-17.877-42.495-29.265-28.7-15.35-76.741-33.647-142.616-33.647-107.298 0-158.257 46.796-173.014 63.481-1.368-1.147-2.722-2.304-4.049-3.48-31.09-27.559-49.526-61.955-52.719-97.882h413.606 57.271c-3.167 35.823-21.414 70.085-52.182 97.501z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        d: "m349.127 340.743c-27.91-11.332-57.307-17.235-87.375-17.543-15.766-.174-31.615 1.255-47.129 4.216-5.471 1.044-9.059 6.323-8.014 11.793 1.044 5.47 6.322 9.065 11.793 8.014 14.203-2.709 28.714-4.006 43.142-3.86 27.527.283 54.442 5.687 79.997 16.064 5.374 2.18 11.646-.771 13.403-6.291 1.575-4.947-1.01-10.441-5.817-12.393z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("circle", {
        cx: "173.255",
        cy: "350.086",
        r: "10"
      })]
    })
  }));
}
// CONCATENATED MODULE: ./src/images/IconCentre.js










const IconCentre = {
  default: DentIcon1,
  dentalCare: DentIcon2,
  tooth: DentIcon3,
  tooth2: DentIcon4,
  dentalVeneer: DentIcon5,
  dentalInsurance: DentIcon6,
  pairOfMolars: DentIcon7,
  dentistChair: DentIcon8,
  braces: DentIcon9,
  dentalCheckup: DentIcon10
};
/* harmony default export */ var images_IconCentre = __webpack_exports__["a"] = (IconCentre);

/***/ }),

/***/ "UhrY":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ "UlpK":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "X24+":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "YTqd":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "a6qw":
/***/ (function(module, exports) {



/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cDf5":
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("284h");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__("cDcd"));

var _router = __webpack_require__("elyg");

var _router2 = __webpack_require__("nOHt");

var _useIntersection = __webpack_require__("vNVm");

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (false) {}
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (false) {}

  const p = props.prefetch !== false;
  const router = (0, _router2.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(pathname, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(pathname, props.as) : resolvedAs || resolvedHref
    };
  }, [pathname, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  (0, _react.useEffect)(() => {
    const shouldPrefetch = isVisible && p && (0, _router.isLocalURL)(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);
  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router.isLocalURL)(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router.getDomainLocale)(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router.addBasePath)((0, _router.addLocale)(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "dQHF":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__("8OQS"));

var _extends2 = _interopRequireDefault(__webpack_require__("pVnL"));

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _head = _interopRequireDefault(__webpack_require__("UlpK"));

var _toBase = __webpack_require__("7UUK");

var _imageConfig = __webpack_require__("ANQk");

var _useIntersection = __webpack_require__("vNVm");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default"} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const percentSizes = [...sizes.matchAll(/(^|\s)(1?\d?\d)vw/g)].map(m => parseInt(m[2]));

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (false) {}

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (false) {}
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, !isVisible && /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    src: src,
    decoding: "async",
    sizes: sizes,
    style: imgStyle,
    className: className
  }))), /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: setRef,
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (false) {}

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "dZ6Y":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "elyg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__("X24+");

var _routeLoader = __webpack_require__("Nh2W");

var _denormalizePagePath = __webpack_require__("wkBG");

var _normalizeLocalePath = __webpack_require__("3wub");

var _mitt = _interopRequireDefault(__webpack_require__("dZ6Y"));

var _utils = __webpack_require__("g/15");

var _isDynamic = __webpack_require__("/jkW");

var _parseRelativeUrl = __webpack_require__("hS4m");

var _querystring = __webpack_require__("3WeD");

var _resolveRewrites = _interopRequireDefault(__webpack_require__("GXs3"));

var _routeMatcher = __webpack_require__("gguc");

var _routeRegex = __webpack_require__("YTqd");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {}

  return false;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href, resolveAs) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href); // Return because it cannot be routed by the Next.js router

  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils.getLocationOrigin)();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router.pathname, url, true);
  const origin = (0, _utils.getLocationOrigin)();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router.pathname, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
}

const manualScrollRestoration =  false && false;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader.markAssetError)(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  // In-flight Server Data Requests, for deduping
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sdr = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;
    this.domainLocales = void 0;
    this.isReady = void 0;
    this.isPreview = void 0;
    this.isLocaleDomain = void 0;
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        initial: true,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic.isDynamicRoute)(_pathname) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || !autoExportDynamic && !self.location.search);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    var _options$scroll;

    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    } // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated


    if (options._h) {
      this.isReady = true;
    } // Default to scroll reset behavior unless explicitly specified to be
    // `false`! This makes the behavior between using `Router#push` and a
    // `<Link />` consistent.


    options.scroll = !!((_options$scroll = options.scroll) != null ? _options$scroll : true);
    let localeChange = options.locale !== this.locale;

    if (false) { var _this$locales; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader.getClientBuildManifest)());
    } catch (err) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname;

    if (pathname !== '/_error') {
      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname, pages);

        if (parsed.pathname !== pathname) {
          pathname = parsed.pathname;
          url = (0, _utils.formatWithValidation)(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);

    if (!isLocalURL(as)) {
      if (false) {}

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (false) {}

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var _self$__NEXT_DATA__$p, _self$__NEXT_DATA__$p2;

      let routeInfo = await this.getRouteInfo(route, pathname, query, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);

            if (pages.includes(parsedHref.pathname)) {
              const {
                url: newUrl,
                as: newAs
              } = prepareUrlAs(this, destination, destination);
              return this.change(method, newUrl, newAs, options);
            }
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (false) {} // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      if (options._h && pathname === '/_error' && ((_self$__NEXT_DATA__$p = self.__NEXT_DATA__.props) == null ? void 0 : (_self$__NEXT_DATA__$p2 = _self$__NEXT_DATA__$p.pageProps) == null ? void 0 : _self$__NEXT_DATA__$p2.statusCode) === 500 && props != null && props.pageProps) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      }

      await this.set(route, pathname, query, cleanedAs, routeInfo, forcedScroll || (isValidShallowRoute || !options.scroll ? null : {
        x: 0,
        y: 0
      })).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (false) {}

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader.isAssetError)(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component;
      let styleSheets;
      let props;

      if (typeof Component === 'undefined' || typeof styleSheets === 'undefined') {
        ;
        ({
          page: Component,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (false) {}

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname) {
        pathname = parsed.pathname;
        url = (0, _utils.formatWithValidation)(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (false) {}

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if ( true && !this.isPreview && this.sdc[cacheKey]) {
      return Promise.resolve(this.sdc[cacheKey]);
    }

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err => {
      delete this.sdr[resourceKey];
      throw err;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "fIVH":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ServiceList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return ServiceContainer; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0mz7");
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tailwind_config__WEBPACK_IMPORTED_MODULE_2__);




function ServiceList({
  icon,
  slug,
  name
}) {
  const Icon = icon;
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(next_link__WEBPACK_IMPORTED_MODULE_1___default.a, {
    href: `/layanan/${slug}`,
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("a", {
      className: "group hover:shadow-lg cursor-pointer bg-grayscale-100 py-4 px-5 rounded-lg text-grayscale-800 font-bold arimo flex lg:text-lg items-center",
      title: name,
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("span", {
        className: "w-10 h-10 rounded-full border border-primary-400 flex justify-center items-center",
        children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(Icon, {
          width: 24,
          height: 24,
          fill: _tailwind_config__WEBPACK_IMPORTED_MODULE_2__["theme"].colors.primary[400]
        })
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("span", {
        className: "ml-3 flex-1",
        children: name
      })]
    })
  });
}
function ServiceContainer({
  className,
  children
}) {
  let css = "mx-5 xl:mx-12 grid grid-flow-row gap-5 xl:gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3";

  if (className) {
    css += ` ${className}`;
  }

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: css,
    children: children
  });
}

/***/ }),

/***/ "g/15":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__("6D7l");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (false) { var _App$prototype; } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (false) {}

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (false) {}

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "gguc":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "hS4m":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__("g/15");

var _querystring = __webpack_require__("3WeD");
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/


function parseRelativeUrl(url, base) {
  const globalBase = new URL(true ? 'http://n' : undefined);
  const resolvedBase = base ? new URL(base, globalBase) : globalBase;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin
  } = new URL(url, resolvedBase);

  if (origin !== globalBase.origin) {
    throw new Error(`invariant: invalid relative URL, router received ${url}`);
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(globalBase.origin.length)
  };
}

/***/ }),

/***/ "nOHt":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("284h");

var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router2 = _interopRequireWildcard(__webpack_require__("elyg"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__("Osoz");

var _withRouter = _interopRequireDefault(__webpack_require__("0Bsm"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "pVnL":
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "ul+n":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const service = axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseURL: "https://admin.zaharadental.com" + "/api"
});
/* harmony default export */ __webpack_exports__["a"] = (service);

/***/ }),

/***/ "vNVm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__("cDcd");

var _requestIdleCallback = __webpack_require__("0G5g");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "wcCm":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Container; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function Container(_ref) {
  let {
    className,
    children
  } = _ref,
      props = _objectWithoutProperties(_ref, ["className", "children"]);

  let styling = "xl:w-1024 mx-6 lg:mx-16 xl:mx-auto " + className;
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    className: styling,
    children: children
  });
}

/***/ }),

/***/ "wkBG":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });
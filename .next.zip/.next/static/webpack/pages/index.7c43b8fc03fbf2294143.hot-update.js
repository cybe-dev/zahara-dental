webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_images_Background__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../src/images/Background */ "./src/images/Background.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../tailwind.config */ "./tailwind.config.js");
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tailwind_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _src_components_Container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/components/Container */ "./src/components/Container.jsx");
/* harmony import */ var _src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/components/SocialMediaButton */ "./src/components/SocialMediaButton.jsx");
/* harmony import */ var _src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/components/WhyChoose */ "./src/components/WhyChoose.jsx");
/* harmony import */ var _src_images_BackgroundMobile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../src/images/BackgroundMobile */ "./src/images/BackgroundMobile.js");
/* harmony import */ var _src_images_Welcome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/images/Welcome */ "./src/images/Welcome.js");
/* harmony import */ var _src_components_Service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../src/components/Service */ "./src/components/Service.jsx");
/* harmony import */ var _src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../src/components/Gallery */ "./src/components/Gallery.jsx");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _src_images_Instagram__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../src/images/Instagram */ "./src/images/Instagram.js");
/* harmony import */ var _src_images_Facebook__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../src/images/Facebook */ "./src/images/Facebook.js");
/* harmony import */ var _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../src/images/IconCentre */ "./src/images/IconCentre.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-responsive-carousel/lib/styles/carousel.min.css */ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react-responsive-carousel */ "./node_modules/react-responsive-carousel/lib/js/index.js");
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _src_components_Embed__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../src/components/Embed */ "./src/components/Embed.js");



var _jsxFileName = "C:\\reactprojects\\zahara\\frontend-public\\pages\\index.js",
    _s = $RefreshSig$();
















 // requires a loader




var __N_SSP = true;
function Home(_ref) {
  _s();

  var _this = this,
      _basicInformation$log;

  var basicInformation = _ref.basicInformation,
      kelebihan = _ref.kelebihan,
      services = _ref.services,
      gallery = _ref.gallery,
      pages = _ref.pages,
      slider = _ref.slider;
  var counter = Object(react__WEBPACK_IMPORTED_MODULE_18__["useRef"])(0);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_11___default.a, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: basicInformation.clinicName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_Background__WEBPACK_IMPORTED_MODULE_1__["default"], {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 hidden lg:block",
      fill: _tailwind_config__WEBPACK_IMPORTED_MODULE_3__["theme"].colors.background
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_BackgroundMobile__WEBPACK_IMPORTED_MODULE_7__["default"], {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 block lg:hidden",
      fill: _tailwind_config__WEBPACK_IMPORTED_MODULE_3__["theme"].colors.background
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "h-screen relative",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        className: "text-grayscale-800 z-10 flex items-center h-full relative",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:w-1/2",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_Welcome__WEBPACK_IMPORTED_MODULE_8__["default"], {
            className: "text-primary-100 mb-5 w-1/2 md:w-1/3 lg:w-2/4 mx-auto lg:mx-0 h-auto"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            className: "font-bold text-xl lg:text-2xl xl:text-3xl poppins mb-3 text-center lg:text-left text-grayscale-800",
            children: "Selamat Datang!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
            className: "text-grayscale-700 text-center lg:text-left",
            children: basicInformation.welcomeText
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 102,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute right-0 z-10 top-0 bottom-0 items-center pt-16 hidden lg:flex w-64",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "lg:p-2 xl:p-5 bg-grayscale-100 shadow-lg rounded-lg",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__["Carousel"], {
              showThumbs: false,
              showStatus: false,
              autoPlay: true,
              infiniteLoop: true,
              interval: 3000,
              swipeable: true,
              showArrows: false,
              children: slider === null || slider === void 0 ? void 0 : slider.map(function (item, index) {
                var _item$thumbnail;

                return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
                    unoptimized: true,
                    src: ((_item$thumbnail = item.thumbnail) === null || _item$thumbnail === void 0 ? void 0 : _item$thumbnail.replace("public", "https://admin.zaharadental.com")) || "/images/dentist.jpg",
                    alt: item.title,
                    width: 240,
                    height: 320,
                    className: "rounded-lg",
                    objectFit: "cover"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 119,
                    columnNumber: 21
                  }, _this)
                }, "".concat(index), false, {
                  fileName: _jsxFileName,
                  lineNumber: 118,
                  columnNumber: 19
                }, _this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 108,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 107,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "bg-grayscale-100 py-10",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Mengapa Memilih Klinik Kami?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 142,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__["default"], {
          children: kelebihan === null || kelebihan === void 0 ? void 0 : kelebihan.map(function (item, index) {
            if (counter.current + 1 > 4) {
              counter.current = 1;
            } else {
              counter.current = counter.current + 1;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__["WhyChooseList"], {
              icon: _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__["default"][item.thumbnail || "default"],
              title: item.title,
              right: counter.current > 2,
              children: item.text
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 153,
              columnNumber: 17
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 140,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "py-16",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Our Services"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Service__WEBPACK_IMPORTED_MODULE_9__["default"], {
          className: "mt-16",
          children: services === null || services === void 0 ? void 0 : services.map(function (item, index) {
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Service__WEBPACK_IMPORTED_MODULE_9__["ServiceList"], {
              icon: _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__["default"][item.thumbnail || "default"],
              name: item.title,
              slug: item.slug
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 173,
              columnNumber: 15
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 171,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 167,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 166,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "py-20 bg-grayscale-100",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Galeri"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__["default"], {
          children: gallery === null || gallery === void 0 ? void 0 : gallery.map(function (item, index) {
            var _item$path;

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__["GalleryList"], {
              slug: item.post.slug,
              text: item.post.title,
              image: (_item$path = item.path) === null || _item$path === void 0 ? void 0 : _item$path.replace("public", "https://admin.zaharadental.com")
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 190,
              columnNumber: 15
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 188,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 183,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200 py-20",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300 mb-10",
          children: "Instagram Feeds"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Embed__WEBPACK_IMPORTED_MODULE_19__["default"], {
          refId: "cf0cdc21292e428a3a654fb046cb71e6958030a8"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 208,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 204,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        className: "z-10 relative flex flex-col lg:flex-row lg:justify-between py-20 px-3 lg:px-0",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:w-1/3 lg:mr-16",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "h-16 w-full relative",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
              unoptimized: true,
              src: basicInformation === null || basicInformation === void 0 ? void 0 : (_basicInformation$log = basicInformation.logo) === null || _basicInformation$log === void 0 ? void 0 : _basicInformation$log.replace("public", "https://admin.zaharadental.com"),
              alt: "Logo ".concat(basicInformation.clinicName),
              layout: "fill",
              objectFit: "contain",
              objectPosition: "left",
              quality: 90
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 215,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 214,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-grayscale-700 text-justify mt-5",
            children: basicInformation.description
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 228,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold mt-10",
            children: "Ikuti Kami"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 231,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-3 flex",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
              title: "Instagram ".concat(basicInformation.clinicName),
              icon: _src_images_Instagram__WEBPACK_IMPORTED_MODULE_12__["default"],
              target: "_blank",
              href: basicInformation.instagram
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 235,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
              title: "Facebook ".concat(basicInformation.clinicName),
              icon: _src_images_Facebook__WEBPACK_IMPORTED_MODULE_13__["default"],
              target: "_blank",
              className: "ml-2",
              href: basicInformation.facebook
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 241,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 234,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 213,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ml-0 lg:ml-5 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Halaman"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 251,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
            className: "mt-3",
            children: pages === null || pages === void 0 ? void 0 : pages.map(function (item, index) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_15___default.a, {
                  href: "/halaman/".concat(item.slug),
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "mt-1 block text-grayscale-700 hover:text-primary-100",
                    title: item.title,
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 256,
                    columnNumber: 21
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 255,
                  columnNumber: 19
                }, _this)
              }, "".concat(index), false, {
                fileName: _jsxFileName,
                lineNumber: 254,
                columnNumber: 17
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 252,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 250,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ml-0 lg:ml-5 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Jam Operasional"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 268,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "arimo mt-3 text-grayscale-800 flex flex-col",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              className: "font-bold",
              children: basicInformation.operationalDay
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 272,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: basicInformation.operationalHour
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 275,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 271,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "arimo mt-3 lg:w-64 flex flex-col",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              className: "text-grayscale-800 font-bold",
              children: "Alamat"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 278,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "text-grayscale-700 flex-1",
              children: [basicInformation === null || basicInformation === void 0 ? void 0 : basicInformation.address, " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 280,
                columnNumber: 45
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: basicInformation.gmaps,
                title: "Google Maps ".concat(basicInformation.clinicName),
                className: "text-primary-200",
                children: "Lihat Maps"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 281,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 279,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 277,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 267,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ml-0 lg:ml-5 mt-8 lg:mt-0",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("iframe", {
            src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.521260322283!2d106.8195613507864!3d-6.194741395493371!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5390917b759%3A0x6b45e67356080477!2sPT%20Kulkul%20Teknologi%20Internasional!5e0!3m2!1sen!2sid!4v1601138221085!5m2!1sen!2sid",
            width: "600",
            height: "450",
            frameBorder: "0",
            style: {
              border: 0
            },
            allowFullScreen: "",
            "aria-hidden": "false",
            tabIndex: "0"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 292,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 291,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 212,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 211,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Home, "3iz0ofrn4gTwn024PSoRDlWOdB8=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiSG9tZSIsImJhc2ljSW5mb3JtYXRpb24iLCJrZWxlYmloYW4iLCJzZXJ2aWNlcyIsImdhbGxlcnkiLCJwYWdlcyIsInNsaWRlciIsImNvdW50ZXIiLCJ1c2VSZWYiLCJjbGluaWNOYW1lIiwidGhlbWUiLCJjb2xvcnMiLCJiYWNrZ3JvdW5kIiwid2VsY29tZVRleHQiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJ0aHVtYm5haWwiLCJyZXBsYWNlIiwicHJvY2VzcyIsInRpdGxlIiwiY3VycmVudCIsIkljb25DZW50cmUiLCJ0ZXh0Iiwic2x1ZyIsInBvc3QiLCJwYXRoIiwibG9nbyIsImRlc2NyaXB0aW9uIiwiSW5zdGFncmFtIiwiaW5zdGFncmFtIiwiRmFjZWJvb2siLCJmYWNlYm9vayIsIm9wZXJhdGlvbmFsRGF5Iiwib3BlcmF0aW9uYWxIb3VyIiwiYWRkcmVzcyIsImdtYXBzIiwiYm9yZGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVnRTs7QUFDaEU7QUFDQTtBQUNBOztBQXFEZSxTQUFTQSxJQUFULE9BT1o7QUFBQTs7QUFBQTtBQUFBOztBQUFBLE1BTkRDLGdCQU1DLFFBTkRBLGdCQU1DO0FBQUEsTUFMREMsU0FLQyxRQUxEQSxTQUtDO0FBQUEsTUFKREMsUUFJQyxRQUpEQSxRQUlDO0FBQUEsTUFIREMsT0FHQyxRQUhEQSxPQUdDO0FBQUEsTUFGREMsS0FFQyxRQUZEQSxLQUVDO0FBQUEsTUFEREMsTUFDQyxRQUREQSxNQUNDO0FBQ0QsTUFBTUMsT0FBTyxHQUFHQyxxREFBTSxDQUFDLENBQUQsQ0FBdEI7QUFDQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLGlEQUFEO0FBQUEsNkJBQ0U7QUFBQSxrQkFBUVAsZ0JBQWdCLENBQUNRO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFJRSxxRUFBQyw4REFBRDtBQUNFLGVBQVMsRUFBQyw0RUFEWjtBQUVFLFVBQUksRUFBRUMsc0RBQUssQ0FBQ0MsTUFBTixDQUFhQztBQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkYsZUFRRSxxRUFBQyxvRUFBRDtBQUNFLGVBQVMsRUFBQyw0RUFEWjtBQUVFLFVBQUksRUFBRUYsc0RBQUssQ0FBQ0MsTUFBTixDQUFhQztBQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUkYsZUFZRTtBQUFLLGVBQVMsRUFBQyxtQkFBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQVcsaUJBQVMsRUFBQywyREFBckI7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsVUFBZjtBQUFBLGtDQUNFLHFFQUFDLDJEQUFEO0FBQVMscUJBQVMsRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBRUU7QUFBSSxxQkFBUyxFQUFDLG9HQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGLGVBS0U7QUFBSSxxQkFBUyxFQUFDLDZDQUFkO0FBQUEsc0JBQ0dYLGdCQUFnQixDQUFDWTtBQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQVVFO0FBQUssbUJBQVMsRUFBQyw2RUFBZjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxxREFBZjtBQUFBLG1DQUNFLHFFQUFDLG1FQUFEO0FBQ0Usd0JBQVUsRUFBRSxLQURkO0FBRUUsd0JBQVUsRUFBRSxLQUZkO0FBR0Usc0JBQVEsRUFBRSxJQUhaO0FBSUUsMEJBQVksRUFBRSxJQUpoQjtBQUtFLHNCQUFRLEVBQUUsSUFMWjtBQU1FLHVCQUFTLEVBQUUsSUFOYjtBQU9FLHdCQUFVLEVBQUUsS0FQZDtBQUFBLHdCQVNHUCxNQVRILGFBU0dBLE1BVEgsdUJBU0dBLE1BQU0sQ0FBRVEsR0FBUixDQUFZLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBOztBQUFBLG9DQUNYO0FBQUEseUNBQ0UscUVBQUMsaURBQUQ7QUFDRSwrQkFBVyxFQUFFLElBRGY7QUFFRSx1QkFBRyxFQUNELG9CQUFBRCxJQUFJLENBQUNFLFNBQUwsb0VBQWdCQyxPQUFoQixDQUNFLFFBREYsRUFFRUMsZ0NBRkYsTUFHSyxxQkFOVDtBQVFFLHVCQUFHLEVBQUVKLElBQUksQ0FBQ0ssS0FSWjtBQVNFLHlCQUFLLEVBQUUsR0FUVDtBQVVFLDBCQUFNLEVBQUUsR0FWVjtBQVdFLDZCQUFTLEVBQUMsWUFYWjtBQVlFLDZCQUFTLEVBQUM7QUFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsNkJBQWFKLEtBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFEVztBQUFBLGVBQVo7QUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVpGLGVBeURFO0FBQUssZUFBUyxFQUFDLHdCQUFmO0FBQUEsNkJBQ0UscUVBQUMsaUVBQUQ7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsb0VBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFJRSxxRUFBQyxpRUFBRDtBQUFBLG9CQUNHZCxTQURILGFBQ0dBLFNBREgsdUJBQ0dBLFNBQVMsQ0FBRVksR0FBWCxDQUFlLFVBQUNDLElBQUQsRUFBT0MsS0FBUCxFQUFpQjtBQUMvQixnQkFBSVQsT0FBTyxDQUFDYyxPQUFSLEdBQWtCLENBQWxCLEdBQXNCLENBQTFCLEVBQTZCO0FBQzNCZCxxQkFBTyxDQUFDYyxPQUFSLEdBQWtCLENBQWxCO0FBQ0QsYUFGRCxNQUVPO0FBQ0xkLHFCQUFPLENBQUNjLE9BQVIsR0FBa0JkLE9BQU8sQ0FBQ2MsT0FBUixHQUFrQixDQUFwQztBQUNEOztBQUNELGdDQUNFLHFFQUFDLHVFQUFEO0FBRUUsa0JBQUksRUFBRUMsK0RBQVUsQ0FBQ1AsSUFBSSxDQUFDRSxTQUFMLElBQWtCLFNBQW5CLENBRmxCO0FBR0UsbUJBQUssRUFBRUYsSUFBSSxDQUFDSyxLQUhkO0FBSUUsbUJBQUssRUFBRWIsT0FBTyxDQUFDYyxPQUFSLEdBQWtCLENBSjNCO0FBQUEsd0JBTUdOLElBQUksQ0FBQ1E7QUFOUix5QkFDVVAsS0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBVUQsV0FoQkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF6REYsZUFtRkU7QUFBSyxlQUFTLEVBQUMsT0FBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLG9FQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUscUVBQUMsK0RBQUQ7QUFBa0IsbUJBQVMsRUFBQyxPQUE1QjtBQUFBLG9CQUNHYixRQURILGFBQ0dBLFFBREgsdUJBQ0dBLFFBQVEsQ0FBRVcsR0FBVixDQUFjLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBLGdDQUNiLHFFQUFDLG1FQUFEO0FBRUUsa0JBQUksRUFBRU0sK0RBQVUsQ0FBQ1AsSUFBSSxDQUFDRSxTQUFMLElBQWtCLFNBQW5CLENBRmxCO0FBR0Usa0JBQUksRUFBRUYsSUFBSSxDQUFDSyxLQUhiO0FBSUUsa0JBQUksRUFBRUwsSUFBSSxDQUFDUztBQUpiLHlCQUNVUixLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRGE7QUFBQSxXQUFkO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbkZGLGVBb0dFO0FBQUssZUFBUyxFQUFDLHdCQUFmO0FBQUEsNkJBQ0UscUVBQUMsaUVBQUQ7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsb0VBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFJRSxxRUFBQyxnRUFBRDtBQUFBLG9CQUNHWixPQURILGFBQ0dBLE9BREgsdUJBQ0dBLE9BQU8sQ0FBRVUsR0FBVCxDQUFhLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBOztBQUFBLGdDQUNaLHFFQUFDLG9FQUFEO0FBRUUsa0JBQUksRUFBRUQsSUFBSSxDQUFDVSxJQUFMLENBQVVELElBRmxCO0FBR0Usa0JBQUksRUFBRVQsSUFBSSxDQUFDVSxJQUFMLENBQVVMLEtBSGxCO0FBSUUsbUJBQUssZ0JBQUVMLElBQUksQ0FBQ1csSUFBUCwrQ0FBRSxXQUFXUixPQUFYLENBQ0wsUUFESyxFQUVMQyxnQ0FGSztBQUpULHlCQUNVSCxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRFk7QUFBQSxXQUFiO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcEdGLGVBd0hFO0FBQUssZUFBUyxFQUFDLCtEQUFmO0FBQUEsNkJBQ0UscUVBQUMsaUVBQUQ7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsMEVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFJRSxxRUFBQyw4REFBRDtBQUFPLGVBQUssRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXhIRixlQWdJRTtBQUFLLGVBQVMsRUFBQyx5REFBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQVcsaUJBQVMsRUFBQywrRUFBckI7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsbUJBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsc0JBQWY7QUFBQSxtQ0FDRSxxRUFBQyxpREFBRDtBQUNFLHlCQUFXLEVBQUUsSUFEZjtBQUVFLGlCQUFHLEVBQUVmLGdCQUFGLGFBQUVBLGdCQUFGLGdEQUFFQSxnQkFBZ0IsQ0FBRTBCLElBQXBCLDBEQUFFLHNCQUF3QlQsT0FBeEIsQ0FDSCxRQURHLEVBRUhDLGdDQUZHLENBRlA7QUFNRSxpQkFBRyxpQkFBVWxCLGdCQUFnQixDQUFDUSxVQUEzQixDQU5MO0FBT0Usb0JBQU0sRUFBQyxNQVBUO0FBUUUsdUJBQVMsRUFBQyxTQVJaO0FBU0UsNEJBQWMsRUFBQyxNQVRqQjtBQVVFLHFCQUFPLEVBQUU7QUFWWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQWVFO0FBQUsscUJBQVMsRUFBQyxzQ0FBZjtBQUFBLHNCQUNHUixnQkFBZ0IsQ0FBQzJCO0FBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBZkYsZUFrQkU7QUFBSSxxQkFBUyxFQUFDLDBDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWxCRixlQXFCRTtBQUFLLHFCQUFTLEVBQUMsV0FBZjtBQUFBLG9DQUNFLHFFQUFDLHlFQUFEO0FBQ0UsbUJBQUssc0JBQWUzQixnQkFBZ0IsQ0FBQ1EsVUFBaEMsQ0FEUDtBQUVFLGtCQUFJLEVBQUVvQiw4REFGUjtBQUdFLG9CQUFNLEVBQUMsUUFIVDtBQUlFLGtCQUFJLEVBQUU1QixnQkFBZ0IsQ0FBQzZCO0FBSnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFPRSxxRUFBQyx5RUFBRDtBQUNFLG1CQUFLLHFCQUFjN0IsZ0JBQWdCLENBQUNRLFVBQS9CLENBRFA7QUFFRSxrQkFBSSxFQUFFc0IsNkRBRlI7QUFHRSxvQkFBTSxFQUFDLFFBSFQ7QUFJRSx1QkFBUyxFQUFDLE1BSlo7QUFLRSxrQkFBSSxFQUFFOUIsZ0JBQWdCLENBQUMrQjtBQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBc0NFO0FBQUssbUJBQVMsRUFBQywyQkFBZjtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBQyxvQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUkscUJBQVMsRUFBQyxNQUFkO0FBQUEsc0JBQ0czQixLQURILGFBQ0dBLEtBREgsdUJBQ0dBLEtBQUssQ0FBRVMsR0FBUCxDQUFXLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBLGtDQUNWO0FBQUEsdUNBQ0UscUVBQUMsaURBQUQ7QUFBTSxzQkFBSSxxQkFBY0QsSUFBSSxDQUFDUyxJQUFuQixDQUFWO0FBQUEseUNBQ0U7QUFDRSw2QkFBUyxFQUFDLHNEQURaO0FBRUUseUJBQUssRUFBRVQsSUFBSSxDQUFDSyxLQUZkO0FBQUEsOEJBSUdMLElBQUksQ0FBQ0s7QUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLDJCQUFZSixLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRFU7QUFBQSxhQUFYO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBdENGLGVBdURFO0FBQUssbUJBQVMsRUFBQywyQkFBZjtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBQyxvQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUlFO0FBQUsscUJBQVMsRUFBQyw2Q0FBZjtBQUFBLG9DQUNFO0FBQVEsdUJBQVMsRUFBQyxXQUFsQjtBQUFBLHdCQUNHZixnQkFBZ0IsQ0FBQ2dDO0FBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFJRTtBQUFBLHdCQUFPaEMsZ0JBQWdCLENBQUNpQztBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKRixlQVVFO0FBQUsscUJBQVMsRUFBQyxrQ0FBZjtBQUFBLG9DQUNFO0FBQVEsdUJBQVMsRUFBQyw4QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFFRTtBQUFNLHVCQUFTLEVBQUMsMkJBQWhCO0FBQUEseUJBQ0dqQyxnQkFESCxhQUNHQSxnQkFESCx1QkFDR0EsZ0JBQWdCLENBQUVrQyxPQURyQixvQkFDOEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFEOUIsZUFFRTtBQUNFLG9CQUFJLEVBQUVsQyxnQkFBZ0IsQ0FBQ21DLEtBRHpCO0FBRUUscUJBQUssd0JBQWlCbkMsZ0JBQWdCLENBQUNRLFVBQWxDLENBRlA7QUFHRSx5QkFBUyxFQUFDLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXZERixlQStFRTtBQUFLLG1CQUFTLEVBQUMsMkJBQWY7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBQyxzU0FETjtBQUVFLGlCQUFLLEVBQUMsS0FGUjtBQUdFLGtCQUFNLEVBQUMsS0FIVDtBQUlFLHVCQUFXLEVBQUMsR0FKZDtBQUtFLGlCQUFLLEVBQUU7QUFBRTRCLG9CQUFNLEVBQUU7QUFBVixhQUxUO0FBTUUsMkJBQWUsRUFBQyxFQU5sQjtBQU9FLDJCQUFZLE9BUGQ7QUFRRSxvQkFBUSxFQUFDO0FBUlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBL0VGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFoSUY7QUFBQSxrQkFERjtBQWlPRDs7R0ExT3VCckMsSTs7S0FBQUEsSSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC43YzQzYjhmYzAzZmJmMjI5NDE0My5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEJhY2tncm91bmQgZnJvbSBcIi4uL3NyYy9pbWFnZXMvQmFja2dyb3VuZFwiO1xuaW1wb3J0IEltYWdlIGZyb20gXCJuZXh0L2ltYWdlXCI7XG5pbXBvcnQgeyB0aGVtZSB9IGZyb20gXCIuLi90YWlsd2luZC5jb25maWdcIjtcbmltcG9ydCBDb250YWluZXIgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL0NvbnRhaW5lclwiO1xuaW1wb3J0IFNvY2lhbE1lZGlhQnV0dG9uIGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9Tb2NpYWxNZWRpYUJ1dHRvblwiO1xuaW1wb3J0IFdoeUNob29zZUNvbnRhaW5lciwgeyBXaHlDaG9vc2VMaXN0IH0gZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL1doeUNob29zZVwiO1xuaW1wb3J0IEJhY2tncm91bmRNb2JpbGUgZnJvbSBcIi4uL3NyYy9pbWFnZXMvQmFja2dyb3VuZE1vYmlsZVwiO1xuaW1wb3J0IFdlbGNvbWUgZnJvbSBcIi4uL3NyYy9pbWFnZXMvV2VsY29tZVwiO1xuaW1wb3J0IFNlcnZpY2VDb250YWluZXIsIHsgU2VydmljZUxpc3QgfSBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvU2VydmljZVwiO1xuaW1wb3J0IEdhbGxlcnlDb250YWluZXIsIHsgR2FsbGVyeUxpc3QgfSBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvR2FsbGVyeVwiO1xuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IEluc3RhZ3JhbSBmcm9tIFwiLi4vc3JjL2ltYWdlcy9JbnN0YWdyYW1cIjtcbmltcG9ydCBGYWNlYm9vayBmcm9tIFwiLi4vc3JjL2ltYWdlcy9GYWNlYm9va1wiO1xuaW1wb3J0IEljb25DZW50cmUgZnJvbSBcIi4uL3NyYy9pbWFnZXMvSWNvbkNlbnRyZVwiO1xuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xuaW1wb3J0IHNlcnZpY2UgZnJvbSBcIi4uL3NyYy9zZXJ2aWNlXCI7XG5pbXBvcnQgXCJyZWFjdC1yZXNwb25zaXZlLWNhcm91c2VsL2xpYi9zdHlsZXMvY2Fyb3VzZWwubWluLmNzc1wiOyAvLyByZXF1aXJlcyBhIGxvYWRlclxuaW1wb3J0IHsgQ2Fyb3VzZWwgfSBmcm9tIFwicmVhY3QtcmVzcG9uc2l2ZS1jYXJvdXNlbFwiO1xuaW1wb3J0IHsgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgRW1iZWQgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL0VtYmVkXCI7XG5cbmV4cG9ydCBjb25zdCBnZXRTZXJ2ZXJTaWRlUHJvcHMgPSBhc3luYyAoKSA9PiB7XG4gIGxldCBiYXNpY0luZm9ybWF0aW9uLFxuICAgIGtlbGViaWhhbixcbiAgICBzZXJ2aWNlcyxcbiAgICBzdWJTZXJ2aWNlcyxcbiAgICBnYWxsZXJ5LFxuICAgIHBhZ2VzLFxuICAgIHNsaWRlcjtcbiAgdHJ5IHtcbiAgICBiYXNpY0luZm9ybWF0aW9uID0gKGF3YWl0IHNlcnZpY2UuZ2V0KFwiL2Jhc2ljLWluZm9ybWF0aW9uXCIpKS5kYXRhLnN1Y2Nlc3NcbiAgICAgIC5kYXRhO1xuICAgIHNlcnZpY2VzID0gKGF3YWl0IHNlcnZpY2UuZ2V0KFwiL3Bvc3QvbGF5YW5hbj9saW1pdD0xMDBcIikpLmRhdGEuc3VjY2Vzcy5kYXRhXG4gICAgICAucm93cztcbiAgICBzdWJTZXJ2aWNlcyA9IChhd2FpdCBzZXJ2aWNlLmdldChcIi9wb3N0L3N1Yi1sYXlhbmFuP2xpbWl0PTEwMCZub2Rlc2M9MVwiKSlcbiAgICAgIC5kYXRhLnN1Y2Nlc3MuZGF0YS5yb3dzO1xuICAgIGtlbGViaWhhbiA9IChhd2FpdCBzZXJ2aWNlLmdldChcIi9wb3N0L2tlbGViaWhhblwiKSkuZGF0YS5zdWNjZXNzLmRhdGEucm93cztcbiAgICBzbGlkZXIgPSAoYXdhaXQgc2VydmljZS5nZXQoXCIvcG9zdC9zbGlkZXJcIikpLmRhdGEuc3VjY2Vzcy5kYXRhLnJvd3M7XG4gICAgcGFnZXMgPSAoYXdhaXQgc2VydmljZS5nZXQoXCIvcG9zdC9oYWxhbWFuP2xpbWl0PTEwMCZub2Rlc2M9MVwiKSkuZGF0YS5zdWNjZXNzXG4gICAgICAuZGF0YS5yb3dzO1xuICAgIGdhbGxlcnkgPSAoYXdhaXQgc2VydmljZS5nZXQoXCIvZ2FsbGVyeS90eXBlL2xheWFuYW4/bGltaXQ9OFwiKSkuZGF0YS5zdWNjZXNzXG4gICAgICAuZGF0YS5yb3dzO1xuICB9IGNhdGNoIChlKSB7XG4gICAgY29uc29sZS5sb2coZSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHByb3BzOiB7XG4gICAgICAgIHN0YXR1czogNTAwLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgcHJvcHM6IHtcbiAgICAgIGJhc2ljSW5mb3JtYXRpb24sXG4gICAgICBrZWxlYmloYW4sXG4gICAgICBzZXJ2aWNlcyxcbiAgICAgIHN1YlNlcnZpY2VzLFxuICAgICAgZ2FsbGVyeSxcbiAgICAgIHBhZ2VzLFxuICAgICAgaGVhZGVyUHJvcHM6IHtcbiAgICAgICAgdHJhbnNwYXJlbnRGaXJzdDogdHJ1ZSxcbiAgICAgIH0sXG4gICAgICBzbGlkZXIsXG4gICAgICBtZXRhVGFnOiBbXG4gICAgICAgIHtcbiAgICAgICAgICBuYW1lOiBcImRlc2NyaXB0aW9uXCIsXG4gICAgICAgICAgY29udGVudDogYmFzaWNJbmZvcm1hdGlvbi5kZXNjcmlwdGlvbj8uc3Vic3RyKDAsIDE1MCkgfHwgXCJcIixcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfSxcbiAgfTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoe1xuICBiYXNpY0luZm9ybWF0aW9uLFxuICBrZWxlYmloYW4sXG4gIHNlcnZpY2VzLFxuICBnYWxsZXJ5LFxuICBwYWdlcyxcbiAgc2xpZGVyLFxufSkge1xuICBjb25zdCBjb3VudGVyID0gdXNlUmVmKDApO1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPntiYXNpY0luZm9ybWF0aW9uLmNsaW5pY05hbWV9PC90aXRsZT5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxCYWNrZ3JvdW5kXG4gICAgICAgIGNsYXNzTmFtZT1cImgtc2NyZWVuIHctZnVsbCBhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgei0wIGJnLWdyYXlzY2FsZS0xMDAgaGlkZGVuIGxnOmJsb2NrXCJcbiAgICAgICAgZmlsbD17dGhlbWUuY29sb3JzLmJhY2tncm91bmR9XG4gICAgICAvPlxuICAgICAgPEJhY2tncm91bmRNb2JpbGVcbiAgICAgICAgY2xhc3NOYW1lPVwiaC1zY3JlZW4gdy1mdWxsIGFic29sdXRlIHRvcC0wIGxlZnQtMCB6LTAgYmctZ3JheXNjYWxlLTEwMCBibG9jayBsZzpoaWRkZW5cIlxuICAgICAgICBmaWxsPXt0aGVtZS5jb2xvcnMuYmFja2dyb3VuZH1cbiAgICAgIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtc2NyZWVuIHJlbGF0aXZlXCI+XG4gICAgICAgIDxDb250YWluZXIgY2xhc3NOYW1lPVwidGV4dC1ncmF5c2NhbGUtODAwIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgaC1mdWxsIHJlbGF0aXZlXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzp3LTEvMlwiPlxuICAgICAgICAgICAgPFdlbGNvbWUgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5LTEwMCBtYi01IHctMS8yIG1kOnctMS8zIGxnOnctMi80IG14LWF1dG8gbGc6bXgtMCBoLWF1dG9cIiAvPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhsIGxnOnRleHQtMnhsIHhsOnRleHQtM3hsIHBvcHBpbnMgbWItMyB0ZXh0LWNlbnRlciBsZzp0ZXh0LWxlZnQgdGV4dC1ncmF5c2NhbGUtODAwXCI+XG4gICAgICAgICAgICAgIFNlbGFtYXQgRGF0YW5nIVxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXlzY2FsZS03MDAgdGV4dC1jZW50ZXIgbGc6dGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgIHtiYXNpY0luZm9ybWF0aW9uLndlbGNvbWVUZXh0fVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTAgei0xMCB0b3AtMCBib3R0b20tMCBpdGVtcy1jZW50ZXIgcHQtMTYgaGlkZGVuIGxnOmZsZXggdy02NFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpwLTIgeGw6cC01IGJnLWdyYXlzY2FsZS0xMDAgc2hhZG93LWxnIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgPENhcm91c2VsXG4gICAgICAgICAgICAgICAgc2hvd1RodW1icz17ZmFsc2V9XG4gICAgICAgICAgICAgICAgc2hvd1N0YXR1cz17ZmFsc2V9XG4gICAgICAgICAgICAgICAgYXV0b1BsYXk9e3RydWV9XG4gICAgICAgICAgICAgICAgaW5maW5pdGVMb29wPXt0cnVlfVxuICAgICAgICAgICAgICAgIGludGVydmFsPXszMDAwfVxuICAgICAgICAgICAgICAgIHN3aXBlYWJsZT17dHJ1ZX1cbiAgICAgICAgICAgICAgICBzaG93QXJyb3dzPXtmYWxzZX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtzbGlkZXI/Lm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtgJHtpbmRleH1gfT5cbiAgICAgICAgICAgICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICAgICAgICAgICAgdW5vcHRpbWl6ZWQ9e3RydWV9XG4gICAgICAgICAgICAgICAgICAgICAgc3JjPXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0udGh1bWJuYWlsPy5yZXBsYWNlKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcInB1YmxpY1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19CQVNFX1VSTFxuICAgICAgICAgICAgICAgICAgICAgICAgKSB8fCBcIi9pbWFnZXMvZGVudGlzdC5qcGdcIlxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2l0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg9ezI0MH1cbiAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9ezMyMH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnXCJcbiAgICAgICAgICAgICAgICAgICAgICBvYmplY3RGaXQ9XCJjb3ZlclwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9DYXJvdXNlbD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5c2NhbGUtMTAwIHB5LTEwXCI+XG4gICAgICAgIDxDb250YWluZXI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBwb3BwaW5zIHRleHQteGwgbGc6dGV4dC0yeGwgdGV4dC1jZW50ZXIgdGV4dC1wcmltYXJ5LTMwMFwiPlxuICAgICAgICAgICAgTWVuZ2FwYSBNZW1pbGloIEtsaW5payBLYW1pP1xuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPFdoeUNob29zZUNvbnRhaW5lcj5cbiAgICAgICAgICAgIHtrZWxlYmloYW4/Lm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGNvdW50ZXIuY3VycmVudCArIDEgPiA0KSB7XG4gICAgICAgICAgICAgICAgY291bnRlci5jdXJyZW50ID0gMTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb3VudGVyLmN1cnJlbnQgPSBjb3VudGVyLmN1cnJlbnQgKyAxO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPFdoeUNob29zZUxpc3RcbiAgICAgICAgICAgICAgICAgIGtleT17YCR7aW5kZXh9YH1cbiAgICAgICAgICAgICAgICAgIGljb249e0ljb25DZW50cmVbaXRlbS50aHVtYm5haWwgfHwgXCJkZWZhdWx0XCJdfVxuICAgICAgICAgICAgICAgICAgdGl0bGU9e2l0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgICByaWdodD17Y291bnRlci5jdXJyZW50ID4gMn1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxuICAgICAgICAgICAgICAgIDwvV2h5Q2hvb3NlTGlzdD5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvV2h5Q2hvb3NlQ29udGFpbmVyPlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xNlwiPlxuICAgICAgICA8Q29udGFpbmVyPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgcG9wcGlucyB0ZXh0LXhsIGxnOnRleHQtMnhsIHRleHQtY2VudGVyIHRleHQtcHJpbWFyeS0zMDBcIj5cbiAgICAgICAgICAgIE91ciBTZXJ2aWNlc1xuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPFNlcnZpY2VDb250YWluZXIgY2xhc3NOYW1lPVwibXQtMTZcIj5cbiAgICAgICAgICAgIHtzZXJ2aWNlcz8ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICA8U2VydmljZUxpc3RcbiAgICAgICAgICAgICAgICBrZXk9e2Ake2luZGV4fWB9XG4gICAgICAgICAgICAgICAgaWNvbj17SWNvbkNlbnRyZVtpdGVtLnRodW1ibmFpbCB8fCBcImRlZmF1bHRcIl19XG4gICAgICAgICAgICAgICAgbmFtZT17aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICBzbHVnPXtpdGVtLnNsdWd9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L1NlcnZpY2VDb250YWluZXI+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTIwIGJnLWdyYXlzY2FsZS0xMDBcIj5cbiAgICAgICAgPENvbnRhaW5lcj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHBvcHBpbnMgdGV4dC14bCBsZzp0ZXh0LTJ4bCB0ZXh0LWNlbnRlciB0ZXh0LXByaW1hcnktMzAwXCI+XG4gICAgICAgICAgICBHYWxlcmlcbiAgICAgICAgICA8L2gzPlxuICAgICAgICAgIDxHYWxsZXJ5Q29udGFpbmVyPlxuICAgICAgICAgICAge2dhbGxlcnk/Lm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgPEdhbGxlcnlMaXN0XG4gICAgICAgICAgICAgICAga2V5PXtgJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgIHNsdWc9e2l0ZW0ucG9zdC5zbHVnfVxuICAgICAgICAgICAgICAgIHRleHQ9e2l0ZW0ucG9zdC50aXRsZX1cbiAgICAgICAgICAgICAgICBpbWFnZT17aXRlbS5wYXRoPy5yZXBsYWNlKFxuICAgICAgICAgICAgICAgICAgXCJwdWJsaWNcIixcbiAgICAgICAgICAgICAgICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0JBU0VfVVJMXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvR2FsbGVyeUNvbnRhaW5lcj5cbiAgICAgICAgPC9Db250YWluZXI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JheXNjYWxlLTEwMCBib3JkZXItdCBib3JkZXItZ3JheXNjYWxlLTIwMCBweS0yMFwiPlxuICAgICAgICA8Q29udGFpbmVyPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgcG9wcGlucyB0ZXh0LXhsIGxnOnRleHQtMnhsIHRleHQtY2VudGVyIHRleHQtcHJpbWFyeS0zMDAgbWItMTBcIj5cbiAgICAgICAgICAgIEluc3RhZ3JhbSBGZWVkc1xuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPEVtYmVkIHJlZklkPVwiY2YwY2RjMjEyOTJlNDI4YTNhNjU0ZmIwNDZjYjcxZTY5NTgwMzBhOFwiIC8+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyYXlzY2FsZS0xMDAgYm9yZGVyLXQgYm9yZGVyLWdyYXlzY2FsZS0yMDBcIj5cbiAgICAgICAgPENvbnRhaW5lciBjbGFzc05hbWU9XCJ6LTEwIHJlbGF0aXZlIGZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6anVzdGlmeS1iZXR3ZWVuIHB5LTIwIHB4LTMgbGc6cHgtMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6dy0xLzMgbGc6bXItMTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xNiB3LWZ1bGwgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICAgICAgdW5vcHRpbWl6ZWQ9e3RydWV9XG4gICAgICAgICAgICAgICAgc3JjPXtiYXNpY0luZm9ybWF0aW9uPy5sb2dvPy5yZXBsYWNlKFxuICAgICAgICAgICAgICAgICAgXCJwdWJsaWNcIixcbiAgICAgICAgICAgICAgICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0JBU0VfVVJMXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICBhbHQ9e2BMb2dvICR7YmFzaWNJbmZvcm1hdGlvbi5jbGluaWNOYW1lfWB9XG4gICAgICAgICAgICAgICAgbGF5b3V0PVwiZmlsbFwiXG4gICAgICAgICAgICAgICAgb2JqZWN0Rml0PVwiY29udGFpblwiXG4gICAgICAgICAgICAgICAgb2JqZWN0UG9zaXRpb249XCJsZWZ0XCJcbiAgICAgICAgICAgICAgICBxdWFsaXR5PXs5MH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXlzY2FsZS03MDAgdGV4dC1qdXN0aWZ5IG10LTVcIj5cbiAgICAgICAgICAgICAge2Jhc2ljSW5mb3JtYXRpb24uZGVzY3JpcHRpb259XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnktNDAwIHBvcHBpbnMgZm9udC1ib2xkIG10LTEwXCI+XG4gICAgICAgICAgICAgIElrdXRpIEthbWlcbiAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleFwiPlxuICAgICAgICAgICAgICA8U29jaWFsTWVkaWFCdXR0b25cbiAgICAgICAgICAgICAgICB0aXRsZT17YEluc3RhZ3JhbSAke2Jhc2ljSW5mb3JtYXRpb24uY2xpbmljTmFtZX1gfVxuICAgICAgICAgICAgICAgIGljb249e0luc3RhZ3JhbX1cbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgIGhyZWY9e2Jhc2ljSW5mb3JtYXRpb24uaW5zdGFncmFtfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8U29jaWFsTWVkaWFCdXR0b25cbiAgICAgICAgICAgICAgICB0aXRsZT17YEZhY2Vib29rICR7YmFzaWNJbmZvcm1hdGlvbi5jbGluaWNOYW1lfWB9XG4gICAgICAgICAgICAgICAgaWNvbj17RmFjZWJvb2t9XG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0yXCJcbiAgICAgICAgICAgICAgICBocmVmPXtiYXNpY0luZm9ybWF0aW9uLmZhY2Vib29rfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0wIGxnOm1sLTUgbXQtOCBsZzptdC0wXCI+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5LTQwMCBwb3BwaW5zIGZvbnQtYm9sZFwiPkhhbGFtYW48L2g0PlxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAge3BhZ2VzPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17YCR7aW5kZXh9YH0+XG4gICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtgL2hhbGFtYW4vJHtpdGVtLnNsdWd9YH0+XG4gICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB0ZXh0LWdyYXlzY2FsZS03MDAgaG92ZXI6dGV4dC1wcmltYXJ5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2l0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTAgbGc6bWwtNSBtdC04IGxnOm10LTBcIj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnktNDAwIHBvcHBpbnMgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIEphbSBPcGVyYXNpb25hbFxuICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXJpbW8gbXQtMyB0ZXh0LWdyYXlzY2FsZS04MDAgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgIHtiYXNpY0luZm9ybWF0aW9uLm9wZXJhdGlvbmFsRGF5fVxuICAgICAgICAgICAgICA8L3N0cm9uZz5cbiAgICAgICAgICAgICAgPHNwYW4+e2Jhc2ljSW5mb3JtYXRpb24ub3BlcmF0aW9uYWxIb3VyfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhcmltbyBtdC0zIGxnOnctNjQgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZ3JheXNjYWxlLTgwMCBmb250LWJvbGRcIj5BbGFtYXQ8L3N0cm9uZz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5c2NhbGUtNzAwIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgIHtiYXNpY0luZm9ybWF0aW9uPy5hZGRyZXNzfSA8YnIgLz5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgaHJlZj17YmFzaWNJbmZvcm1hdGlvbi5nbWFwc31cbiAgICAgICAgICAgICAgICAgIHRpdGxlPXtgR29vZ2xlIE1hcHMgJHtiYXNpY0luZm9ybWF0aW9uLmNsaW5pY05hbWV9YH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeS0yMDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIExpaGF0IE1hcHNcbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtMCBsZzptbC01IG10LTggbGc6bXQtMFwiPlxuICAgICAgICAgICAgPGlmcmFtZVxuICAgICAgICAgICAgICBzcmM9XCJodHRwczovL3d3dy5nb29nbGUuY29tL21hcHMvZW1iZWQ/cGI9ITFtMTghMW0xMiExbTMhMWQzOTY2LjUyMTI2MDMyMjI4MyEyZDEwNi44MTk1NjEzNTA3ODY0ITNkLTYuMTk0NzQxMzk1NDkzMzcxITJtMyExZjAhMmYwITNmMCEzbTIhMWkxMDI0ITJpNzY4ITRmMTMuMSEzbTMhMW0yITFzMHgyZTY5ZjUzOTA5MTdiNzU5JTNBMHg2YjQ1ZTY3MzU2MDgwNDc3ITJzUFQlMjBLdWxrdWwlMjBUZWtub2xvZ2klMjBJbnRlcm5hc2lvbmFsITVlMCEzbTIhMXNlbiEyc2lkITR2MTYwMTEzODIyMTA4NSE1bTIhMXNlbiEyc2lkXCJcbiAgICAgICAgICAgICAgd2lkdGg9XCI2MDBcIlxuICAgICAgICAgICAgICBoZWlnaHQ9XCI0NTBcIlxuICAgICAgICAgICAgICBmcmFtZUJvcmRlcj1cIjBcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBib3JkZXI6IDAgfX1cbiAgICAgICAgICAgICAgYWxsb3dGdWxsU2NyZWVuPVwiXCJcbiAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJmYWxzZVwiXG4gICAgICAgICAgICAgIHRhYkluZGV4PVwiMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==
webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_images_Background__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../src/images/Background */ "./src/images/Background.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../tailwind.config */ "./tailwind.config.js");
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tailwind_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _src_components_Container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/components/Container */ "./src/components/Container.jsx");
/* harmony import */ var _src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/components/SocialMediaButton */ "./src/components/SocialMediaButton.jsx");
/* harmony import */ var _src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/components/WhyChoose */ "./src/components/WhyChoose.jsx");
/* harmony import */ var _src_images_BackgroundMobile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../src/images/BackgroundMobile */ "./src/images/BackgroundMobile.js");
/* harmony import */ var _src_images_Welcome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/images/Welcome */ "./src/images/Welcome.js");
/* harmony import */ var _src_components_Service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../src/components/Service */ "./src/components/Service.jsx");
/* harmony import */ var _src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../src/components/Gallery */ "./src/components/Gallery.jsx");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _src_images_Instagram__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../src/images/Instagram */ "./src/images/Instagram.js");
/* harmony import */ var _src_images_Facebook__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../src/images/Facebook */ "./src/images/Facebook.js");
/* harmony import */ var _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../src/images/IconCentre */ "./src/images/IconCentre.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-responsive-carousel/lib/styles/carousel.min.css */ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react-responsive-carousel */ "./node_modules/react-responsive-carousel/lib/js/index.js");
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _src_components_Embed__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../src/components/Embed */ "./src/components/Embed.js");



var _jsxFileName = "C:\\reactprojects\\zahara\\frontend-public\\pages\\index.js",
    _s = $RefreshSig$();
















 // requires a loader




var __N_SSP = true;
function Home(_ref) {
  _s();

  var _this = this,
      _basicInformation$log;

  var basicInformation = _ref.basicInformation,
      kelebihan = _ref.kelebihan,
      services = _ref.services,
      gallery = _ref.gallery,
      pages = _ref.pages,
      slider = _ref.slider;
  var counter = Object(react__WEBPACK_IMPORTED_MODULE_18__["useRef"])(0);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_11___default.a, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: basicInformation.clinicName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_Background__WEBPACK_IMPORTED_MODULE_1__["default"], {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 hidden lg:block",
      fill: _tailwind_config__WEBPACK_IMPORTED_MODULE_3__["theme"].colors.background
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_BackgroundMobile__WEBPACK_IMPORTED_MODULE_7__["default"], {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 block lg:hidden",
      fill: _tailwind_config__WEBPACK_IMPORTED_MODULE_3__["theme"].colors.background
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "h-screen relative",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        className: "text-grayscale-800 z-10 flex items-center h-full relative",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:w-1/2",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_Welcome__WEBPACK_IMPORTED_MODULE_8__["default"], {
            className: "text-primary-100 mb-5 w-1/2 md:w-1/3 lg:w-2/4 mx-auto lg:mx-0 h-auto"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            className: "font-bold text-xl lg:text-2xl xl:text-3xl poppins mb-3 text-center lg:text-left text-grayscale-800",
            children: "Selamat Datang!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
            className: "text-grayscale-700 text-center lg:text-left",
            children: basicInformation.welcomeText
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 102,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute right-0 z-10 top-0 bottom-0 items-center pt-16 hidden lg:flex w-64",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "lg:p-2 xl:p-5 bg-grayscale-100 shadow-lg rounded-lg",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__["Carousel"], {
              showThumbs: false,
              showStatus: false,
              autoPlay: true,
              infiniteLoop: true,
              interval: 3000,
              swipeable: true,
              showArrows: false,
              children: slider === null || slider === void 0 ? void 0 : slider.map(function (item, index) {
                var _item$thumbnail;

                return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
                    unoptimized: true,
                    src: ((_item$thumbnail = item.thumbnail) === null || _item$thumbnail === void 0 ? void 0 : _item$thumbnail.replace("public", "https://admin.zaharadental.com")) || "/images/dentist.jpg",
                    alt: item.title,
                    width: 240,
                    height: 320,
                    className: "rounded-lg",
                    objectFit: "cover"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 119,
                    columnNumber: 21
                  }, _this)
                }, "".concat(index), false, {
                  fileName: _jsxFileName,
                  lineNumber: 118,
                  columnNumber: 19
                }, _this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 108,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 107,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "bg-grayscale-100 py-10",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Mengapa Memilih Klinik Kami?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 142,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__["default"], {
          children: kelebihan === null || kelebihan === void 0 ? void 0 : kelebihan.map(function (item, index) {
            if (counter.current + 1 > 4) {
              counter.current = 1;
            } else {
              counter.current = counter.current + 1;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__["WhyChooseList"], {
              icon: _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__["default"][item.thumbnail || "default"],
              title: item.title,
              right: counter.current > 2,
              children: item.text
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 153,
              columnNumber: 17
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 140,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "py-16",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Our Services"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Service__WEBPACK_IMPORTED_MODULE_9__["default"], {
          className: "mt-16",
          children: services === null || services === void 0 ? void 0 : services.map(function (item, index) {
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Service__WEBPACK_IMPORTED_MODULE_9__["ServiceList"], {
              icon: _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__["default"][item.thumbnail || "default"],
              name: item.title,
              slug: item.slug
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 173,
              columnNumber: 15
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 171,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 167,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 166,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "py-20 bg-grayscale-100",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Galeri"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__["default"], {
          children: gallery === null || gallery === void 0 ? void 0 : gallery.map(function (item, index) {
            var _item$path;

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__["GalleryList"], {
              slug: item.post.slug,
              text: item.post.title,
              image: (_item$path = item.path) === null || _item$path === void 0 ? void 0 : _item$path.replace("public", "https://admin.zaharadental.com")
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 190,
              columnNumber: 15
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 188,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 183,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Embed__WEBPACK_IMPORTED_MODULE_19__["default"], {
          refId: "cf0cdc21292e428a3a654fb046cb71e6958030a8"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 204,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        className: "z-10 relative flex flex-col lg:flex-row lg:justify-between py-20 px-3 lg:px-0",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:w-1/3 lg:mr-16",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "h-16 w-full relative",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
              unoptimized: true,
              src: basicInformation === null || basicInformation === void 0 ? void 0 : (_basicInformation$log = basicInformation.logo) === null || _basicInformation$log === void 0 ? void 0 : _basicInformation$log.replace("public", "https://admin.zaharadental.com"),
              alt: "Logo ".concat(basicInformation.clinicName),
              layout: "fill",
              objectFit: "contain",
              objectPosition: "left",
              quality: 90
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 212,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 211,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-grayscale-700 text-justify mt-5",
            children: basicInformation.description
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 225,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 210,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ml-0 lg:ml-5 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Halaman"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 230,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
            className: "mt-3",
            children: pages === null || pages === void 0 ? void 0 : pages.map(function (item, index) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_15___default.a, {
                  href: "/halaman/".concat(item.slug),
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "mt-1 block text-grayscale-700 hover:text-primary-100",
                    title: item.title,
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 235,
                    columnNumber: 21
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 234,
                  columnNumber: 19
                }, _this)
              }, "".concat(index), false, {
                fileName: _jsxFileName,
                lineNumber: 233,
                columnNumber: 17
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 231,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 229,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ml-0 lg:ml-5 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Jam Operasional"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 247,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "arimo mt-3 text-grayscale-800 flex flex-col",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              className: "font-bold",
              children: basicInformation.operationalDay
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 251,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: basicInformation.operationalHour
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 254,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 250,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "arimo mt-3 lg:w-64 flex flex-col",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              className: "text-grayscale-800 font-bold",
              children: "Alamat"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 257,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "text-grayscale-700 flex-1",
              children: [basicInformation === null || basicInformation === void 0 ? void 0 : basicInformation.address, " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 259,
                columnNumber: 45
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: basicInformation.gmaps,
                title: "Google Maps ".concat(basicInformation.clinicName),
                className: "text-primary-200",
                children: "Lihat Maps"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 260,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 258,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 256,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 246,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ml-0 lg:ml-5 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Ikuti Kami"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 271,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-3 flex",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
              title: "Instagram ".concat(basicInformation.clinicName),
              icon: _src_images_Instagram__WEBPACK_IMPORTED_MODULE_12__["default"],
              target: "_blank",
              href: basicInformation.instagram
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 273,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
              title: "Facebook ".concat(basicInformation.clinicName),
              icon: _src_images_Facebook__WEBPACK_IMPORTED_MODULE_13__["default"],
              target: "_blank",
              className: "ml-2",
              href: basicInformation.facebook
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 279,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 272,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 270,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 209,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 208,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Home, "3iz0ofrn4gTwn024PSoRDlWOdB8=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiSG9tZSIsImJhc2ljSW5mb3JtYXRpb24iLCJrZWxlYmloYW4iLCJzZXJ2aWNlcyIsImdhbGxlcnkiLCJwYWdlcyIsInNsaWRlciIsImNvdW50ZXIiLCJ1c2VSZWYiLCJjbGluaWNOYW1lIiwidGhlbWUiLCJjb2xvcnMiLCJiYWNrZ3JvdW5kIiwid2VsY29tZVRleHQiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJ0aHVtYm5haWwiLCJyZXBsYWNlIiwicHJvY2VzcyIsInRpdGxlIiwiY3VycmVudCIsIkljb25DZW50cmUiLCJ0ZXh0Iiwic2x1ZyIsInBvc3QiLCJwYXRoIiwibG9nbyIsImRlc2NyaXB0aW9uIiwib3BlcmF0aW9uYWxEYXkiLCJvcGVyYXRpb25hbEhvdXIiLCJhZGRyZXNzIiwiZ21hcHMiLCJJbnN0YWdyYW0iLCJpbnN0YWdyYW0iLCJGYWNlYm9vayIsImZhY2Vib29rIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVnRTs7QUFDaEU7QUFDQTtBQUNBOztBQXFEZSxTQUFTQSxJQUFULE9BT1o7QUFBQTs7QUFBQTtBQUFBOztBQUFBLE1BTkRDLGdCQU1DLFFBTkRBLGdCQU1DO0FBQUEsTUFMREMsU0FLQyxRQUxEQSxTQUtDO0FBQUEsTUFKREMsUUFJQyxRQUpEQSxRQUlDO0FBQUEsTUFIREMsT0FHQyxRQUhEQSxPQUdDO0FBQUEsTUFGREMsS0FFQyxRQUZEQSxLQUVDO0FBQUEsTUFEREMsTUFDQyxRQUREQSxNQUNDO0FBQ0QsTUFBTUMsT0FBTyxHQUFHQyxxREFBTSxDQUFDLENBQUQsQ0FBdEI7QUFDQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLGlEQUFEO0FBQUEsNkJBQ0U7QUFBQSxrQkFBUVAsZ0JBQWdCLENBQUNRO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFJRSxxRUFBQyw4REFBRDtBQUNFLGVBQVMsRUFBQyw0RUFEWjtBQUVFLFVBQUksRUFBRUMsc0RBQUssQ0FBQ0MsTUFBTixDQUFhQztBQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkYsZUFRRSxxRUFBQyxvRUFBRDtBQUNFLGVBQVMsRUFBQyw0RUFEWjtBQUVFLFVBQUksRUFBRUYsc0RBQUssQ0FBQ0MsTUFBTixDQUFhQztBQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUkYsZUFZRTtBQUFLLGVBQVMsRUFBQyxtQkFBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQVcsaUJBQVMsRUFBQywyREFBckI7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsVUFBZjtBQUFBLGtDQUNFLHFFQUFDLDJEQUFEO0FBQVMscUJBQVMsRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBRUU7QUFBSSxxQkFBUyxFQUFDLG9HQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGLGVBS0U7QUFBSSxxQkFBUyxFQUFDLDZDQUFkO0FBQUEsc0JBQ0dYLGdCQUFnQixDQUFDWTtBQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQVVFO0FBQUssbUJBQVMsRUFBQyw2RUFBZjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxxREFBZjtBQUFBLG1DQUNFLHFFQUFDLG1FQUFEO0FBQ0Usd0JBQVUsRUFBRSxLQURkO0FBRUUsd0JBQVUsRUFBRSxLQUZkO0FBR0Usc0JBQVEsRUFBRSxJQUhaO0FBSUUsMEJBQVksRUFBRSxJQUpoQjtBQUtFLHNCQUFRLEVBQUUsSUFMWjtBQU1FLHVCQUFTLEVBQUUsSUFOYjtBQU9FLHdCQUFVLEVBQUUsS0FQZDtBQUFBLHdCQVNHUCxNQVRILGFBU0dBLE1BVEgsdUJBU0dBLE1BQU0sQ0FBRVEsR0FBUixDQUFZLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBOztBQUFBLG9DQUNYO0FBQUEseUNBQ0UscUVBQUMsaURBQUQ7QUFDRSwrQkFBVyxFQUFFLElBRGY7QUFFRSx1QkFBRyxFQUNELG9CQUFBRCxJQUFJLENBQUNFLFNBQUwsb0VBQWdCQyxPQUFoQixDQUNFLFFBREYsRUFFRUMsZ0NBRkYsTUFHSyxxQkFOVDtBQVFFLHVCQUFHLEVBQUVKLElBQUksQ0FBQ0ssS0FSWjtBQVNFLHlCQUFLLEVBQUUsR0FUVDtBQVVFLDBCQUFNLEVBQUUsR0FWVjtBQVdFLDZCQUFTLEVBQUMsWUFYWjtBQVlFLDZCQUFTLEVBQUM7QUFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsNkJBQWFKLEtBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFEVztBQUFBLGVBQVo7QUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVpGLGVBeURFO0FBQUssZUFBUyxFQUFDLHdCQUFmO0FBQUEsNkJBQ0UscUVBQUMsaUVBQUQ7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsb0VBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFJRSxxRUFBQyxpRUFBRDtBQUFBLG9CQUNHZCxTQURILGFBQ0dBLFNBREgsdUJBQ0dBLFNBQVMsQ0FBRVksR0FBWCxDQUFlLFVBQUNDLElBQUQsRUFBT0MsS0FBUCxFQUFpQjtBQUMvQixnQkFBSVQsT0FBTyxDQUFDYyxPQUFSLEdBQWtCLENBQWxCLEdBQXNCLENBQTFCLEVBQTZCO0FBQzNCZCxxQkFBTyxDQUFDYyxPQUFSLEdBQWtCLENBQWxCO0FBQ0QsYUFGRCxNQUVPO0FBQ0xkLHFCQUFPLENBQUNjLE9BQVIsR0FBa0JkLE9BQU8sQ0FBQ2MsT0FBUixHQUFrQixDQUFwQztBQUNEOztBQUNELGdDQUNFLHFFQUFDLHVFQUFEO0FBRUUsa0JBQUksRUFBRUMsK0RBQVUsQ0FBQ1AsSUFBSSxDQUFDRSxTQUFMLElBQWtCLFNBQW5CLENBRmxCO0FBR0UsbUJBQUssRUFBRUYsSUFBSSxDQUFDSyxLQUhkO0FBSUUsbUJBQUssRUFBRWIsT0FBTyxDQUFDYyxPQUFSLEdBQWtCLENBSjNCO0FBQUEsd0JBTUdOLElBQUksQ0FBQ1E7QUFOUix5QkFDVVAsS0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBVUQsV0FoQkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF6REYsZUFtRkU7QUFBSyxlQUFTLEVBQUMsT0FBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLG9FQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUscUVBQUMsK0RBQUQ7QUFBa0IsbUJBQVMsRUFBQyxPQUE1QjtBQUFBLG9CQUNHYixRQURILGFBQ0dBLFFBREgsdUJBQ0dBLFFBQVEsQ0FBRVcsR0FBVixDQUFjLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBLGdDQUNiLHFFQUFDLG1FQUFEO0FBRUUsa0JBQUksRUFBRU0sK0RBQVUsQ0FBQ1AsSUFBSSxDQUFDRSxTQUFMLElBQWtCLFNBQW5CLENBRmxCO0FBR0Usa0JBQUksRUFBRUYsSUFBSSxDQUFDSyxLQUhiO0FBSUUsa0JBQUksRUFBRUwsSUFBSSxDQUFDUztBQUpiLHlCQUNVUixLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRGE7QUFBQSxXQUFkO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbkZGLGVBb0dFO0FBQUssZUFBUyxFQUFDLHdCQUFmO0FBQUEsNkJBQ0UscUVBQUMsaUVBQUQ7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsb0VBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFJRSxxRUFBQyxnRUFBRDtBQUFBLG9CQUNHWixPQURILGFBQ0dBLE9BREgsdUJBQ0dBLE9BQU8sQ0FBRVUsR0FBVCxDQUFhLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBOztBQUFBLGdDQUNaLHFFQUFDLG9FQUFEO0FBRUUsa0JBQUksRUFBRUQsSUFBSSxDQUFDVSxJQUFMLENBQVVELElBRmxCO0FBR0Usa0JBQUksRUFBRVQsSUFBSSxDQUFDVSxJQUFMLENBQVVMLEtBSGxCO0FBSUUsbUJBQUssZ0JBQUVMLElBQUksQ0FBQ1csSUFBUCwrQ0FBRSxXQUFXUixPQUFYLENBQ0wsUUFESyxFQUVMQyxnQ0FGSztBQUpULHlCQUNVSCxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRFk7QUFBQSxXQUFiO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcEdGLGVBd0hFO0FBQUssZUFBUyxFQUFDLHlEQUFmO0FBQUEsNkJBQ0UscUVBQUMsaUVBQUQ7QUFBQSwrQkFDRSxxRUFBQyw4REFBRDtBQUFPLGVBQUssRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXhIRixlQTZIRTtBQUFLLGVBQVMsRUFBQyx5REFBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQVcsaUJBQVMsRUFBQywrRUFBckI7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsbUJBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsc0JBQWY7QUFBQSxtQ0FDRSxxRUFBQyxpREFBRDtBQUNFLHlCQUFXLEVBQUUsSUFEZjtBQUVFLGlCQUFHLEVBQUVmLGdCQUFGLGFBQUVBLGdCQUFGLGdEQUFFQSxnQkFBZ0IsQ0FBRTBCLElBQXBCLDBEQUFFLHNCQUF3QlQsT0FBeEIsQ0FDSCxRQURHLEVBRUhDLGdDQUZHLENBRlA7QUFNRSxpQkFBRyxpQkFBVWxCLGdCQUFnQixDQUFDUSxVQUEzQixDQU5MO0FBT0Usb0JBQU0sRUFBQyxNQVBUO0FBUUUsdUJBQVMsRUFBQyxTQVJaO0FBU0UsNEJBQWMsRUFBQyxNQVRqQjtBQVVFLHFCQUFPLEVBQUU7QUFWWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQWVFO0FBQUsscUJBQVMsRUFBQyxzQ0FBZjtBQUFBLHNCQUNHUixnQkFBZ0IsQ0FBQzJCO0FBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBb0JFO0FBQUssbUJBQVMsRUFBQywyQkFBZjtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBQyxvQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUkscUJBQVMsRUFBQyxNQUFkO0FBQUEsc0JBQ0d2QixLQURILGFBQ0dBLEtBREgsdUJBQ0dBLEtBQUssQ0FBRVMsR0FBUCxDQUFXLFVBQUNDLElBQUQsRUFBT0MsS0FBUDtBQUFBLGtDQUNWO0FBQUEsdUNBQ0UscUVBQUMsaURBQUQ7QUFBTSxzQkFBSSxxQkFBY0QsSUFBSSxDQUFDUyxJQUFuQixDQUFWO0FBQUEseUNBQ0U7QUFDRSw2QkFBUyxFQUFDLHNEQURaO0FBRUUseUJBQUssRUFBRVQsSUFBSSxDQUFDSyxLQUZkO0FBQUEsOEJBSUdMLElBQUksQ0FBQ0s7QUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLDJCQUFZSixLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRFU7QUFBQSxhQUFYO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBcEJGLGVBcUNFO0FBQUssbUJBQVMsRUFBQywyQkFBZjtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBQyxvQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUlFO0FBQUsscUJBQVMsRUFBQyw2Q0FBZjtBQUFBLG9DQUNFO0FBQVEsdUJBQVMsRUFBQyxXQUFsQjtBQUFBLHdCQUNHZixnQkFBZ0IsQ0FBQzRCO0FBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFJRTtBQUFBLHdCQUFPNUIsZ0JBQWdCLENBQUM2QjtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKRixlQVVFO0FBQUsscUJBQVMsRUFBQyxrQ0FBZjtBQUFBLG9DQUNFO0FBQVEsdUJBQVMsRUFBQyw4QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFFRTtBQUFNLHVCQUFTLEVBQUMsMkJBQWhCO0FBQUEseUJBQ0c3QixnQkFESCxhQUNHQSxnQkFESCx1QkFDR0EsZ0JBQWdCLENBQUU4QixPQURyQixvQkFDOEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFEOUIsZUFFRTtBQUNFLG9CQUFJLEVBQUU5QixnQkFBZ0IsQ0FBQytCLEtBRHpCO0FBRUUscUJBQUssd0JBQWlCL0IsZ0JBQWdCLENBQUNRLFVBQWxDLENBRlA7QUFHRSx5QkFBUyxFQUFDLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXJDRixlQTZERTtBQUFLLG1CQUFTLEVBQUMsMkJBQWY7QUFBQSxrQ0FDRTtBQUFJLHFCQUFTLEVBQUMsb0NBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRTtBQUFLLHFCQUFTLEVBQUMsV0FBZjtBQUFBLG9DQUNFLHFFQUFDLHlFQUFEO0FBQ0UsbUJBQUssc0JBQWVSLGdCQUFnQixDQUFDUSxVQUFoQyxDQURQO0FBRUUsa0JBQUksRUFBRXdCLDhEQUZSO0FBR0Usb0JBQU0sRUFBQyxRQUhUO0FBSUUsa0JBQUksRUFBRWhDLGdCQUFnQixDQUFDaUM7QUFKekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQU9FLHFFQUFDLHlFQUFEO0FBQ0UsbUJBQUsscUJBQWNqQyxnQkFBZ0IsQ0FBQ1EsVUFBL0IsQ0FEUDtBQUVFLGtCQUFJLEVBQUUwQiw2REFGUjtBQUdFLG9CQUFNLEVBQUMsUUFIVDtBQUlFLHVCQUFTLEVBQUMsTUFKWjtBQUtFLGtCQUFJLEVBQUVsQyxnQkFBZ0IsQ0FBQ21DO0FBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTdIRjtBQUFBLGtCQURGO0FBa05EOztHQTNOdUJwQyxJOztLQUFBQSxJIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjNiNGNmNDI1NWRkMWNmNWJlMWI5LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQmFja2dyb3VuZCBmcm9tIFwiLi4vc3JjL2ltYWdlcy9CYWNrZ3JvdW5kXCI7XG5pbXBvcnQgSW1hZ2UgZnJvbSBcIm5leHQvaW1hZ2VcIjtcbmltcG9ydCB7IHRoZW1lIH0gZnJvbSBcIi4uL3RhaWx3aW5kLmNvbmZpZ1wiO1xuaW1wb3J0IENvbnRhaW5lciBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvQ29udGFpbmVyXCI7XG5pbXBvcnQgU29jaWFsTWVkaWFCdXR0b24gZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL1NvY2lhbE1lZGlhQnV0dG9uXCI7XG5pbXBvcnQgV2h5Q2hvb3NlQ29udGFpbmVyLCB7IFdoeUNob29zZUxpc3QgfSBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvV2h5Q2hvb3NlXCI7XG5pbXBvcnQgQmFja2dyb3VuZE1vYmlsZSBmcm9tIFwiLi4vc3JjL2ltYWdlcy9CYWNrZ3JvdW5kTW9iaWxlXCI7XG5pbXBvcnQgV2VsY29tZSBmcm9tIFwiLi4vc3JjL2ltYWdlcy9XZWxjb21lXCI7XG5pbXBvcnQgU2VydmljZUNvbnRhaW5lciwgeyBTZXJ2aWNlTGlzdCB9IGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9TZXJ2aWNlXCI7XG5pbXBvcnQgR2FsbGVyeUNvbnRhaW5lciwgeyBHYWxsZXJ5TGlzdCB9IGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9HYWxsZXJ5XCI7XG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgSW5zdGFncmFtIGZyb20gXCIuLi9zcmMvaW1hZ2VzL0luc3RhZ3JhbVwiO1xuaW1wb3J0IEZhY2Vib29rIGZyb20gXCIuLi9zcmMvaW1hZ2VzL0ZhY2Vib29rXCI7XG5pbXBvcnQgSWNvbkNlbnRyZSBmcm9tIFwiLi4vc3JjL2ltYWdlcy9JY29uQ2VudHJlXCI7XG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XG5pbXBvcnQgc2VydmljZSBmcm9tIFwiLi4vc3JjL3NlcnZpY2VcIjtcbmltcG9ydCBcInJlYWN0LXJlc3BvbnNpdmUtY2Fyb3VzZWwvbGliL3N0eWxlcy9jYXJvdXNlbC5taW4uY3NzXCI7IC8vIHJlcXVpcmVzIGEgbG9hZGVyXG5pbXBvcnQgeyBDYXJvdXNlbCB9IGZyb20gXCJyZWFjdC1yZXNwb25zaXZlLWNhcm91c2VsXCI7XG5pbXBvcnQgeyB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBFbWJlZCBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvRW1iZWRcIjtcblxuZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wcyA9IGFzeW5jICgpID0+IHtcbiAgbGV0IGJhc2ljSW5mb3JtYXRpb24sXG4gICAga2VsZWJpaGFuLFxuICAgIHNlcnZpY2VzLFxuICAgIHN1YlNlcnZpY2VzLFxuICAgIGdhbGxlcnksXG4gICAgcGFnZXMsXG4gICAgc2xpZGVyO1xuICB0cnkge1xuICAgIGJhc2ljSW5mb3JtYXRpb24gPSAoYXdhaXQgc2VydmljZS5nZXQoXCIvYmFzaWMtaW5mb3JtYXRpb25cIikpLmRhdGEuc3VjY2Vzc1xuICAgICAgLmRhdGE7XG4gICAgc2VydmljZXMgPSAoYXdhaXQgc2VydmljZS5nZXQoXCIvcG9zdC9sYXlhbmFuP2xpbWl0PTEwMFwiKSkuZGF0YS5zdWNjZXNzLmRhdGFcbiAgICAgIC5yb3dzO1xuICAgIHN1YlNlcnZpY2VzID0gKGF3YWl0IHNlcnZpY2UuZ2V0KFwiL3Bvc3Qvc3ViLWxheWFuYW4/bGltaXQ9MTAwJm5vZGVzYz0xXCIpKVxuICAgICAgLmRhdGEuc3VjY2Vzcy5kYXRhLnJvd3M7XG4gICAga2VsZWJpaGFuID0gKGF3YWl0IHNlcnZpY2UuZ2V0KFwiL3Bvc3Qva2VsZWJpaGFuXCIpKS5kYXRhLnN1Y2Nlc3MuZGF0YS5yb3dzO1xuICAgIHNsaWRlciA9IChhd2FpdCBzZXJ2aWNlLmdldChcIi9wb3N0L3NsaWRlclwiKSkuZGF0YS5zdWNjZXNzLmRhdGEucm93cztcbiAgICBwYWdlcyA9IChhd2FpdCBzZXJ2aWNlLmdldChcIi9wb3N0L2hhbGFtYW4/bGltaXQ9MTAwJm5vZGVzYz0xXCIpKS5kYXRhLnN1Y2Nlc3NcbiAgICAgIC5kYXRhLnJvd3M7XG4gICAgZ2FsbGVyeSA9IChhd2FpdCBzZXJ2aWNlLmdldChcIi9nYWxsZXJ5L3R5cGUvbGF5YW5hbj9saW1pdD04XCIpKS5kYXRhLnN1Y2Nlc3NcbiAgICAgIC5kYXRhLnJvd3M7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zb2xlLmxvZyhlKTtcbiAgICByZXR1cm4ge1xuICAgICAgcHJvcHM6IHtcbiAgICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICB9LFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBwcm9wczoge1xuICAgICAgYmFzaWNJbmZvcm1hdGlvbixcbiAgICAgIGtlbGViaWhhbixcbiAgICAgIHNlcnZpY2VzLFxuICAgICAgc3ViU2VydmljZXMsXG4gICAgICBnYWxsZXJ5LFxuICAgICAgcGFnZXMsXG4gICAgICBoZWFkZXJQcm9wczoge1xuICAgICAgICB0cmFuc3BhcmVudEZpcnN0OiB0cnVlLFxuICAgICAgfSxcbiAgICAgIHNsaWRlcixcbiAgICAgIG1ldGFUYWc6IFtcbiAgICAgICAge1xuICAgICAgICAgIG5hbWU6IFwiZGVzY3JpcHRpb25cIixcbiAgICAgICAgICBjb250ZW50OiBiYXNpY0luZm9ybWF0aW9uLmRlc2NyaXB0aW9uPy5zdWJzdHIoMCwgMTUwKSB8fCBcIlwiLFxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICB9LFxuICB9O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSh7XG4gIGJhc2ljSW5mb3JtYXRpb24sXG4gIGtlbGViaWhhbixcbiAgc2VydmljZXMsXG4gIGdhbGxlcnksXG4gIHBhZ2VzLFxuICBzbGlkZXIsXG59KSB7XG4gIGNvbnN0IGNvdW50ZXIgPSB1c2VSZWYoMCk7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxIZWFkPlxuICAgICAgICA8dGl0bGU+e2Jhc2ljSW5mb3JtYXRpb24uY2xpbmljTmFtZX08L3RpdGxlPlxuICAgICAgPC9IZWFkPlxuICAgICAgPEJhY2tncm91bmRcbiAgICAgICAgY2xhc3NOYW1lPVwiaC1zY3JlZW4gdy1mdWxsIGFic29sdXRlIHRvcC0wIGxlZnQtMCB6LTAgYmctZ3JheXNjYWxlLTEwMCBoaWRkZW4gbGc6YmxvY2tcIlxuICAgICAgICBmaWxsPXt0aGVtZS5jb2xvcnMuYmFja2dyb3VuZH1cbiAgICAgIC8+XG4gICAgICA8QmFja2dyb3VuZE1vYmlsZVxuICAgICAgICBjbGFzc05hbWU9XCJoLXNjcmVlbiB3LWZ1bGwgYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHotMCBiZy1ncmF5c2NhbGUtMTAwIGJsb2NrIGxnOmhpZGRlblwiXG4gICAgICAgIGZpbGw9e3RoZW1lLmNvbG9ycy5iYWNrZ3JvdW5kfVxuICAgICAgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1zY3JlZW4gcmVsYXRpdmVcIj5cbiAgICAgICAgPENvbnRhaW5lciBjbGFzc05hbWU9XCJ0ZXh0LWdyYXlzY2FsZS04MDAgei0xMCBmbGV4IGl0ZW1zLWNlbnRlciBoLWZ1bGwgcmVsYXRpdmVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOnctMS8yXCI+XG4gICAgICAgICAgICA8V2VsY29tZSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnktMTAwIG1iLTUgdy0xLzIgbWQ6dy0xLzMgbGc6dy0yLzQgbXgtYXV0byBsZzpteC0wIGgtYXV0b1wiIC8+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteGwgbGc6dGV4dC0yeGwgeGw6dGV4dC0zeGwgcG9wcGlucyBtYi0zIHRleHQtY2VudGVyIGxnOnRleHQtbGVmdCB0ZXh0LWdyYXlzY2FsZS04MDBcIj5cbiAgICAgICAgICAgICAgU2VsYW1hdCBEYXRhbmchXG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtZ3JheXNjYWxlLTcwMCB0ZXh0LWNlbnRlciBsZzp0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAge2Jhc2ljSW5mb3JtYXRpb24ud2VsY29tZVRleHR9XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMCB6LTEwIHRvcC0wIGJvdHRvbS0wIGl0ZW1zLWNlbnRlciBwdC0xNiBoaWRkZW4gbGc6ZmxleCB3LTY0XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOnAtMiB4bDpwLTUgYmctZ3JheXNjYWxlLTEwMCBzaGFkb3ctbGcgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICA8Q2Fyb3VzZWxcbiAgICAgICAgICAgICAgICBzaG93VGh1bWJzPXtmYWxzZX1cbiAgICAgICAgICAgICAgICBzaG93U3RhdHVzPXtmYWxzZX1cbiAgICAgICAgICAgICAgICBhdXRvUGxheT17dHJ1ZX1cbiAgICAgICAgICAgICAgICBpbmZpbml0ZUxvb3A9e3RydWV9XG4gICAgICAgICAgICAgICAgaW50ZXJ2YWw9ezMwMDB9XG4gICAgICAgICAgICAgICAgc3dpcGVhYmxlPXt0cnVlfVxuICAgICAgICAgICAgICAgIHNob3dBcnJvd3M9e2ZhbHNlfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3NsaWRlcj8ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2Ake2luZGV4fWB9PlxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2VcbiAgICAgICAgICAgICAgICAgICAgICB1bm9wdGltaXplZD17dHJ1ZX1cbiAgICAgICAgICAgICAgICAgICAgICBzcmM9e1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS50aHVtYm5haWw/LnJlcGxhY2UoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwicHVibGljXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0JBU0VfVVJMXG4gICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiL2ltYWdlcy9kZW50aXN0LmpwZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGFsdD17aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICB3aWR0aD17MjQwfVxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD17MzIwfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGdcIlxuICAgICAgICAgICAgICAgICAgICAgIG9iamVjdEZpdD1cImNvdmVyXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L0Nhcm91c2VsPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXlzY2FsZS0xMDAgcHktMTBcIj5cbiAgICAgICAgPENvbnRhaW5lcj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHBvcHBpbnMgdGV4dC14bCBsZzp0ZXh0LTJ4bCB0ZXh0LWNlbnRlciB0ZXh0LXByaW1hcnktMzAwXCI+XG4gICAgICAgICAgICBNZW5nYXBhIE1lbWlsaWggS2xpbmlrIEthbWk/XG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8V2h5Q2hvb3NlQ29udGFpbmVyPlxuICAgICAgICAgICAge2tlbGViaWhhbj8ubWFwKChpdGVtLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICBpZiAoY291bnRlci5jdXJyZW50ICsgMSA+IDQpIHtcbiAgICAgICAgICAgICAgICBjb3VudGVyLmN1cnJlbnQgPSAxO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvdW50ZXIuY3VycmVudCA9IGNvdW50ZXIuY3VycmVudCArIDE7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8V2h5Q2hvb3NlTGlzdFxuICAgICAgICAgICAgICAgICAga2V5PXtgJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgICAgaWNvbj17SWNvbkNlbnRyZVtpdGVtLnRodW1ibmFpbCB8fCBcImRlZmF1bHRcIl19XG4gICAgICAgICAgICAgICAgICB0aXRsZT17aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgIHJpZ2h0PXtjb3VudGVyLmN1cnJlbnQgPiAyfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnRleHR9XG4gICAgICAgICAgICAgICAgPC9XaHlDaG9vc2VMaXN0PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9XaHlDaG9vc2VDb250YWluZXI+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTE2XCI+XG4gICAgICAgIDxDb250YWluZXI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBwb3BwaW5zIHRleHQteGwgbGc6dGV4dC0yeGwgdGV4dC1jZW50ZXIgdGV4dC1wcmltYXJ5LTMwMFwiPlxuICAgICAgICAgICAgT3VyIFNlcnZpY2VzXG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8U2VydmljZUNvbnRhaW5lciBjbGFzc05hbWU9XCJtdC0xNlwiPlxuICAgICAgICAgICAge3NlcnZpY2VzPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgIDxTZXJ2aWNlTGlzdFxuICAgICAgICAgICAgICAgIGtleT17YCR7aW5kZXh9YH1cbiAgICAgICAgICAgICAgICBpY29uPXtJY29uQ2VudHJlW2l0ZW0udGh1bWJuYWlsIHx8IFwiZGVmYXVsdFwiXX1cbiAgICAgICAgICAgICAgICBuYW1lPXtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgIHNsdWc9e2l0ZW0uc2x1Z31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvU2VydmljZUNvbnRhaW5lcj5cbiAgICAgICAgPC9Db250YWluZXI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMjAgYmctZ3JheXNjYWxlLTEwMFwiPlxuICAgICAgICA8Q29udGFpbmVyPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgcG9wcGlucyB0ZXh0LXhsIGxnOnRleHQtMnhsIHRleHQtY2VudGVyIHRleHQtcHJpbWFyeS0zMDBcIj5cbiAgICAgICAgICAgIEdhbGVyaVxuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPEdhbGxlcnlDb250YWluZXI+XG4gICAgICAgICAgICB7Z2FsbGVyeT8ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICA8R2FsbGVyeUxpc3RcbiAgICAgICAgICAgICAgICBrZXk9e2Ake2luZGV4fWB9XG4gICAgICAgICAgICAgICAgc2x1Zz17aXRlbS5wb3N0LnNsdWd9XG4gICAgICAgICAgICAgICAgdGV4dD17aXRlbS5wb3N0LnRpdGxlfVxuICAgICAgICAgICAgICAgIGltYWdlPXtpdGVtLnBhdGg/LnJlcGxhY2UoXG4gICAgICAgICAgICAgICAgICBcInB1YmxpY1wiLFxuICAgICAgICAgICAgICAgICAgcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQkFTRV9VUkxcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9HYWxsZXJ5Q29udGFpbmVyPlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy1ncmF5c2NhbGUtMTAwIGJvcmRlci10IGJvcmRlci1ncmF5c2NhbGUtMjAwXCI+XG4gICAgICAgIDxDb250YWluZXI+XG4gICAgICAgICAgPEVtYmVkIHJlZklkPVwiY2YwY2RjMjEyOTJlNDI4YTNhNjU0ZmIwNDZjYjcxZTY5NTgwMzBhOFwiIC8+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyYXlzY2FsZS0xMDAgYm9yZGVyLXQgYm9yZGVyLWdyYXlzY2FsZS0yMDBcIj5cbiAgICAgICAgPENvbnRhaW5lciBjbGFzc05hbWU9XCJ6LTEwIHJlbGF0aXZlIGZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6anVzdGlmeS1iZXR3ZWVuIHB5LTIwIHB4LTMgbGc6cHgtMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6dy0xLzMgbGc6bXItMTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xNiB3LWZ1bGwgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICAgICAgdW5vcHRpbWl6ZWQ9e3RydWV9XG4gICAgICAgICAgICAgICAgc3JjPXtiYXNpY0luZm9ybWF0aW9uPy5sb2dvPy5yZXBsYWNlKFxuICAgICAgICAgICAgICAgICAgXCJwdWJsaWNcIixcbiAgICAgICAgICAgICAgICAgIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0JBU0VfVVJMXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICBhbHQ9e2BMb2dvICR7YmFzaWNJbmZvcm1hdGlvbi5jbGluaWNOYW1lfWB9XG4gICAgICAgICAgICAgICAgbGF5b3V0PVwiZmlsbFwiXG4gICAgICAgICAgICAgICAgb2JqZWN0Rml0PVwiY29udGFpblwiXG4gICAgICAgICAgICAgICAgb2JqZWN0UG9zaXRpb249XCJsZWZ0XCJcbiAgICAgICAgICAgICAgICBxdWFsaXR5PXs5MH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXlzY2FsZS03MDAgdGV4dC1qdXN0aWZ5IG10LTVcIj5cbiAgICAgICAgICAgICAge2Jhc2ljSW5mb3JtYXRpb24uZGVzY3JpcHRpb259XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTAgbGc6bWwtNSBtdC04IGxnOm10LTBcIj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnktNDAwIHBvcHBpbnMgZm9udC1ib2xkXCI+SGFsYW1hbjwvaDQ+XG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICB7cGFnZXM/Lm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtgJHtpbmRleH1gfT5cbiAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2AvaGFsYW1hbi8ke2l0ZW0uc2x1Z31gfT5cbiAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHRleHQtZ3JheXNjYWxlLTcwMCBob3Zlcjp0ZXh0LXByaW1hcnktMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtMCBsZzptbC01IG10LTggbGc6bXQtMFwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeS00MDAgcG9wcGlucyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgSmFtIE9wZXJhc2lvbmFsXG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhcmltbyBtdC0zIHRleHQtZ3JheXNjYWxlLTgwMCBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAge2Jhc2ljSW5mb3JtYXRpb24ub3BlcmF0aW9uYWxEYXl9XG4gICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICA8c3Bhbj57YmFzaWNJbmZvcm1hdGlvbi5vcGVyYXRpb25hbEhvdXJ9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFyaW1vIG10LTMgbGc6dy02NCBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1ncmF5c2NhbGUtODAwIGZvbnQtYm9sZFwiPkFsYW1hdDwvc3Ryb25nPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXlzY2FsZS03MDAgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAge2Jhc2ljSW5mb3JtYXRpb24/LmFkZHJlc3N9IDxiciAvPlxuICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICBocmVmPXtiYXNpY0luZm9ybWF0aW9uLmdtYXBzfVxuICAgICAgICAgICAgICAgICAgdGl0bGU9e2BHb29nbGUgTWFwcyAke2Jhc2ljSW5mb3JtYXRpb24uY2xpbmljTmFtZX1gfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5LTIwMFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgTGloYXQgTWFwc1xuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0wIGxnOm1sLTUgbXQtOCBsZzptdC0wXCI+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5LTQwMCBwb3BwaW5zIGZvbnQtYm9sZFwiPklrdXRpIEthbWk8L2g0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXhcIj5cbiAgICAgICAgICAgICAgPFNvY2lhbE1lZGlhQnV0dG9uXG4gICAgICAgICAgICAgICAgdGl0bGU9e2BJbnN0YWdyYW0gJHtiYXNpY0luZm9ybWF0aW9uLmNsaW5pY05hbWV9YH1cbiAgICAgICAgICAgICAgICBpY29uPXtJbnN0YWdyYW19XG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICBocmVmPXtiYXNpY0luZm9ybWF0aW9uLmluc3RhZ3JhbX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPFNvY2lhbE1lZGlhQnV0dG9uXG4gICAgICAgICAgICAgICAgdGl0bGU9e2BGYWNlYm9vayAke2Jhc2ljSW5mb3JtYXRpb24uY2xpbmljTmFtZX1gfVxuICAgICAgICAgICAgICAgIGljb249e0ZhY2Vib29rfVxuICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMlwiXG4gICAgICAgICAgICAgICAgaHJlZj17YmFzaWNJbmZvcm1hdGlvbi5mYWNlYm9va31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==
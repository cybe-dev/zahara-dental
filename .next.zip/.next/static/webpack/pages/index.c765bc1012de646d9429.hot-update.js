webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_images_Background__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../src/images/Background */ "./src/images/Background.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../tailwind.config */ "./tailwind.config.js");
/* harmony import */ var _tailwind_config__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tailwind_config__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _src_components_Container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/components/Container */ "./src/components/Container.jsx");
/* harmony import */ var _src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/components/SocialMediaButton */ "./src/components/SocialMediaButton.jsx");
/* harmony import */ var _src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/components/WhyChoose */ "./src/components/WhyChoose.jsx");
/* harmony import */ var _src_images_BackgroundMobile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../src/images/BackgroundMobile */ "./src/images/BackgroundMobile.js");
/* harmony import */ var _src_images_Welcome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/images/Welcome */ "./src/images/Welcome.js");
/* harmony import */ var _src_components_Service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../src/components/Service */ "./src/components/Service.jsx");
/* harmony import */ var _src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../src/components/Gallery */ "./src/components/Gallery.jsx");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _src_images_Instagram__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../src/images/Instagram */ "./src/images/Instagram.js");
/* harmony import */ var _src_images_Facebook__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../src/images/Facebook */ "./src/images/Facebook.js");
/* harmony import */ var _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../src/images/IconCentre */ "./src/images/IconCentre.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-responsive-carousel/lib/styles/carousel.min.css */ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react-responsive-carousel */ "./node_modules/react-responsive-carousel/lib/js/index.js");
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _src_components_Embed__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../src/components/Embed */ "./src/components/Embed.js");



var _jsxFileName = "C:\\reactprojects\\zahara\\frontend-public\\pages\\index.js",
    _s = $RefreshSig$();
















 // requires a loader




var __N_SSP = true;
function Home(_ref) {
  _s();

  var _this = this,
      _basicInformation$log;

  var basicInformation = _ref.basicInformation,
      kelebihan = _ref.kelebihan,
      services = _ref.services,
      gallery = _ref.gallery,
      pages = _ref.pages,
      slider = _ref.slider;
  var counter = Object(react__WEBPACK_IMPORTED_MODULE_18__["useRef"])(0);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_11___default.a, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: basicInformation.clinicName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_Background__WEBPACK_IMPORTED_MODULE_1__["default"], {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 hidden lg:block",
      fill: _tailwind_config__WEBPACK_IMPORTED_MODULE_3__["theme"].colors.background
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_BackgroundMobile__WEBPACK_IMPORTED_MODULE_7__["default"], {
      className: "h-screen w-full absolute top-0 left-0 z-0 bg-grayscale-100 block lg:hidden",
      fill: _tailwind_config__WEBPACK_IMPORTED_MODULE_3__["theme"].colors.background
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "h-screen relative",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        className: "text-grayscale-800 z-10 flex items-center h-full relative",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:w-1/2",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_images_Welcome__WEBPACK_IMPORTED_MODULE_8__["default"], {
            className: "text-primary-100 mb-5 w-1/2 md:w-1/3 lg:w-2/4 mx-auto lg:mx-0 h-auto"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            className: "font-bold text-xl lg:text-2xl xl:text-3xl poppins mb-3 text-center lg:text-left text-grayscale-800",
            children: "Selamat Datang!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
            className: "text-grayscale-700 text-center lg:text-left",
            children: basicInformation.welcomeText
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 102,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute right-0 z-10 top-0 bottom-0 items-center pt-16 hidden lg:flex w-64",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "lg:p-2 xl:p-5 bg-grayscale-100 shadow-lg rounded-lg",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_17__["Carousel"], {
              showThumbs: false,
              showStatus: false,
              autoPlay: true,
              infiniteLoop: true,
              interval: 3000,
              swipeable: true,
              showArrows: false,
              children: slider === null || slider === void 0 ? void 0 : slider.map(function (item, index) {
                var _item$thumbnail;

                return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
                    unoptimized: true,
                    src: ((_item$thumbnail = item.thumbnail) === null || _item$thumbnail === void 0 ? void 0 : _item$thumbnail.replace("public", "https://admin.zaharadental.com")) || "/images/dentist.jpg",
                    alt: item.title,
                    width: 240,
                    height: 320,
                    className: "rounded-lg",
                    objectFit: "cover"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 119,
                    columnNumber: 21
                  }, _this)
                }, "".concat(index), false, {
                  fileName: _jsxFileName,
                  lineNumber: 118,
                  columnNumber: 19
                }, _this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 108,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 107,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "bg-grayscale-100 py-10",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Mengapa Memilih Klinik Kami?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 142,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__["default"], {
          children: kelebihan === null || kelebihan === void 0 ? void 0 : kelebihan.map(function (item, index) {
            if (counter.current + 1 > 4) {
              counter.current = 1;
            } else {
              counter.current = counter.current + 1;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_WhyChoose__WEBPACK_IMPORTED_MODULE_6__["WhyChooseList"], {
              icon: _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__["default"][item.thumbnail || "default"],
              title: item.title,
              right: counter.current > 2,
              children: item.text
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 153,
              columnNumber: 17
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 140,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "py-16",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Our Services"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Service__WEBPACK_IMPORTED_MODULE_9__["default"], {
          className: "mt-16",
          children: services === null || services === void 0 ? void 0 : services.map(function (item, index) {
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Service__WEBPACK_IMPORTED_MODULE_9__["ServiceList"], {
              icon: _src_images_IconCentre__WEBPACK_IMPORTED_MODULE_14__["default"][item.thumbnail || "default"],
              name: item.title,
              slug: item.slug
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 173,
              columnNumber: 15
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 171,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 167,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 166,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "py-20 bg-grayscale-100",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300",
          children: "Galeri"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__["default"], {
          children: gallery === null || gallery === void 0 ? void 0 : gallery.map(function (item, index) {
            var _item$path;

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Gallery__WEBPACK_IMPORTED_MODULE_10__["GalleryList"], {
              slug: item.post.slug,
              text: item.post.title,
              image: (_item$path = item.path) === null || _item$path === void 0 ? void 0 : _item$path.replace("public", "https://admin.zaharadental.com")
            }, "".concat(index), false, {
              fileName: _jsxFileName,
              lineNumber: 190,
              columnNumber: 15
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 188,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 183,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200 py-20",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: "font-bold poppins text-xl lg:text-2xl text-center text-primary-300 mb-10",
          children: "Instagram Feeds"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Embed__WEBPACK_IMPORTED_MODULE_19__["default"], {
          refId: "cf0cdc21292e428a3a654fb046cb71e6958030a8"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 208,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 204,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative bg-grayscale-100 border-t border-grayscale-200",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Container__WEBPACK_IMPORTED_MODULE_4__["default"], {
        className: "z-10 relative flex flex-col lg:flex-row lg:justify-between py-20 px-3 lg:px-0",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "lg:w-1/2 lg:mr-16",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "h-16 w-full relative",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
              unoptimized: true,
              src: basicInformation === null || basicInformation === void 0 ? void 0 : (_basicInformation$log = basicInformation.logo) === null || _basicInformation$log === void 0 ? void 0 : _basicInformation$log.replace("public", "https://admin.zaharadental.com"),
              alt: "Logo ".concat(basicInformation.clinicName),
              layout: "fill",
              objectFit: "contain",
              objectPosition: "left",
              quality: 90
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 215,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 214,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-grayscale-700 text-justify mt-5",
            children: basicInformation.description
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 228,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold mt-10",
            children: "Ikuti Kami"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 231,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "mt-3 flex",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
              title: "Instagram ".concat(basicInformation.clinicName),
              icon: _src_images_Instagram__WEBPACK_IMPORTED_MODULE_12__["default"],
              target: "_blank",
              href: basicInformation.instagram
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 235,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_SocialMediaButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
              title: "Facebook ".concat(basicInformation.clinicName),
              icon: _src_images_Facebook__WEBPACK_IMPORTED_MODULE_13__["default"],
              target: "_blank",
              className: "ml-2",
              href: basicInformation.facebook
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 241,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 234,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 213,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ml-0 lg:ml-5 mt-8 lg:mt-0",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
            className: "text-primary-400 poppins font-bold",
            children: "Halaman"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 251,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
            className: "mt-3",
            children: pages === null || pages === void 0 ? void 0 : pages.map(function (item, index) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_15___default.a, {
                  href: "/halaman/".concat(item.slug),
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "mt-1 block text-grayscale-700 hover:text-primary-100",
                    title: item.title,
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 256,
                    columnNumber: 21
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 255,
                  columnNumber: 19
                }, _this)
              }, "".concat(index), false, {
                fileName: _jsxFileName,
                lineNumber: 254,
                columnNumber: 17
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 252,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 250,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 212,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 211,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Home, "3iz0ofrn4gTwn024PSoRDlWOdB8=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiSG9tZSIsImJhc2ljSW5mb3JtYXRpb24iLCJrZWxlYmloYW4iLCJzZXJ2aWNlcyIsImdhbGxlcnkiLCJwYWdlcyIsInNsaWRlciIsImNvdW50ZXIiLCJ1c2VSZWYiLCJjbGluaWNOYW1lIiwidGhlbWUiLCJjb2xvcnMiLCJiYWNrZ3JvdW5kIiwid2VsY29tZVRleHQiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJ0aHVtYm5haWwiLCJyZXBsYWNlIiwicHJvY2VzcyIsInRpdGxlIiwiY3VycmVudCIsIkljb25DZW50cmUiLCJ0ZXh0Iiwic2x1ZyIsInBvc3QiLCJwYXRoIiwibG9nbyIsImRlc2NyaXB0aW9uIiwiSW5zdGFncmFtIiwiaW5zdGFncmFtIiwiRmFjZWJvb2siLCJmYWNlYm9vayJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Q0FFZ0U7O0FBQ2hFO0FBQ0E7QUFDQTs7QUFxRGUsU0FBU0EsSUFBVCxPQU9aO0FBQUE7O0FBQUE7QUFBQTs7QUFBQSxNQU5EQyxnQkFNQyxRQU5EQSxnQkFNQztBQUFBLE1BTERDLFNBS0MsUUFMREEsU0FLQztBQUFBLE1BSkRDLFFBSUMsUUFKREEsUUFJQztBQUFBLE1BSERDLE9BR0MsUUFIREEsT0FHQztBQUFBLE1BRkRDLEtBRUMsUUFGREEsS0FFQztBQUFBLE1BRERDLE1BQ0MsUUFEREEsTUFDQztBQUNELE1BQU1DLE9BQU8sR0FBR0MscURBQU0sQ0FBQyxDQUFELENBQXRCO0FBQ0Esc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxpREFBRDtBQUFBLDZCQUNFO0FBQUEsa0JBQVFQLGdCQUFnQixDQUFDUTtBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBSUUscUVBQUMsOERBQUQ7QUFDRSxlQUFTLEVBQUMsNEVBRFo7QUFFRSxVQUFJLEVBQUVDLHNEQUFLLENBQUNDLE1BQU4sQ0FBYUM7QUFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUpGLGVBUUUscUVBQUMsb0VBQUQ7QUFDRSxlQUFTLEVBQUMsNEVBRFo7QUFFRSxVQUFJLEVBQUVGLHNEQUFLLENBQUNDLE1BQU4sQ0FBYUM7QUFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVJGLGVBWUU7QUFBSyxlQUFTLEVBQUMsbUJBQWY7QUFBQSw2QkFDRSxxRUFBQyxpRUFBRDtBQUFXLGlCQUFTLEVBQUMsMkRBQXJCO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLFVBQWY7QUFBQSxrQ0FDRSxxRUFBQywyREFBRDtBQUFTLHFCQUFTLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUkscUJBQVMsRUFBQyxvR0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGRixlQUtFO0FBQUkscUJBQVMsRUFBQyw2Q0FBZDtBQUFBLHNCQUNHWCxnQkFBZ0IsQ0FBQ1k7QUFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFVRTtBQUFLLG1CQUFTLEVBQUMsNkVBQWY7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMscURBQWY7QUFBQSxtQ0FDRSxxRUFBQyxtRUFBRDtBQUNFLHdCQUFVLEVBQUUsS0FEZDtBQUVFLHdCQUFVLEVBQUUsS0FGZDtBQUdFLHNCQUFRLEVBQUUsSUFIWjtBQUlFLDBCQUFZLEVBQUUsSUFKaEI7QUFLRSxzQkFBUSxFQUFFLElBTFo7QUFNRSx1QkFBUyxFQUFFLElBTmI7QUFPRSx3QkFBVSxFQUFFLEtBUGQ7QUFBQSx3QkFTR1AsTUFUSCxhQVNHQSxNQVRILHVCQVNHQSxNQUFNLENBQUVRLEdBQVIsQ0FBWSxVQUFDQyxJQUFELEVBQU9DLEtBQVA7QUFBQTs7QUFBQSxvQ0FDWDtBQUFBLHlDQUNFLHFFQUFDLGlEQUFEO0FBQ0UsK0JBQVcsRUFBRSxJQURmO0FBRUUsdUJBQUcsRUFDRCxvQkFBQUQsSUFBSSxDQUFDRSxTQUFMLG9FQUFnQkMsT0FBaEIsQ0FDRSxRQURGLEVBRUVDLGdDQUZGLE1BR0sscUJBTlQ7QUFRRSx1QkFBRyxFQUFFSixJQUFJLENBQUNLLEtBUlo7QUFTRSx5QkFBSyxFQUFFLEdBVFQ7QUFVRSwwQkFBTSxFQUFFLEdBVlY7QUFXRSw2QkFBUyxFQUFDLFlBWFo7QUFZRSw2QkFBUyxFQUFDO0FBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLDZCQUFhSixLQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRFc7QUFBQSxlQUFaO0FBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFaRixlQXlERTtBQUFLLGVBQVMsRUFBQyx3QkFBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLG9FQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUscUVBQUMsaUVBQUQ7QUFBQSxvQkFDR2QsU0FESCxhQUNHQSxTQURILHVCQUNHQSxTQUFTLENBQUVZLEdBQVgsQ0FBZSxVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDL0IsZ0JBQUlULE9BQU8sQ0FBQ2MsT0FBUixHQUFrQixDQUFsQixHQUFzQixDQUExQixFQUE2QjtBQUMzQmQscUJBQU8sQ0FBQ2MsT0FBUixHQUFrQixDQUFsQjtBQUNELGFBRkQsTUFFTztBQUNMZCxxQkFBTyxDQUFDYyxPQUFSLEdBQWtCZCxPQUFPLENBQUNjLE9BQVIsR0FBa0IsQ0FBcEM7QUFDRDs7QUFDRCxnQ0FDRSxxRUFBQyx1RUFBRDtBQUVFLGtCQUFJLEVBQUVDLCtEQUFVLENBQUNQLElBQUksQ0FBQ0UsU0FBTCxJQUFrQixTQUFuQixDQUZsQjtBQUdFLG1CQUFLLEVBQUVGLElBQUksQ0FBQ0ssS0FIZDtBQUlFLG1CQUFLLEVBQUViLE9BQU8sQ0FBQ2MsT0FBUixHQUFrQixDQUozQjtBQUFBLHdCQU1HTixJQUFJLENBQUNRO0FBTlIseUJBQ1VQLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQVVELFdBaEJBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBekRGLGVBbUZFO0FBQUssZUFBUyxFQUFDLE9BQWY7QUFBQSw2QkFDRSxxRUFBQyxpRUFBRDtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxvRUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUlFLHFFQUFDLCtEQUFEO0FBQWtCLG1CQUFTLEVBQUMsT0FBNUI7QUFBQSxvQkFDR2IsUUFESCxhQUNHQSxRQURILHVCQUNHQSxRQUFRLENBQUVXLEdBQVYsQ0FBYyxVQUFDQyxJQUFELEVBQU9DLEtBQVA7QUFBQSxnQ0FDYixxRUFBQyxtRUFBRDtBQUVFLGtCQUFJLEVBQUVNLCtEQUFVLENBQUNQLElBQUksQ0FBQ0UsU0FBTCxJQUFrQixTQUFuQixDQUZsQjtBQUdFLGtCQUFJLEVBQUVGLElBQUksQ0FBQ0ssS0FIYjtBQUlFLGtCQUFJLEVBQUVMLElBQUksQ0FBQ1M7QUFKYix5QkFDVVIsS0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURhO0FBQUEsV0FBZDtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW5GRixlQW9HRTtBQUFLLGVBQVMsRUFBQyx3QkFBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLG9FQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUscUVBQUMsZ0VBQUQ7QUFBQSxvQkFDR1osT0FESCxhQUNHQSxPQURILHVCQUNHQSxPQUFPLENBQUVVLEdBQVQsQ0FBYSxVQUFDQyxJQUFELEVBQU9DLEtBQVA7QUFBQTs7QUFBQSxnQ0FDWixxRUFBQyxvRUFBRDtBQUVFLGtCQUFJLEVBQUVELElBQUksQ0FBQ1UsSUFBTCxDQUFVRCxJQUZsQjtBQUdFLGtCQUFJLEVBQUVULElBQUksQ0FBQ1UsSUFBTCxDQUFVTCxLQUhsQjtBQUlFLG1CQUFLLGdCQUFFTCxJQUFJLENBQUNXLElBQVAsK0NBQUUsV0FBV1IsT0FBWCxDQUNMLFFBREssRUFFTEMsZ0NBRks7QUFKVCx5QkFDVUgsS0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURZO0FBQUEsV0FBYjtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXBHRixlQXdIRTtBQUFLLGVBQVMsRUFBQywrREFBZjtBQUFBLDZCQUNFLHFFQUFDLGlFQUFEO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLDBFQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUscUVBQUMsOERBQUQ7QUFBTyxlQUFLLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF4SEYsZUFnSUU7QUFBSyxlQUFTLEVBQUMseURBQWY7QUFBQSw2QkFDRSxxRUFBQyxpRUFBRDtBQUFXLGlCQUFTLEVBQUMsK0VBQXJCO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLG1CQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLHNCQUFmO0FBQUEsbUNBQ0UscUVBQUMsaURBQUQ7QUFDRSx5QkFBVyxFQUFFLElBRGY7QUFFRSxpQkFBRyxFQUFFZixnQkFBRixhQUFFQSxnQkFBRixnREFBRUEsZ0JBQWdCLENBQUUwQixJQUFwQiwwREFBRSxzQkFBd0JULE9BQXhCLENBQ0gsUUFERyxFQUVIQyxnQ0FGRyxDQUZQO0FBTUUsaUJBQUcsaUJBQVVsQixnQkFBZ0IsQ0FBQ1EsVUFBM0IsQ0FOTDtBQU9FLG9CQUFNLEVBQUMsTUFQVDtBQVFFLHVCQUFTLEVBQUMsU0FSWjtBQVNFLDRCQUFjLEVBQUMsTUFUakI7QUFVRSxxQkFBTyxFQUFFO0FBVlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFlRTtBQUFLLHFCQUFTLEVBQUMsc0NBQWY7QUFBQSxzQkFDR1IsZ0JBQWdCLENBQUMyQjtBQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWZGLGVBa0JFO0FBQUkscUJBQVMsRUFBQywwQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFsQkYsZUFxQkU7QUFBSyxxQkFBUyxFQUFDLFdBQWY7QUFBQSxvQ0FDRSxxRUFBQyx5RUFBRDtBQUNFLG1CQUFLLHNCQUFlM0IsZ0JBQWdCLENBQUNRLFVBQWhDLENBRFA7QUFFRSxrQkFBSSxFQUFFb0IsOERBRlI7QUFHRSxvQkFBTSxFQUFDLFFBSFQ7QUFJRSxrQkFBSSxFQUFFNUIsZ0JBQWdCLENBQUM2QjtBQUp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBT0UscUVBQUMseUVBQUQ7QUFDRSxtQkFBSyxxQkFBYzdCLGdCQUFnQixDQUFDUSxVQUEvQixDQURQO0FBRUUsa0JBQUksRUFBRXNCLDZEQUZSO0FBR0Usb0JBQU0sRUFBQyxRQUhUO0FBSUUsdUJBQVMsRUFBQyxNQUpaO0FBS0Usa0JBQUksRUFBRTlCLGdCQUFnQixDQUFDK0I7QUFMekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQXNDRTtBQUFLLG1CQUFTLEVBQUMsMkJBQWY7QUFBQSxrQ0FDRTtBQUFJLHFCQUFTLEVBQUMsb0NBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRTtBQUFJLHFCQUFTLEVBQUMsTUFBZDtBQUFBLHNCQUNHM0IsS0FESCxhQUNHQSxLQURILHVCQUNHQSxLQUFLLENBQUVTLEdBQVAsQ0FBVyxVQUFDQyxJQUFELEVBQU9DLEtBQVA7QUFBQSxrQ0FDVjtBQUFBLHVDQUNFLHFFQUFDLGlEQUFEO0FBQU0sc0JBQUkscUJBQWNELElBQUksQ0FBQ1MsSUFBbkIsQ0FBVjtBQUFBLHlDQUNFO0FBQ0UsNkJBQVMsRUFBQyxzREFEWjtBQUVFLHlCQUFLLEVBQUVULElBQUksQ0FBQ0ssS0FGZDtBQUFBLDhCQUlHTCxJQUFJLENBQUNLO0FBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERiwyQkFBWUosS0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURVO0FBQUEsYUFBWDtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBaElGO0FBQUEsa0JBREY7QUE2TEQ7O0dBdE11QmhCLEk7O0tBQUFBLEkiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYzc2NWJjMTAxMmRlNjQ2ZDk0MjkuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBCYWNrZ3JvdW5kIGZyb20gXCIuLi9zcmMvaW1hZ2VzL0JhY2tncm91bmRcIjtcbmltcG9ydCBJbWFnZSBmcm9tIFwibmV4dC9pbWFnZVwiO1xuaW1wb3J0IHsgdGhlbWUgfSBmcm9tIFwiLi4vdGFpbHdpbmQuY29uZmlnXCI7XG5pbXBvcnQgQ29udGFpbmVyIGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9Db250YWluZXJcIjtcbmltcG9ydCBTb2NpYWxNZWRpYUJ1dHRvbiBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvU29jaWFsTWVkaWFCdXR0b25cIjtcbmltcG9ydCBXaHlDaG9vc2VDb250YWluZXIsIHsgV2h5Q2hvb3NlTGlzdCB9IGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9XaHlDaG9vc2VcIjtcbmltcG9ydCBCYWNrZ3JvdW5kTW9iaWxlIGZyb20gXCIuLi9zcmMvaW1hZ2VzL0JhY2tncm91bmRNb2JpbGVcIjtcbmltcG9ydCBXZWxjb21lIGZyb20gXCIuLi9zcmMvaW1hZ2VzL1dlbGNvbWVcIjtcbmltcG9ydCBTZXJ2aWNlQ29udGFpbmVyLCB7IFNlcnZpY2VMaXN0IH0gZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL1NlcnZpY2VcIjtcbmltcG9ydCBHYWxsZXJ5Q29udGFpbmVyLCB7IEdhbGxlcnlMaXN0IH0gZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL0dhbGxlcnlcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCBJbnN0YWdyYW0gZnJvbSBcIi4uL3NyYy9pbWFnZXMvSW5zdGFncmFtXCI7XG5pbXBvcnQgRmFjZWJvb2sgZnJvbSBcIi4uL3NyYy9pbWFnZXMvRmFjZWJvb2tcIjtcbmltcG9ydCBJY29uQ2VudHJlIGZyb20gXCIuLi9zcmMvaW1hZ2VzL0ljb25DZW50cmVcIjtcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcbmltcG9ydCBzZXJ2aWNlIGZyb20gXCIuLi9zcmMvc2VydmljZVwiO1xuaW1wb3J0IFwicmVhY3QtcmVzcG9uc2l2ZS1jYXJvdXNlbC9saWIvc3R5bGVzL2Nhcm91c2VsLm1pbi5jc3NcIjsgLy8gcmVxdWlyZXMgYSBsb2FkZXJcbmltcG9ydCB7IENhcm91c2VsIH0gZnJvbSBcInJlYWN0LXJlc3BvbnNpdmUtY2Fyb3VzZWxcIjtcbmltcG9ydCB7IHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IEVtYmVkIGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9FbWJlZFwiO1xuXG5leHBvcnQgY29uc3QgZ2V0U2VydmVyU2lkZVByb3BzID0gYXN5bmMgKCkgPT4ge1xuICBsZXQgYmFzaWNJbmZvcm1hdGlvbixcbiAgICBrZWxlYmloYW4sXG4gICAgc2VydmljZXMsXG4gICAgc3ViU2VydmljZXMsXG4gICAgZ2FsbGVyeSxcbiAgICBwYWdlcyxcbiAgICBzbGlkZXI7XG4gIHRyeSB7XG4gICAgYmFzaWNJbmZvcm1hdGlvbiA9IChhd2FpdCBzZXJ2aWNlLmdldChcIi9iYXNpYy1pbmZvcm1hdGlvblwiKSkuZGF0YS5zdWNjZXNzXG4gICAgICAuZGF0YTtcbiAgICBzZXJ2aWNlcyA9IChhd2FpdCBzZXJ2aWNlLmdldChcIi9wb3N0L2xheWFuYW4/bGltaXQ9MTAwXCIpKS5kYXRhLnN1Y2Nlc3MuZGF0YVxuICAgICAgLnJvd3M7XG4gICAgc3ViU2VydmljZXMgPSAoYXdhaXQgc2VydmljZS5nZXQoXCIvcG9zdC9zdWItbGF5YW5hbj9saW1pdD0xMDAmbm9kZXNjPTFcIikpXG4gICAgICAuZGF0YS5zdWNjZXNzLmRhdGEucm93cztcbiAgICBrZWxlYmloYW4gPSAoYXdhaXQgc2VydmljZS5nZXQoXCIvcG9zdC9rZWxlYmloYW5cIikpLmRhdGEuc3VjY2Vzcy5kYXRhLnJvd3M7XG4gICAgc2xpZGVyID0gKGF3YWl0IHNlcnZpY2UuZ2V0KFwiL3Bvc3Qvc2xpZGVyXCIpKS5kYXRhLnN1Y2Nlc3MuZGF0YS5yb3dzO1xuICAgIHBhZ2VzID0gKGF3YWl0IHNlcnZpY2UuZ2V0KFwiL3Bvc3QvaGFsYW1hbj9saW1pdD0xMDAmbm9kZXNjPTFcIikpLmRhdGEuc3VjY2Vzc1xuICAgICAgLmRhdGEucm93cztcbiAgICBnYWxsZXJ5ID0gKGF3YWl0IHNlcnZpY2UuZ2V0KFwiL2dhbGxlcnkvdHlwZS9sYXlhbmFuP2xpbWl0PThcIikpLmRhdGEuc3VjY2Vzc1xuICAgICAgLmRhdGEucm93cztcbiAgfSBjYXRjaCAoZSkge1xuICAgIGNvbnNvbGUubG9nKGUpO1xuICAgIHJldHVybiB7XG4gICAgICBwcm9wczoge1xuICAgICAgICBzdGF0dXM6IDUwMCxcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHByb3BzOiB7XG4gICAgICBiYXNpY0luZm9ybWF0aW9uLFxuICAgICAga2VsZWJpaGFuLFxuICAgICAgc2VydmljZXMsXG4gICAgICBzdWJTZXJ2aWNlcyxcbiAgICAgIGdhbGxlcnksXG4gICAgICBwYWdlcyxcbiAgICAgIGhlYWRlclByb3BzOiB7XG4gICAgICAgIHRyYW5zcGFyZW50Rmlyc3Q6IHRydWUsXG4gICAgICB9LFxuICAgICAgc2xpZGVyLFxuICAgICAgbWV0YVRhZzogW1xuICAgICAgICB7XG4gICAgICAgICAgbmFtZTogXCJkZXNjcmlwdGlvblwiLFxuICAgICAgICAgIGNvbnRlbnQ6IGJhc2ljSW5mb3JtYXRpb24uZGVzY3JpcHRpb24/LnN1YnN0cigwLCAxNTApIHx8IFwiXCIsXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH0sXG4gIH07XG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKHtcbiAgYmFzaWNJbmZvcm1hdGlvbixcbiAga2VsZWJpaGFuLFxuICBzZXJ2aWNlcyxcbiAgZ2FsbGVyeSxcbiAgcGFnZXMsXG4gIHNsaWRlcixcbn0pIHtcbiAgY29uc3QgY291bnRlciA9IHVzZVJlZigwKTtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT57YmFzaWNJbmZvcm1hdGlvbi5jbGluaWNOYW1lfTwvdGl0bGU+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8QmFja2dyb3VuZFxuICAgICAgICBjbGFzc05hbWU9XCJoLXNjcmVlbiB3LWZ1bGwgYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHotMCBiZy1ncmF5c2NhbGUtMTAwIGhpZGRlbiBsZzpibG9ja1wiXG4gICAgICAgIGZpbGw9e3RoZW1lLmNvbG9ycy5iYWNrZ3JvdW5kfVxuICAgICAgLz5cbiAgICAgIDxCYWNrZ3JvdW5kTW9iaWxlXG4gICAgICAgIGNsYXNzTmFtZT1cImgtc2NyZWVuIHctZnVsbCBhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgei0wIGJnLWdyYXlzY2FsZS0xMDAgYmxvY2sgbGc6aGlkZGVuXCJcbiAgICAgICAgZmlsbD17dGhlbWUuY29sb3JzLmJhY2tncm91bmR9XG4gICAgICAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLXNjcmVlbiByZWxhdGl2ZVwiPlxuICAgICAgICA8Q29udGFpbmVyIGNsYXNzTmFtZT1cInRleHQtZ3JheXNjYWxlLTgwMCB6LTEwIGZsZXggaXRlbXMtY2VudGVyIGgtZnVsbCByZWxhdGl2ZVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6dy0xLzJcIj5cbiAgICAgICAgICAgIDxXZWxjb21lIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeS0xMDAgbWItNSB3LTEvMiBtZDp3LTEvMyBsZzp3LTIvNCBteC1hdXRvIGxnOm14LTAgaC1hdXRvXCIgLz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14bCBsZzp0ZXh0LTJ4bCB4bDp0ZXh0LTN4bCBwb3BwaW5zIG1iLTMgdGV4dC1jZW50ZXIgbGc6dGV4dC1sZWZ0IHRleHQtZ3JheXNjYWxlLTgwMFwiPlxuICAgICAgICAgICAgICBTZWxhbWF0IERhdGFuZyFcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1ncmF5c2NhbGUtNzAwIHRleHQtY2VudGVyIGxnOnRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICB7YmFzaWNJbmZvcm1hdGlvbi53ZWxjb21lVGV4dH1cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHotMTAgdG9wLTAgYm90dG9tLTAgaXRlbXMtY2VudGVyIHB0LTE2IGhpZGRlbiBsZzpmbGV4IHctNjRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6cC0yIHhsOnAtNSBiZy1ncmF5c2NhbGUtMTAwIHNoYWRvdy1sZyByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgIDxDYXJvdXNlbFxuICAgICAgICAgICAgICAgIHNob3dUaHVtYnM9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIHNob3dTdGF0dXM9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIGF1dG9QbGF5PXt0cnVlfVxuICAgICAgICAgICAgICAgIGluZmluaXRlTG9vcD17dHJ1ZX1cbiAgICAgICAgICAgICAgICBpbnRlcnZhbD17MzAwMH1cbiAgICAgICAgICAgICAgICBzd2lwZWFibGU9e3RydWV9XG4gICAgICAgICAgICAgICAgc2hvd0Fycm93cz17ZmFsc2V9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7c2xpZGVyPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17YCR7aW5kZXh9YH0+XG4gICAgICAgICAgICAgICAgICAgIDxJbWFnZVxuICAgICAgICAgICAgICAgICAgICAgIHVub3B0aW1pemVkPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgICAgIHNyYz17XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnRodW1ibmFpbD8ucmVwbGFjZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJwdWJsaWNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQkFTRV9VUkxcbiAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIvaW1hZ2VzL2RlbnRpc3QuanBnXCJcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgIHdpZHRoPXsyNDB9XG4gICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PXszMjB9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgb2JqZWN0Rml0PVwiY292ZXJcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvQ2Fyb3VzZWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9Db250YWluZXI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheXNjYWxlLTEwMCBweS0xMFwiPlxuICAgICAgICA8Q29udGFpbmVyPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgcG9wcGlucyB0ZXh0LXhsIGxnOnRleHQtMnhsIHRleHQtY2VudGVyIHRleHQtcHJpbWFyeS0zMDBcIj5cbiAgICAgICAgICAgIE1lbmdhcGEgTWVtaWxpaCBLbGluaWsgS2FtaT9cbiAgICAgICAgICA8L2gzPlxuICAgICAgICAgIDxXaHlDaG9vc2VDb250YWluZXI+XG4gICAgICAgICAgICB7a2VsZWJpaGFuPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgIGlmIChjb3VudGVyLmN1cnJlbnQgKyAxID4gNCkge1xuICAgICAgICAgICAgICAgIGNvdW50ZXIuY3VycmVudCA9IDE7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY291bnRlci5jdXJyZW50ID0gY291bnRlci5jdXJyZW50ICsgMTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxXaHlDaG9vc2VMaXN0XG4gICAgICAgICAgICAgICAgICBrZXk9e2Ake2luZGV4fWB9XG4gICAgICAgICAgICAgICAgICBpY29uPXtJY29uQ2VudHJlW2l0ZW0udGh1bWJuYWlsIHx8IFwiZGVmYXVsdFwiXX1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPXtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgcmlnaHQ9e2NvdW50ZXIuY3VycmVudCA+IDJ9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cbiAgICAgICAgICAgICAgICA8L1doeUNob29zZUxpc3Q+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L1doeUNob29zZUNvbnRhaW5lcj5cbiAgICAgICAgPC9Db250YWluZXI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTZcIj5cbiAgICAgICAgPENvbnRhaW5lcj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHBvcHBpbnMgdGV4dC14bCBsZzp0ZXh0LTJ4bCB0ZXh0LWNlbnRlciB0ZXh0LXByaW1hcnktMzAwXCI+XG4gICAgICAgICAgICBPdXIgU2VydmljZXNcbiAgICAgICAgICA8L2gzPlxuICAgICAgICAgIDxTZXJ2aWNlQ29udGFpbmVyIGNsYXNzTmFtZT1cIm10LTE2XCI+XG4gICAgICAgICAgICB7c2VydmljZXM/Lm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgPFNlcnZpY2VMaXN0XG4gICAgICAgICAgICAgICAga2V5PXtgJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgIGljb249e0ljb25DZW50cmVbaXRlbS50aHVtYm5haWwgfHwgXCJkZWZhdWx0XCJdfVxuICAgICAgICAgICAgICAgIG5hbWU9e2l0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgc2x1Zz17aXRlbS5zbHVnfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9TZXJ2aWNlQ29udGFpbmVyPlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0yMCBiZy1ncmF5c2NhbGUtMTAwXCI+XG4gICAgICAgIDxDb250YWluZXI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBwb3BwaW5zIHRleHQteGwgbGc6dGV4dC0yeGwgdGV4dC1jZW50ZXIgdGV4dC1wcmltYXJ5LTMwMFwiPlxuICAgICAgICAgICAgR2FsZXJpXG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8R2FsbGVyeUNvbnRhaW5lcj5cbiAgICAgICAgICAgIHtnYWxsZXJ5Py5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgIDxHYWxsZXJ5TGlzdFxuICAgICAgICAgICAgICAgIGtleT17YCR7aW5kZXh9YH1cbiAgICAgICAgICAgICAgICBzbHVnPXtpdGVtLnBvc3Quc2x1Z31cbiAgICAgICAgICAgICAgICB0ZXh0PXtpdGVtLnBvc3QudGl0bGV9XG4gICAgICAgICAgICAgICAgaW1hZ2U9e2l0ZW0ucGF0aD8ucmVwbGFjZShcbiAgICAgICAgICAgICAgICAgIFwicHVibGljXCIsXG4gICAgICAgICAgICAgICAgICBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19CQVNFX1VSTFxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L0dhbGxlcnlDb250YWluZXI+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyYXlzY2FsZS0xMDAgYm9yZGVyLXQgYm9yZGVyLWdyYXlzY2FsZS0yMDAgcHktMjBcIj5cbiAgICAgICAgPENvbnRhaW5lcj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHBvcHBpbnMgdGV4dC14bCBsZzp0ZXh0LTJ4bCB0ZXh0LWNlbnRlciB0ZXh0LXByaW1hcnktMzAwIG1iLTEwXCI+XG4gICAgICAgICAgICBJbnN0YWdyYW0gRmVlZHNcbiAgICAgICAgICA8L2gzPlxuICAgICAgICAgIDxFbWJlZCByZWZJZD1cImNmMGNkYzIxMjkyZTQyOGEzYTY1NGZiMDQ2Y2I3MWU2OTU4MDMwYThcIiAvPlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy1ncmF5c2NhbGUtMTAwIGJvcmRlci10IGJvcmRlci1ncmF5c2NhbGUtMjAwXCI+XG4gICAgICAgIDxDb250YWluZXIgY2xhc3NOYW1lPVwiei0xMCByZWxhdGl2ZSBmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGxnOmp1c3RpZnktYmV0d2VlbiBweS0yMCBweC0zIGxnOnB4LTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOnctMS8yIGxnOm1yLTE2XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTYgdy1mdWxsIHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxJbWFnZVxuICAgICAgICAgICAgICAgIHVub3B0aW1pemVkPXt0cnVlfVxuICAgICAgICAgICAgICAgIHNyYz17YmFzaWNJbmZvcm1hdGlvbj8ubG9nbz8ucmVwbGFjZShcbiAgICAgICAgICAgICAgICAgIFwicHVibGljXCIsXG4gICAgICAgICAgICAgICAgICBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19CQVNFX1VSTFxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgYWx0PXtgTG9nbyAke2Jhc2ljSW5mb3JtYXRpb24uY2xpbmljTmFtZX1gfVxuICAgICAgICAgICAgICAgIGxheW91dD1cImZpbGxcIlxuICAgICAgICAgICAgICAgIG9iamVjdEZpdD1cImNvbnRhaW5cIlxuICAgICAgICAgICAgICAgIG9iamVjdFBvc2l0aW9uPVwibGVmdFwiXG4gICAgICAgICAgICAgICAgcXVhbGl0eT17OTB9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5c2NhbGUtNzAwIHRleHQtanVzdGlmeSBtdC01XCI+XG4gICAgICAgICAgICAgIHtiYXNpY0luZm9ybWF0aW9uLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5LTQwMCBwb3BwaW5zIGZvbnQtYm9sZCBtdC0xMFwiPlxuICAgICAgICAgICAgICBJa3V0aSBLYW1pXG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXhcIj5cbiAgICAgICAgICAgICAgPFNvY2lhbE1lZGlhQnV0dG9uXG4gICAgICAgICAgICAgICAgdGl0bGU9e2BJbnN0YWdyYW0gJHtiYXNpY0luZm9ybWF0aW9uLmNsaW5pY05hbWV9YH1cbiAgICAgICAgICAgICAgICBpY29uPXtJbnN0YWdyYW19XG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICBocmVmPXtiYXNpY0luZm9ybWF0aW9uLmluc3RhZ3JhbX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPFNvY2lhbE1lZGlhQnV0dG9uXG4gICAgICAgICAgICAgICAgdGl0bGU9e2BGYWNlYm9vayAke2Jhc2ljSW5mb3JtYXRpb24uY2xpbmljTmFtZX1gfVxuICAgICAgICAgICAgICAgIGljb249e0ZhY2Vib29rfVxuICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMlwiXG4gICAgICAgICAgICAgICAgaHJlZj17YmFzaWNJbmZvcm1hdGlvbi5mYWNlYm9va31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtMCBsZzptbC01IG10LTggbGc6bXQtMFwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeS00MDAgcG9wcGlucyBmb250LWJvbGRcIj5IYWxhbWFuPC9oND5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtdC0zXCI+XG4gICAgICAgICAgICAgIHtwYWdlcz8ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2Ake2luZGV4fWB9PlxuICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj17YC9oYWxhbWFuLyR7aXRlbS5zbHVnfWB9PlxuICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdGV4dC1ncmF5c2NhbGUtNzAwIGhvdmVyOnRleHQtcHJpbWFyeS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9